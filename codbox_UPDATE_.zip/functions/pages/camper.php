﻿<?php

$filemtime=filemtime($crn_camp);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_camp) != 0))
      if (time()-$filemtime < 20200)  //21600  6 hours   
			{	
				
if(filesize($crn_camp) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_3) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.camp+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $campr = $row['camp'];
	$campl = $row['s_player'];
	$camp_guid = $row['s_guid'];
} 


 	$fpl = fopen($crn_camp, 'w+');
	fwrite($fpl, $camp_guid."%".$campl."%".$campr);	
    fclose($fpl);
 
    
	}
	else
	{
		
$fpl = file($crn_camp);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$camp_guid = trim($infff[0]);		
$campl = trim($infff[1]);	
$campr = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 20200) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_3) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.camp+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $campr = $row['camp'];
	$campl = $row['s_player'];
	$camp_guid = $row['s_guid'];
} 


 	$fpl = fopen($crn_camp, 'w+');
	fwrite($fpl, $camp_guid."%".$campl."%".$campr);	
    fclose($fpl);
}
