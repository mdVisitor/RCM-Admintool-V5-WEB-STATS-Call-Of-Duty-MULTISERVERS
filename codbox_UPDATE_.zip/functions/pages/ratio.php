﻿<?php

$filemtime=filemtime($crn_ratio);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_ratio) != 0))
      if (time()-$filemtime < 1200)  //21600  6 hours   
			{	
				
if(filesize($crn_ratio) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.w_ratio+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $ratioxr = $row['w_ratio'];
	$ratioxrpl = $row['s_player'];
	$ratioxr_guid = $row['s_guid'];
} 


 	$fpl = fopen($crn_ratio, 'w+');
	fwrite($fpl, $ratioxr_guid."%".$ratioxrpl."%".$ratioxr);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_ratio);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$ratioxr_guid = trim($infff[0]);		
$ratioxrpl = trim($infff[1]);	
$ratioxr = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 1200) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.w_ratio+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $ratioxr = $row['w_ratio'];
	$ratioxrpl = $row['s_player'];
	$ratioxr_guid = $row['s_guid'];
} 


 	$fpl = fopen($crn_ratio, 'w+');
	fwrite($fpl, $ratioxr_guid."%".$ratioxrpl."%".$ratioxr);	
    fclose($fpl);
}
