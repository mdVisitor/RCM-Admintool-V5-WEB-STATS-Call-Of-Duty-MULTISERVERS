﻿<?php

$filemtime=filemtime($crn_cobra);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_cobra) != 0))
      if (time()-$filemtime < 8600)  //21600  6 hours   
			{	
				
if(filesize($crn_cobra) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_5) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.cobra_+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $cobra = $row['cobra_'];
	$cobrakiller = $row['s_player'];
	$cobrakiller_guid = $row['s_guid'];
}
  

 	$fpl = fopen($crn_cobra, 'w+');
	fwrite($fpl, $cobrakiller_guid."%".$cobrakiller."%".$cobra);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_cobra);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$cobrakiller_guid = trim($infff[0]);		
$cobrakiller = trim($infff[1]);	
$cobra = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 8600) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_5) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.cobra_+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $cobra = $row['cobra_'];
	$cobrakiller = $row['s_player'];
	$cobrakiller_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_cobra, 'w+');
	fwrite($fpl, $cobrakiller_guid."%".$cobrakiller."%".$cobra);	
    fclose($fpl);
}
