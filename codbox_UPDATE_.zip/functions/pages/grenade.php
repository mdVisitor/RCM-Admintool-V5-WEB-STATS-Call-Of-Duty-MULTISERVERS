﻿<?php
 $filemtime=filemtime($crn_grenade);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_grenade) != 0))
      if (time()-$filemtime < 14800)  //21600  6 hours   
			{	
				
if(filesize($crn_grenade) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_3) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.grenade+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $grenade = $row['grenade'];
	$grenadekiller = $row['s_player'];
	$grenadekiller_guid = $row['s_guid'];
}


	$fpl = fopen($crn_grenade, 'w+');
	fwrite($fpl, $grenadekiller_guid."%".$grenadekiller."%".$grenade);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_grenade);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$grenadekiller_guid = trim($infff[0]);		
$grenadekiller = trim($infff[1]);	
$grenade = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 14800) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_3) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.grenade+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $grenade = $row['grenade'];
	$grenadekiller = $row['s_player'];
	$grenadekiller_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_grenade, 'w+');
	fwrite($fpl, $grenadekiller_guid."%".$grenadekiller."%".$grenade);	
    fclose($fpl);
}
