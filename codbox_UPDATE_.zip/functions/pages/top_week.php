﻿<?php
$filemtime=filemtime($top_w);
            //if ((time()-$filemtime>= 100)&& (filesize($top_w) != 0))
      if (time()-$filemtime < 12600)  //21600  3,5 hours   
			{	
				
if(filesize($top_w) == 0)
{
	
	if (strpos($_SERVER["REQUEST_URI"], '/stats.php?main=0&kills=sort') !== false)
 	   $rs = $dbm3day->query("SELECT servername,s_pg,w_port,s_player,s_kills,s_deaths,s_heads,s_lasttime,w_guid FROM db_stats_day WHERE s_kills ORDER BY (s_kills+0) DESC LIMIT 3");
	else if((strpos($_SERVER["REQUEST_URI"], '&kills=sort') !== false)&&(!empty($server)))
	   $rs = $dbm3day->query("SELECT servername,s_pg,w_port,s_player,s_kills,s_deaths,s_heads,s_lasttime,w_guid FROM db_stats_day WHERE s_kills and w_port='$server' ORDER BY (s_kills+0) DESC LIMIT 3");
 
 $sss=0;
 
 
 foreach ($rs as $row){	 

	++$sss;
                $serverx    = $row['servername']; 
                $csi_pg       = $row['s_pg']; 
				$cntz       = $row['w_port'];
                $playername = $row['s_player'];
                $kills      = $row['s_kills'];
                $deaths     = $row['s_deaths'];				
                //$suicids    = $row['s_suicids'];				
                $heads      = $row['s_heads'];
                $lasttime   = $row['s_lasttime'];
                $guidi[]       = $row['w_guid'];
 
	 
	            $jarr_playername[] = $playername;
	            $akills[]      = $kills;
				$iarr_deaths[]     = $deaths;
				$iarr_sss[]        = $sss;
				$cs_pg[]        = $csi_pg;
                //$iarr_cfour[]      = $cfour;				

		   }


if(!empty($cs_pg)){
	$fpl = fopen($top_w, 'w+');
	fwrite($fpl, $cs_pg."%".$jarr_playername."%".$akills."\n");	
    fclose($fpl);
}

    
	}
	else
	{
		
$fpl = file($top_w);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$cs_pg = trim($infff[0]);		
$jarr_playername = trim($infff[1]);	
$akills = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 12600) 
{





	if (strpos($_SERVER["REQUEST_URI"], '/stats.php?main=0&kills=sort') !== false)
 	   $rs = $dbm3day->query("SELECT servername,s_pg,w_port,s_player,s_kills,s_deaths,s_heads,s_lasttime,w_guid FROM db_stats_day WHERE s_kills ORDER BY (s_kills+0) DESC LIMIT 3");
	else if((strpos($_SERVER["REQUEST_URI"], '&kills=sort') !== false)&&(!empty($server)))
	   $rs = $dbm3day->query("SELECT servername,s_pg,w_port,s_player,s_kills,s_deaths,s_heads,s_lasttime,w_guid FROM db_stats_day WHERE s_kills and w_port='$server' ORDER BY (s_kills+0) DESC LIMIT 3");
 
 $sss=0;
 
 
 foreach ($rs as $row){	 

	++$sss;
                $serverx    = $row['servername']; 
                $csi_pg       = $row['s_pg']; 
				$cntz       = $row['w_port'];
                $playername = $row['s_player'];
                $kills      = $row['s_kills'];
                $deaths     = $row['s_deaths'];				
                //$suicids    = $row['s_suicids'];				
                $heads      = $row['s_heads'];
                $lasttime   = $row['s_lasttime'];
                $guidi[]       = $row['w_guid'];
 
	 
	            $jarr_playername[] = $playername;
	            $akills[]      = $kills;
				$iarr_deaths[]     = $deaths;
				$iarr_sss[]        = $sss;
				$cs_pg[]        = $csi_pg;
                //$iarr_cfour[]      = $cfour;				
           }

if(!empty($cs_pg)){
	$fpl = fopen($top_w, 'w+');
	fwrite($fpl, $cs_pg."%".$jarr_playername."%".$akills."\n");	
    fclose($fpl);
	}
}
