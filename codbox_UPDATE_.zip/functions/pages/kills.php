﻿<?php

 $filemtime=filemtime($crn_kills);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_kills) != 0))
      if (time()-$filemtime < 31600)
			{	
				
if(filesize($crn_kills) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t1.s_kills+0)  DESC LIMIT 1');  
while ($row = $re->fetch())	
{	
    $kills = $row['s_kills'];
	$killer = $row['s_player'];
	$killer_guid = $row['s_guid'];
}  

 	$fpl = fopen($crn_kills, 'w+');
	fwrite($fpl, $killer_guid."%".$killer."%".$kills);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_kills);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$killer_guid = trim($infff[0]);		
$killer = trim($infff[1]);	
$kills = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 31600)
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t1.s_kills+0)  DESC LIMIT 1');  
while ($row = $re->fetch())	
{	
    $kills = $row['s_kills'];
	$killer = $row['s_player'];
	$killer_guid = $row['s_guid'];
}  

 	$fpl = fopen($crn_kills, 'w+');
	fwrite($fpl, $killer_guid."%".$killer."%".$kills);	
    fclose($fpl);
}

