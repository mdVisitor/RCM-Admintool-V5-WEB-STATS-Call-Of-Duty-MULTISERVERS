﻿<?php


 $filemtime=filemtime($crn_skill);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_skill) != 0))
      if (time()-$filemtime < 24600) 
			{	
				
if(filesize($crn_skill) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.w_skill+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $skill = $row['w_skill'];
	$skiller = $row['s_player'];
	$skiller_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_skill, 'w+');
	fwrite($fpl, $skiller_guid."%".$skiller."%".$skill);	
    fclose($fpl);
    }
	else
	{
		
$fpl = file($crn_skill);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$skiller_guid = trim($infff[0]);		
$skiller = trim($infff[1]);	
$skill = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 24600) 
{



$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.w_skill+0)  DESC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $skill = $row['w_skill'];
	$skiller = $row['s_player'];
	$skiller_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_skill, 'w+');
	fwrite($fpl, $skiller_guid."%".$skiller."%".$skill);	
    fclose($fpl);
}

