﻿<?php


 $filemtime=filemtime($crn_anti_skill);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_anti_skill) != 0))
      if (time()-$filemtime < 39600) 
			{	
				
if(filesize($crn_anti_skill) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.w_skill+0) ASC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $skill_anti = $row['w_skill'];
	$skiller_anti = $row['s_player'];
	$skiller_anti_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_anti_skill, 'w+');
	fwrite($fpl, $skiller_anti_guid."%".$skiller_anti."%".$skill_anti);	
    fclose($fpl);
    }
	else
	{
		
$fpl = file($crn_anti_skill);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$skiller_anti_guid = trim($infff[0]);		
$skiller_anti = trim($infff[1]);	
$skill_anti = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 39600) 
{



$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.w_skill+0) ASC LIMIT 1'); 
 
 while ($row = $re->fetch())	
{	
    $skill_anti = $row['w_skill'];
	$skiller_anti = $row['s_player'];
	$skiller_anti_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_anti_skill, 'w+');
	fwrite($fpl, $skiller_anti_guid."%".$skiller_anti."%".$skill_anti);	
    fclose($fpl);
}

