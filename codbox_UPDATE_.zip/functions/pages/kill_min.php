﻿<?php
$filemtime=filemtime($crn_kill_min);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_kill_min) != 0))
      if (time()-$filemtime < 7100)  //21600  6 hours   
			{	
				
if(filesize($crn_kill_min) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.n_kills_min+0)  DESC LIMIT 1');  
 
 
while ($row = $re->fetch())	
{	
    $n_kills_min = $row['n_kills_min'];
	$n_kills_minr = $row['s_player'];
	$n_kills_min_guid = $row['s_guid'];
}

 	$fpl = fopen($crn_kill_min, 'w+');
	fwrite($fpl, $n_kills_min_guid."%".$n_kills_minr."%".$n_kills_min);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_kill_min);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$n_kills_min_guid = trim($infff[0]);		
$n_kills_minr = trim($infff[1]);	
$n_kills_min = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 7100) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t2.n_kills_min+0)  DESC LIMIT 1');  
 
 
while ($row = $re->fetch())	
{	
    $n_kills_min = $row['n_kills_min'];
	$n_kills_minr = $row['s_player'];
	$n_kills_min_guid = $row['s_guid'];
}

 	$fpl = fopen($crn_kill_min, 'w+');
	fwrite($fpl, $n_kills_min_guid."%".$n_kills_minr."%".$n_kills_min);	
    fclose($fpl);
}
