﻿<?php

if(!empty($kills_limiter_top_cfg))
{
$kills_limiter_top = $kills_limiter_top_cfg;
}	
else
{
	if($kills_limiter_top < 1001)
		 $kills_limiter_top = 1000;
}	 


if (!empty($pgsearch))
  $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime,t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, 
t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_pg = "'.$pgsearch.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 	 
 else if (!empty($search_nicknamev)){
	 
$keyword=$search_nicknamev;	      
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_player LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   }
  
   
else if ($infomore=='min'){
	 
  $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_guid = "'.$finder.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 	 
 
}else if ($infomore=='max')
  $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_pg = "'.$search.'" LIMIT 1'); 
 
else if (!empty($search))
  $reponse = $bdd->query('SELECT t0.*, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_guid = "'.$search.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 	 
 
 else if (!empty($search_ip))
  $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_ip = "'.$search_ip.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
  
else if ((!empty($server))&&(!empty($search_time))){
	 
$keyword=$search_time;	      
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t0.s_lasttime LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   }   
else if (!empty($search_time)){
	 
$keyword=$search_time;	      
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_lasttime LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   } 
else if ((!empty($server))&&(!empty($search_heads)))
	$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_heads+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 
else if ((!empty($server))&&(!empty($search_skill))){
	
/*
$datetime = date('Y-m');
 $keyword=$datetime;	
	
	$sql = 'SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total; 
 
 $reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute(); 
*/ 
 
 
$datetime = date('Y-m');
 $keyword=$datetime;	
 
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,
	t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
	t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,
	t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,
	t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min,
    t5.sort	
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
 join 
 (SELECT sort, w_skill, s_pg
FROM
(
    SELECT @sort:=@sort + 1 AS sort, w_skill, s_pg
    FROM
    (
        SELECT db_stats_2.w_skill, db_stats_2.s_pg
        FROM db_stats_2
        INNER JOIN db_stats_1
        ON db_stats_2.s_pg = db_stats_1.s_pg
		INNER JOIN db_stats_0
        ON db_stats_1.s_pg = db_stats_0.s_pg
		        where db_stats_0.s_lasttime LIKE :keyword and db_stats_1.s_kills >= 1000
        ORDER BY w_skill DESC
    ) sub0
    CROSS JOIN (SELECT @sort:=0) sub2
) sub1
WHERE sub1.s_pg) 
 t5 ON 
 t0.s_pg = t5.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,
        n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute(); 
  
}
else if ((!empty($server))&&(!empty($search_ratiokd)))
{

	$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'"  and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_ratio+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  
 
 }
else if ((!empty($server))&&(!empty($search_deaths)))
  	$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'"  and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_deaths+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  
 
 

else if ((!empty($server))&&(!empty($search_kills)))
  $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 
else if ((!empty($server))&&(!empty($search_knife)))
 $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_melle+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
else if (!empty($server))
     $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  



else if (!empty($search_kills))
	
     $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 


else if (!empty($search_heads_percents))
	{
		
$prestigexll  = 9999;


$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,
 t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
 t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,
 t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,
 t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg, ROUND((s_heads) * 100.0 / s_kills, 1) AS Percent
FROM db_stats_1 where s_kills > 50 ORDER BY (Percent+0) DESC) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
t1.s_pg = t2.s_pg where t1.s_kills >= 50 and Percent >= 42  
ORDER BY (Percent+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 




/*	
$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,
	t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
	t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,
	t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,
	t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min,
    t5.sort	
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg, ROUND((s_heads) * 100.0 / s_kills, 1) AS Percent
FROM db_stats_1 where s_kills > 50) 
 t1 ON 
 t0.s_pg = t1.s_pg
 join 
 (SELECT sort, w_skill, s_pg
FROM
(
    SELECT @sort:=@sort + 1 AS sort, w_skill, s_pg
    FROM
    (
        SELECT db_stats_2.w_skill, db_stats_2.s_pg
        FROM db_stats_2
        INNER JOIN db_stats_1
        ON db_stats_2.s_pg = db_stats_1.s_pg
		INNER JOIN db_stats_0
        ON db_stats_1.s_pg = db_stats_0.s_pg
		        where db_stats_1.s_kills >= 50
        ORDER BY w_skill DESC
    ) sub0
    CROSS JOIN (SELECT @sort:=0) sub2
) sub1
WHERE sub1.s_pg) 
 t5 ON 
 t0.s_pg = t5.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,
        n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills >= 50 and Percent >= 42  
ORDER BY (Percent+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  
*/ 



 }
else if (!empty($search_deaths))
	$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_deaths and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_deaths+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 

	 
else if (!empty($search_ratiokd))
		 	$reponse = $bdd->query('SELECT t0.*, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_ratio and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_ratio+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 

else if (!empty($search_heads))
{
$datetime = date('Y-m');
 $keyword=$datetime;	
	
	$sql = 'SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_heads and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_heads+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total; 
 
 
 $reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
}	 
else if (!empty($search_skill))
{
/*	
$datetime = date('Y-m');
 $keyword=$datetime;	
	
	$sql = 'SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_skill and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total; 
 
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
*/


$datetime = date('Y-m');
 $keyword=$datetime;	
 
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,
	t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
	t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,
	t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,
	t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min,
    t5.sort	
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
 join 
 (SELECT sort, w_skill, s_pg
FROM
(
    SELECT @sort:=@sort + 1 AS sort, w_skill, s_pg
    FROM
    (
        SELECT db_stats_2.w_skill, db_stats_2.s_pg
        FROM db_stats_2
        INNER JOIN db_stats_1
        ON db_stats_2.s_pg = db_stats_1.s_pg
		INNER JOIN db_stats_0
        ON db_stats_1.s_pg = db_stats_0.s_pg
		        where db_stats_0.s_lasttime LIKE :keyword and db_stats_1.s_kills >= 1000
        ORDER BY w_skill DESC
    ) sub0
    CROSS JOIN (SELECT @sort:=0) sub2
) sub1
WHERE sub1.s_pg) 
 t5 ON 
 t0.s_pg = t5.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,
        n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute(); 


}
else if (!empty($search_grenades))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_grenade ORDER BY (s_grenade+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	 


else if (!empty($search_knife))
$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_melle and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_melle+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 


else if (!empty($search_suecides))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_suicids ORDER BY (s_suicids+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	 
else if (!empty($search_geo))
$reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_geo="'.$search_geo.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
else if (!empty($search_cfour))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_c4 ORDER BY (s_c4+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	

else if ((!empty($server)) && (!empty($paages)))
{

$datetime = date('Y-m');
 $keyword=$datetime;	
	
 $reponse = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
 
}
else
{	

/*
$datetime = date('Y-m');
 $keyword=$datetime;	
 
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
*/
$datetime = date('Y-m');
 $keyword=$datetime;	
 
	$sql='SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,
	t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
	t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,
	t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,
	t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min,
    t5.sort	
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
 join 
 (SELECT sort, w_skill, s_pg
FROM
(
    SELECT @sort:=@sort + 1 AS sort, w_skill, s_pg
    FROM
    (
        SELECT db_stats_2.w_skill, db_stats_2.s_pg
        FROM db_stats_2
        INNER JOIN db_stats_1
        ON db_stats_2.s_pg = db_stats_1.s_pg
		INNER JOIN db_stats_0
        ON db_stats_1.s_pg = db_stats_0.s_pg
		        where db_stats_0.s_lasttime LIKE :keyword and db_stats_1.s_kills >= 1000
        ORDER BY w_skill DESC
    ) sub0
    CROSS JOIN (SELECT @sort:=0) sub2
) sub1
WHERE sub1.s_pg) 
 t5 ON 
 t0.s_pg = t5.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,
        n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills and t0.s_lasttime LIKE :keyword and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
 
}
