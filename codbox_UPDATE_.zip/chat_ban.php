<?php
////error_reporting(0);
ini_set("display_errors",1);
error_reporting(E_ALL);
session_start(); 
$key = '';
$startx = microtime(true);

function hx($sc)
 {
  $sc = str_replace(array(
    "chat_ban.php"
  ), '', $sc);
  return $sc . "";
 }
$x_ff  = 0;
$cpath = hx(__FILE__);
include($cpath . "functions/geoip_bases/MaxMD/geoipcity.inc");
include($cpath . "functions/geoip_bases/MaxMD/timezone/timezone.php");
if (empty($_SESSION['username'])) 
	$_SESSION['username']=0;

if (!empty($_SESSION['username'])){
	$_GET['pass'] = $_SESSION['username'];
	 $passsword = $_SESSION['username'];	
}
 
if ((!empty($_GET['pass'])) && (!empty($_SESSION))) {
   $_POST['pass'] = $passsword;   
}
$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php"); 
include_once("functions/words.php"); 
include_once("functions/chatdb_archive.php"); 
include_once("functions/functions.inc.php"); include_once("langctrl.php");  
include_once("functions/geo.php"); 

//var_dump($geo_array);




if (empty($Msql_support))
$Msql_support = 0;
if (empty($host_adress))
    $host_adress = '0';
if (empty($db_name))
    $db_name   = '0';
if (empty($db_user))
    $db_user = '0';
if (empty($db_pass))
    $db_pass = '0';
if (empty($charset_db))
    $charset_db = '0';



if (!empty($passsword)){		
foreach ($steam_users_id as $passw => $xy){
  if(md5($passsword) == md5($passw))
  {
	  $key=1;
	  $xz = $xy;
  }
  
  }} else $key = '';	
  

if (is_numeric($key))
	$key = $key.'.1';
 
if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_x'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	
if(empty($Msql_support))
	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)(filesize($stats_db_path) / 1000000).' Мб';
else
{
	
try
{	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
    $sth = $bdd->query('SHOW TABLE STATUS');
    $sizeoff = $sth->fetch(PDO::FETCH_ASSOC)["Data_length"];

  
	
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}	

	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)($sizeoff / 1000000).' Мб';

}	
	}else $adminiinfo = '';	

if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_x'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php?adminpanel='.$xz.'" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">АдминПанель</a>
	<a href="'.$ssylka_na_codbox.'?logout=logout&lg#Logout!" onclick="location.reload()" style="color:#000;text-shadow:0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #ffa500, 0 0 7px #ffa500, 0 0 16px #ffa500, 0 0 40px #ffa500, 0 0 65px #ffa500;" >Logout!</a>';
}else 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">Логин</a>';


if (((!empty($_GET['logout'])) && (!empty($_SESSION['username']))) || ((!empty($_GET['logout'])) && (!empty($_COOKIE['user_online_x']))))
{	
echo 'Админ - '.$key.' вышел :)';
setcookie ( 'user_online_x', '', time()-2 );
session_destroy();
echo "<meta http-equiv='refresh' content='0'>";
}





       //$key=10000;
	   //$xz = $xy = 333333333;





$cache_time = 6;
             //header("Refresh:".$cache_time);
  
if (!empty($_GET['geo'])) 
   $geosearch = $_GET['geo']; 
else
  	$geosearch = 0;

if (!empty($_GET['archive'])) 
{
   $chatdbarc = $_GET['archive'];
   $chatdb_path = dirname( __FILE__ ) . '/chat_archive/'.$chatdbarc;   
}
   else
  	$chatdbarc = 0;

if (!empty($_GET['ip'])) 
   $search_ip = $_GET['ip']; 
else
  	$search_ip = 0;

if (!empty($_GET['st1'])) 
   $statusx1 = $_GET['st1']; 
else
  	$statusx1 = 0;

if (!empty($_GET['st2'])) 
   $statusx2 = $_GET['st2']; 
else
  	$statusx2 = 0;

if(empty($soob_na_page))   
$soob_na_page=40; 

if (!empty($_GET['search'])) 
   $searchplayername = $_GET['search']; 
else
  	$searchplayername = 0;

if (!empty($_GET['timeh'])) 
$timesearch = $_GET['timeh'];
else
  	$timesearch = 0;
  
   if (empty($_GET['page']))
     $cache_time = 30;
  else
   $paages = $_GET['page'];	  
 
  if (empty($_GET['server']))
  {
$cache_time = 30; 
$server = 0;
  }
   else
	$server = $_GET['server']; 

if (!empty($paages)){
	if($paages < 3)
  $cache_time = 30; 
    else
		$cache_time = 10*$paages;}

if (!empty($_GET['search']))
  $cache_time = 55; 

 
if (!empty($server))
		$cache_time = 25; 

if (empty($cache_time))
if (!empty($server))
	$cache_time = 10;

    $cc = round($cache_time, 0);       
    $xcache_time = $cc;
 
if(empty($key))
{
  $file = "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
  $filemd5 = md5($file); 
  $cache_file = $cache_folder."$filemd5.html";
  if (file_exists($cache_file)) {
   if ((time() - $cc) < filemtime($cache_file)) {
      echo file_get_contents($cache_file); 
	  echo "<!-- --------- Cached with $xcache_time seconds --------- -->";
      exit; 
    }
	}
  ob_start();
  }
  
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title>CHAT BAN | player list.</title>
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/recod-ru.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/demo.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/tooltip-classic.css" />
 
		<script type="text/javascript" src="<?php echo $ssylka_na_codbox;?>css_js/html2canvas.js"></script>
		
 <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		
		
		<!--[if IE]>
  		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->		
<style>
.flashing {
    animation-name: flash;
    animation-duration: 2s;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
	border: solid 1px #111;
	opacity: 0.5;	
}
@keyframes flash {
    0% { background: #000 url(img/search-icon.png) no-repeat 9px center; }
	10% { background: #222 url(img/search-icon.png) no-repeat 9px center; }
    20% { background: #444 url(img/search-icon.png) no-repeat 9px center; }
	30% { background: #555 url(img/search-icon.png) no-repeat 9px center; }
    40% { background: #666 url(img/search-icon.png) no-repeat 9px center; }
	50% { background: #888 url(img/search-icon.png) no-repeat 9px center; }
    60% { background: #666 url(img/search-icon.png) no-repeat 9px center; }
	70% { background: #555 url(img/search-icon.png) no-repeat 9px center; }
    80% { background: #444 url(img/search-icon.png) no-repeat 9px center; }
	90% { background: #222 url(img/search-icon.png) no-repeat 9px center; }
    100% { background: #000 url(img/search-icon.png) no-repeat 9px center; }
}
.button2 {
	background: #333 url(img/camera.png) no-repeat -1px center;
	padding: 0px 0px 0px 0px;
	width: 48px;
	height: 48px;
	border: solid 1px #000;
	-webkit-border-radius: 1em;
	-moz-border-radius: 1em;
	border-radius: 1em;
	-webkit-transition: all .5s;
	-moz-transition: all .5s;
	transition: all .5s;	
}
</style>


<style type="text/css">
.form-style-4{
	width: 190px;
	height:20px;
	font-size: 14px;
	border: 0px;
	margin:1px;
}
.form-style-4 input[type=submit],
.form-style-4 input[type=button],
.form-style-4 input[type=text],
.form-style-4 input[type=email],
.form-style-4 textarea,
.form-style-4 label
{
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 14px;
	color: #fff;

}
.form-style-4 label {
	display:block;
	margin-bottom: 1px;
}
.form-style-4 label > span{
	display: inline-block;
	float: left;
	width: 55px;
}
.form-style-4 input[type=text],
.form-style-4 input[type=email] 
{
	height:19px;
	background: transparent;
	border: none;
	border-bottom: 1px dashed #83A4C5;
	width: 55px;
	outline: none;
	font-style: italic;
}
.form-style-4 textarea{
	height:19px;
	font-style: italic;
	background: transparent;
	outline: none;
	border: none;
	border-bottom: 1px dashed #83A4C5;
	width: 45px;
	overflow: hidden;
	resize:none;
	height:24px;
}

.form-style-4 textarea:focus, 
.form-style-4 input[type=text]:focus,
.form-style-4 input[type=email]:focus,
.form-style-4 input[type=email] :focus
{
	border-bottom: 1px dashed #D9FFA9;
}

.form-style-4 input[type=submit],
.form-style-4 input[type=button]{
	background: #576E86;
	border: none;
	border-radius: 2px;
	color: #A8BACE;
}
.form-style-4 input[type=submit]:hover,
.form-style-4 input[type=button]:hover{
background: #394D61;
}
</style>


<?php 

if (!empty($_GET['theme']))
$_SESSION['theme'] = $_GET['theme'];


if (!empty($_SESSION['theme'])){
	$_GET['theme'] = $_SESSION['theme'];
}
else
	$_GET['theme'] = 'dark';



if (($_GET['theme']) == 'dark') {?>
<style>
body{
  transition:0;
  background-color:#141e21; /* #002600 */
  color:#2eb4e9;
  margin: 0;
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}

table{
 position:relative;	
}


.topbuttondark {
width:50px;
border:2px solid #ccc;
background:#f7f7f7;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#333;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }
else if (($_GET['theme'] == 'light')) {
?>
<style>
body{
  transition:0;
  background-color:#ddd; /* #002600 */
  color:#000;
  margin: 0;
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}


table{
 position:relative;		
}

.topbutton {
width:50px;
border:2px solid #ccc;
background:#333;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#fff;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }?>
  
  
<script>
var newTxt="<?php echo $title_migalka ?>";
var oldTxt=document.title;
 
function migalka(){
    if(document.title==oldTxt){
        document.title=newTxt;
    }else{
        document.title=oldTxt;
    }
}
 
var timer = setInterval(migalka,1000);
</script>


 <script>
 $(document).ready(function(){

        var $menu = $("#menu");

        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("default")
                           .addClass("fixed transbg")
                           .fadeIn('fast');
                });
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("fixed transbg")
                           .addClass("default")
                           .fadeIn('fast');
                });
            }
        });//scroll

        $menu.hover(
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).removeClass('transbg');
                }
            },
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).addClass('transbg');
                }
            });//hover
    });//jQuery
 </script>
	</head>
<body>

<script> 
addEventListener('click', function (event) {
    if (event.target.id == 'found') {
        
    }
}, true);
</script>
</br></br>
<div class="menuooo-center2">
 <div class="menuooo2">
<div id="menu">
        <ul>		
<?php		
		echo '<li>'.$adminpl.'</li>';
foreach ($ssylki_array as $arxx => $namessylka) {	
   echo '<li>| <a href="'.$arxx.'" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #FFF, 0 0 7px #990694, 0 0 18px #990694, 0 0 40px #990694, 0 0 65px #990694;" target="_blank">'.$namessylka.'</a></li>';   
} echo '</br>';		
	 $df = 0; 
 $dfx = 0;
foreach ($multi_servers_array as $arx => $xservername) {
	++$df;if($df > 10){echo '</br>'; $df = 0; ++$dfx;}	
						   $zx = explode("server_md5:", $arx);
						   $fld = $zx[1];
						   $server_md5 = strtok($fld, " ");
   echo '<li>| <a href="'.$ssylka_na_codbox.'chat_ban.php?server='.$server_md5.'">'.$xservername.'</a></li>';    
}
?>
        </ul>
	<?php
	
	echo '</div></div></div>';
	
if($dfx == 1)
echo '</br></br></br>';
else if($dfx == 2)
	echo '</br></br></br></br>';
else if($dfx == 3)
	echo '</br></br></br></br></br>';


?>
 <div id="blockx">
<div class="absolute-style">



<?php


if(!empty($key)){	
//if((empty($key)) || (empty($_COOKIE['user_online_x']))){

echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?archive='.$chatdbarc.'" style="padding-bottom: 40px;"> '. $main_servername . '</a>';

 if(!empty($key)){	 
	 
       $dawDe = "<span tooltip=\"".$take_screen."\"><a href=\"".$ssylka_na_codbox."upload/index.php\" 
onclick=\"window.open(this.href, '', 'scrollbars=1,height='+Math.min(350, screen.availHeight)+',width='+Math.min(590, screen.availWidth)); 
return false;\" style=\"color:".$cvet_text.";\"> <img src=\"".$ssylka_na_codbox."img/s_icon.png\" height=\"48px\" width=\"48px\"> </a></span>";	
?>
<span tooltip="Создать скриншот в один клик!">
<form class="button2" name="allsearch" method="get" action="<?php echo $ssylka_na_codbox;?>upload/index.php">
<input class="button2" type="button" onclick="screenshot();">
</form>
</span>
<form id="demo-b" name="allsearchkk" method="get">
<?php echo $dawDe;?> 
</form>
    <script type="text/javascript">
    function screenshot(){
        html2canvas(document.getElementById('container')).then(function(canvas) {
         //document.body.appendChild(canvas);
         // Get base64URL
		 
         var base64URL = canvas.toDataURL('image/jpeg', 0.9).replace('image/jpeg', 'image/octet-stream');
         // AJAX request
         $.ajax({
            url: 'ajaxfile.php',
            type: 'post',
            data: {image: base64URL},
            success: function(data){
               console.log('Upload successfully');
            }
         });
       });
     }
     </script>	 
   	<span tooltip="ИП адрес игрока, жмём Enter!" onClick="clearInterval(t)"> <a href="javascript:void(0);" onclick="viewdiv('mydiv');">
   <form id="demo-b">
 <input class="button flashing" type="search" name="ip">
  </form> </a></span>
  
  
  	<span tooltip="Гуид игрока, жмём Enter!" onClick="clearInterval(t)"> <a href="javascript:void(0);" onclick="viewdiv('mydiv');">
   <form id="demo-b">
 <input class="button flashing" type="search" name="guid">
  </form> </a></span>

<?php
 }
?>
   
	<span tooltip="Имя игрока, жмём Enter!" onClick="clearInterval(t)"> <a href="javascript:void(0);" onclick="viewdiv('mydiv');">
   <form id="demo-b">
 <input class="button flashing" type="search" name="search">
  </form> </a></span>
     
</div>		
</div>	



 <script type="text/javascript">
function viewdiv(id){
var el=document.getElementById(id);
if(el.style.display=="block"){
el.style.display="none";
} else {
el.style.display="block";
}
}
</script>
 
<?php	

if (empty($_GET['search']))
	
{ $search = 0;?>
 
<div id="timer">
     
                <div v-for="(group,key) in bTime" v-show="key !== 'h1' || group !== '0000'" class="flex-container flex bit-container">
                    <div v-for="bit in group" :class="['flex', 'bit', (bit === '1')?'lit':'']"></div>
                </div>
            </div>
			<h1><div class="abs-center time"><div id="mydiv" style="display:block;"> 
			<span id="time" ><!-- <span id="time" >10</span> --> <canvas id="DigiRain"></canvas> <canvas id=c></canvas></span>  
			</div></div></h1>
        <div class="rela-block flex-container button-container"><?php echo '&emsp;&emsp;'.$adminiinfo ?>
        </div>

<?php
}
else
$search = $_GET['search'];


 
echo '<br/><br/>
<div id="blockx">';


 $user_agent = $_SERVER["HTTP_USER_AGENT"];
  if (strpos($user_agent, "Firefox") !== false)  $browser = "Firefox";
  elseif (strpos($user_agent, "Opera") !== false) $browser = "Opera";
  elseif (strpos($user_agent, "Chrome") !== false) $browser = "Chrome";
  elseif (strpos($user_agent, "MSIE") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Safari") !== false) $browser = "Safari";
  else $browser = "Неизвестный";
  //echo "Ваш браузер: $browser ";
 if ((strpos($_SERVER["REQUEST_URI"], '/chat_ban.php?server=') !== false)||(strpos($_SERVER["REQUEST_URI"], '&main=0&server=2') !== false)) {
  
if($browser == "Firefox")
	echo '<br/><br/>';
else
	echo '<br/>';
  }else{
	  
if($browser == "Firefox")
	echo '<br/><br/>';
else
	echo '<br/>'; 
	  
  }


$psx = 0;
$psxz = 0;
$psxzl = 0;
if (!empty($search))
{
	//$search = trim($search);
  if(((23>(strlen($search))) && (18<(strlen($search)))) && (ctype_digit($search)))
  {
	   if (!empty($searchplayername))
	   $searchplayername = '';
	   $psx = 1;
  }
	   else if(!ctype_digit($search))
	   {
             $searchplayername = $search;
			 $_GET['search'] = $searchplayername;
			 $search= '';
			 echo '<br/><br/><br/>';
	   }
		 else{
			 $searchplayername = $search;
			 $_GET['search'] = $searchplayername;
              $search= '';	
              echo '<br/><br/><br/>';			  
	    }
}	
 echo '<center><h5> Example: in <b>Days...</b> +3 (+ 3 days) or in <b>Days...</b> (3 days) </h5></center>';
 
////////////////////////////////////////////////////////////////////////////////////				   
////////////////////////////////////////////////////////////////////////////////////
//////////////////////                                        ////////////////////// 
//////////////////////        CHAT SQLITE WALL ON SITE        ////////////////////// 			
//////////////////////                                        ////////////////////// 
////////////////////////////////////////////////////////////////////////////////////			
////////////////////////////////////////////////////////////////////////////////////	
//chmod($chatdb_path, 0666);
$chatdb = $chatdb_path;


 
try
{

  
	  
	  if(empty($Msql_support))
    $bdd = new PDO('sqlite:' . $chatdb);
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    
    $bdd = new PDO($dsn, $db_user, $db_pass);				  	  
	  }
//$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //отрубает базу при ошибке + в лог
//$bdd->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );   //продолжает работу, идет откладка в лог


$а = 0;
$xpip = 0;
$number_of_rows = 0;
$limitswplus = 0;

/*
$query = $bdd->query("SELECT COUNT(*) as count FROM x_db_players");
$query->setFetchMode(PDO::FETCH_ASSOC);
$row = $query->fetch();
$members = $row['count']; 
 */
 
 
 
 
 
 
 
if (!empty($_GET['status']))
{	
   $statusw = $_GET['status'];
   
} 
else
  	$statusw = 0; 

if ($statusw == 1)
	$statusw = 0;

 
if (!empty($_GET['limits'])) 
{
   $limitsw = $_GET['limits'];
}   
else
  	$limitsw = 0;  


if (!empty($_GET['guidstatus'])) 
   $guidstatus = $_GET['guidstatus']; 
else
  	$guidstatus = 0;


if((empty($limitsw))&&(!empty($statusw)))
{
if (!empty($guidstatus))
	$guidt = $guidstatus;

    $guidstatus = 0;
	$guidw = 0;
	$statuswu = $statusw; 
	$limitsw = 0;
	$statusw = 0;
}

$plusstatus = 0;
$status1days = 0;
 if (strpos($limitsw, "+") !== false)
 {
$guidw = $guidstatus;
$reponse = $bdd->query("SELECT status1days,status FROM chat_ban where guid = $guidw");
while ($dannye = $reponse->fetch())	
{	
$status1days = $dannye['status1days'];
$statusw = $dannye['status'];
}

$plusstatus = 1; 

$limitswbbb = str_replace("+", "", $limitsw);
 $limitswplus = $status1days+$limitsw;

 }
 else
 {
$plusstatus = 0;
 }



	 
 
 
 
 
if (!empty($guidstatus)) 
{
   $guidw = $guidstatus;
$date = date('Y-m-d H:i:s');


  if(!empty($limitswbbb))
$totaldd = $status1days+$limitswbbb;
else
	$totaldd = $status1days;



if(empty($plusstatus))
  $dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	
else
	$dateend = date('Y-m-d', strtotime($date. ' + '.$totaldd.' days'));	





if(!empty($guidw))
{

if(empty($statusw)){
	$reponse = $bdd->query("SELECT status1days,status,guid FROM chat_ban where guid = $guidw limit 1");
while ($dannye = $reponse->fetch())	
{	
$status1days = $dannye['status1days'];
$statusw = $dannye['status1'];

}

}	
$rp = $bdd->query("SELECT id FROM chat_ban where guid = '".$guidw."'")->rowCount();
}
if(!empty($_GET['guidstatus']))
{

if(empty($statusw)){
	$reponse = $bdd->query("SELECT status1days,status,guid FROM chat_ban where guid = '".$_GET['guidstatus']."' limit 1");
while ($dannye = $reponse->fetch())	
{	
$status1days = $dannye['status1days'];
$statusw = $dannye['status'];

}
}	
$rp = $bdd->query("SELECT id FROM chat_ban where guid = '".$_GET['guidstatus']."'")->rowCount();
}
	
	 
	
	//echo $limitswplus.$rp.$statusw;
	
	 
	
	
if(empty($rp)){
	if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	
 $bdd->exec("INSERT INTO chat_ban (guid,time,timeh,status,status1days)
 VALUES ('$guidw','$dateend',CURRENT_TIME(),'$statusw','$limitsw')");
}
else if((!empty($rp))&&(!empty($plusstatus))) 
{
	if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	
 $bdd->query("UPDATE chat_ban SET time='{$dateend}', status='{$statusw}', status1days='{$limitswplus}' WHERE guid = $guidw");
}
else if((!empty($rp))&&(!empty($limitswplus)))
{	

if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	

 $bdd->query("UPDATE chat_ban SET time='{$dateend}', status='{$statusw}', status1days='{$limitswplus}' WHERE guid = $guidw");
}
else if((!empty($rp))&&(!empty($limitsw)))
{

if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	

 $bdd->query("UPDATE chat_ban SET time='{$dateend}', status='{$statusw}', status1days='{$limitsw}' WHERE guid = $guidw");
}
else if((!empty($rp))&&(!empty($statusw)))
{

if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	

 $bdd->query("UPDATE chat_ban SET time='{$dateend}', status='{$statusw}', status1days='{$limitsw}' WHERE guid = $guidw");
 
}else{
	if($statusw=='Ban')
	$statusw = 1;
else if($statusw=='Unban')
	$statusw = 0;	
 $bdd->query("UPDATE chat_ban SET time='{$dateend}', status='{$statusw}', status1days='{$limitsw}' WHERE guid = $guidw");	 
 
}
 
 
 
 
 
}  
else if(!empty($guidt)){
	
	

	
	
if(!empty($statuswu)){

if($statuswu=='Ban')
	$statuswu = 1;
else if($statuswu=='Unban')
	$statuswu = 0;	
	
$rp = $bdd->query("SELECT id FROM chat_ban where guid = $guidt")->rowCount();
 if(!empty($rp))
 $bdd->query("UPDATE chat_ban SET status='{$statuswu}' WHERE guid = $guidt");	
} 
} 
else
  	$guidw = 0;   
 

 
 
 
 if(!empty($_GET['search']))
$getsearch = $_GET['search'];
 
 
 
  if (!empty($_GET['search'])) 
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_name  = '".$getsearch."'")->rowCount();
else if (!empty($_GET['guid']))
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_guid  = '".$_GET['guid']."'")->rowCount();
//else if (!empty($_GET['server']))
//$reponse = $bdd->query("SELECT id FROM x_db_players where s_port  = '".$_GET['server']."'")->rowCount();
else if (!empty($_GET['ip']))
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_ip  = '".$_GET['ip']."'")->rowCount();	
else
	$reponse = $bdd->query('SELECT id FROM x_db_players')->rowCount();


$kolichestvi_soobsh=$reponse;

$nb_pages = ceil($kolichestvi_soobsh / $soob_na_page); 
echo '<div align="center">';
 
if (isset($_GET['page'])){$page = $_GET['page']; }else {$page = 1; }
$premierMessageAafficher = ($page - 1) * $soob_na_page;


  if (!empty($_GET['search']))
  {
$keyword=$getsearch;
  
//$reponse = $bdd->query('SELECT * FROM x_db_players where x_db_name LIKE :keyword ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page); 

$sql = 'SELECT t0.*, t1.*
   from x_up_players t0 
   join
 (select x_db_name, x_up_name, x_db_ip, x_up_ip, x_db_ping, x_db_guid, x_db_conn, x_db_date, x_db_warn, x_date_reg, stat from x_db_players) 
 t1 ON 
 t1.x_db_guid = t0.guid where t0.name LIKE :keyword ORDER BY t1.id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;

$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
  }
  else if (!empty($_GET['guid']))	  
 //$reponse = $bdd->query('SELECT * FROM x_db_players where x_db_guid = "'.$_GET['guid'].'" ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);


$reponse = $bdd->query('SELECT t0.*, t1.*
   from x_db_players t0 
   join
 (select * from x_up_players) 
 t1 ON 
 t0.x_db_guid = t1.guid where t1.guid = "'.$_GET['guid'].'" ORDER BY t0.id  DESC LIMIT 1');




// else if (!empty($_GET['server']))	  
// $reponse = $bdd->query('SELECT * FROM x_db_players where s_port = "'.$_GET['server'].'" ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);  
  else if (!empty($_GET['ip']))
 $reponse = $bdd->query('SELECT * FROM x_db_players where x_db_ip = "'.$_GET['ip'].'" ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);
else
  $reponse = $bdd->query('SELECT * FROM x_db_players ORDER BY id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);
 
 
 echo '<table border="0" id="container">';
 $i=0;
 $ssssob = 0;
 
 $pixelz = 0;
while ($dannye = $reponse->fetch())	
{	
$xplid = $dannye['id'];

if (empty($_GET['guid']))
$xplayerip = $dannye['x_db_ip'];
else
$xplayerip = $dannye['ip'];	
 
if (empty($_GET['guid'])) 
$xpnickname = $dannye['x_db_name'];
 else
$xpnickname = $dannye['name'];


$upname = $dannye['x_up_name'];
$guidxx = $dannye['x_db_guid'];
$txt = $dannye['x_db_conn'];
//$geo = $dannye['geo'];

if(!empty($status1time))
	$status1time = ' ';

if(!empty($status1))
	$status1 = ' - ';

if(!empty($status1days))
	$status1days = 'Days...';

 $repi = $bdd->query('SELECT * FROM chat_ban where guid = "'.$guidxx.'" LIMIT 1');
 while ($d = $repi->fetch())	
{
			$status1 = $d['status'];
			$status1days = $d['status1days'];
			$status1time = $d['time'];
}

if(empty($status1))
	$status1 = ' - ';

if(empty($status1days))
	$status1days = 'Days...';

if(empty($status1time))
	$status1time = ' ';


                        $gi     = geoip_open($cpath .  "functions/geoip_bases/MaxMD/GeoLiteCity.dat", GEOIP_STANDARD);
                        $record = geoip_record_by_addr($gi, $xplayerip);


						if(!empty($record)){
							  $xxxnnn = ($record->country_name);     
                        
                          $xxxnw = ($record->country_name . ", " . $record->city . "");
                        $xxccode = ($record->country_code);
						}

	if(empty($xxccode))
		$xxccode = '-';
	if(empty($xxxnnn))
	  $xxxnnn = '-';     
    if(empty($xxxnw))
      $xxxnw = '-';  	
	
	
	
$geo = $xxccode;
$fullgeo = $geo;












	if($i == 0) 
	{	//echo "<center><a href='index.php'><h1 style=\"font-family: Impact, fantasy;\">" . colorize($main_servername) . "</h1></a></center>";	

          
               if (!empty($kolichestvi_soobsh))
				echo "<h2>".$t_players."- ". $kolichestvi_soobsh." </h2>";
			

            if (!empty($_GET['server']))
				echo "<h2>Server port - ". $server." </h2>";
			
            

	echo "<tr>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;&emsp;</center></td>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;Id&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;Guid&emsp;</center></td>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;".$t_nickname."&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> <b>".$t_time." </b></center></td>
	  <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> <b>".$t_city." </b></center></td>
	  
	 <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> &emsp;<b> Status &emsp;/ Days &emsp;/ Update &emsp; </b></center></td>
	 
	 <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> &emsp;<b> Time </b></center></td>
	    
	  ";
	  
	echo "</tr>";		
	}
	
$i++;	
$ssssob = $i;
//$geo = mb_strtolower($geo);
          
		  
			   

	echo "<tr>";


    $tm = str_replace(".", "-", $dannye['x_db_date']);
	$tm = trim($tm);
	
	if(empty($raznica_vremya_admin))
	$raznica_vremya_admin = '-1';
	
	if($geo == 'zag')
      $tm = $tm.'';
    else
		$tm = date( "Y-m-d H:i:s", strtotime( $tm." ".$raznica_vremya." hour" ) );
	
	$xxtime = trim($tm);
    $tm = str_replace("-", ".", $tm);
	
	$tm = time_elapsed_string($xxtime);
	//$db_date = new DateTime($xxtime);
    //$unix_db_date = $db_date->getTimestamp();
    //$tm = getDateString($unix_db_date);
	
	$ttim = $dannye['x_date_reg'];
 
 
 
 
 
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\">&emsp; 
	
	  <span tooltip=\"Player in Chat\"><a href=\"".$ssylka_na_codbox."chat.php?search=".$guidxx."\" target=\"_blank\"><img src=\"".$ssylka_na_codbox."/img/chat.svg\" width=\"24\" height=\"15\" alt=\"chat\"></a></span>   </td>";
	

echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	  <span tooltip=\"Player in Stats\"><a href=\"".$ssylka_na_codbox."stats.php?search=".$guidxx."\" target=\"_blank\"><img src=\"".$ssylka_na_codbox."/img/stats.svg\" width=\"24\" height=\"15\" alt=\"chat\"></a></span>   </td>";
	 
  
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp; <b style=\"color:".$cvet_ip.";\">" .  $xplid . "&emsp;</b>   </td>";
  
 
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp;<a href=\"".$ssylka_na_codbox."chat_ban.php?guid=".$guidxx."&archive=". $chatdbarc."\"><b style=\"color:".$cvet_ip.";\">" .  $guidxx . "&emsp;</b> </a>  </td>";
 
  
 	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp;<a href=\"".$ssylka_na_codbox."chat_ban.php?search=".$xpnickname."&archive=". $chatdbarc."\"><b style=\"color:Silver;\">" . $xpnickname . "&emsp;</b> </a>  </td>";
 
  
 
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	<span tooltip=\"".$xxtime." || ".$dannye['x_date_reg']."\">&nbsp;<a href=\"".$ssylka_na_codbox."?timeh=".$ttim."&archive=". $chatdbarc."\"><b style=\"color:".$cvet_date_time.";\">" . $tm . "&emsp;</b> </a> </span>  </td>";
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\">";
	
	
	
	
/*	
	
foreach($geo_array as $arrr => $sd)
{
    foreach($sd as $w => $geon)
    {
		if($geo == $geon)
		{
	    ////ENG		
        //echo "<br/>".$sd[2].' => '.$geon;
	    $fullgeo = $sd[2];
	    }
    
	}	
	
}	
*/	
	
	if(!empty($geo))
	  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?geo='.$geo.'&archive='. $chatdbarc.'"><span tooltip="'.$xxxnw.'"> <img src="'.$ssylka_na_codbox.'/flags-mini/'.$geo.'.png" width="24" height="12" alt="'.$xxxnw.'"></span></a>';
	else{
/*	*/		
////////////////////////////////////////////// 
 if((($psxz < 20)&&(!empty($Msql_support)))||(($psxz < 40)&&(empty($Msql_support)))){
 $oss=$bdd ->query("SELECT * From chat where x='1' and guid='$guidxx' limit 1");
while ($xnc = $oss->fetch())
{ 
   if((!empty($xnc['geo']))||(!empty($xnc['ip'])))
   {
	   ++$psxz;
	   ++$psxzl;
   $strana = $xnc['geo']; 
   $ipaddr = $xnc['ip'];
   
   	/// + псевдо загрузка флагов
	echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?geo='.$strana.'&archive='.$chatdbarc.'"><span tooltip="'.$strana.'"><img src="'.$ssylka_na_codbox.'/flags-mini/'.$strana.'.png" width="24" height="12" alt="'.$strana.'"></span></a>';
   
   //if($psxzl < 2)
   //$bdd->exec("UPDATE chat SET geo='$strana', ip='$ipaddr',x='1' WHERE guid='$guidxx' and z='0'");
  
   }
 }
	}
	}
    




	
  
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;
 height:24px;line-height:22px;margin:0;padding:0;\">";
echo '<form class="form-style-4"  method="get"  action="chat_ban.php">	
	<select style="background:' . ($i % 2 ? '#111' : '#222') .';color: Silver;width:55px; height:20px;line-height:22px;" name="status">
	
	<option label="Ban" value="1" selected>'.$status1.'</option>
	<option>Unban</option>
    <option>Ban</option>
	<input style="opacity: 0.6;" name="limits" type="text" placeholder="&nbsp;&nbsp;'.$status1days.'" size="8">
	<input id="guidstatus" name="guidstatus" type="hidden" value="'.$guidxx.'">
</select>
<input type="submit" value="Update" />
</form>'; 
 echo "</td>";	
  
  echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
 <b style=\"color:".$cvet_ip.";\">" .   $status1time . "&emsp;</b></td>";
 
  
		if(empty($key))	{
		 $txtemptycnt = substr_count($txt,' ');	
		 if((strlen($txt) > 70) && ($txtemptycnt < 3))
		 $txt = strlen($txt) > 35 ? substr($txt,0,35)."...." : $txt;
	    }
	  
		 $txt = wordwrap($txt, 60, "</br>&emsp;", 1);
 
		 if(empty($Msql_support))
		  $txt = iconv("windows-1251", "utf-8",$txt);
	   
			
	}

echo '</table>';	



if (!$reponse) {
    echo "\nPDO::errorInfo():\n";
    print_r($bdd->errorInfo());
}

$reponse->closeCursor();
$reponse = null;
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}


$fff = $soob_na_page - $ssssob;

$t = 0;
for ($i = 1 ; $i <= $nb_pages ; $i++)
{
    $t++;
	
	if (empty($search)){
		
		if (($nb_pages == $page) && ($nb_pages == $t))
		{
			  
			for ($k = 1 ; $k <= $fff; $k++)
			{
		 if($soob_na_page < $ssssob + 10)
		  echo '</br>';
	        }
		 
		 }
	}	
}	

echo '<br/><div class="footerx"><div class="footer">';

if (is_numeric($key))	
$pageskey = '<a href="'.$ssylka_na_codbox.'chat_ban.php?pass=' . $passsword .'&server=' . $server .'&search=' . $search .'&geo=' . $geosearch .'&timeh=' . $timesearch .'&st1=' . $statusx1 .'&st2=' . $statusx2 .'&ip=' . $search_ip.'&archive=' . $chatdbarc.'&page=';    
 else
$pageskey = '<a href="'.$ssylka_na_codbox.'chat_ban.php?server=' . $server .'&search=' . $search .'&geo=' . $geosearch .'&timeh=' . $timesearch .'&st1=' . $statusx1 .'&st2=' . $statusx2.'&page=';


// Проверяем нужны ли стрелки назад
if ($page != 1) $pervpage = $pageskey.'1">Первая</a> | '.$pageskey.($page - 1).'">Предыдущая</a> | ';
// Проверяем нужны ли стрелки вперед
if ($page != $nb_pages) $nextpage = ' | '.$pageskey. ($page + 1) .'">Следующая</a> | '.$pageskey.$nb_pages. '">Последняя</a>';

// Находим две ближайшие станицы с обоих краев, если они есть
if($page - 8 > 0) $page8left = ' '.$pageskey. ($page - 8) .'">'. ($page - 8) .'</a> | ';
if($page - 7 > 0) $page7left = ' '.$pageskey. ($page - 7) .'">'. ($page - 7) .'</a> | ';
if($page - 6 > 0) $page6left = ' '.$pageskey. ($page - 6) .'">'. ($page - 6) .'</a> | ';
if($page - 5 > 0) $page5left = ' '.$pageskey. ($page - 5) .'">'. ($page - 5) .'</a> | ';
if($page - 4 > 0) $page4left = ' '.$pageskey. ($page - 4) .'">'. ($page - 4) .'</a> | ';
if($page - 3 > 0) $page3left = ' '.$pageskey. ($page - 3) .'">'. ($page - 3) .'</a> | ';
if($page - 2 > 0) $page2left = ' '.$pageskey. ($page - 2) .'">'. ($page - 2) .'</a> | ';
if($page - 1 > 0) $page1left = $pageskey. ($page - 1) .'">'. ($page - 1) .'</a> | ';

if($page + 8 <= $nb_pages) $page8right = ' | '.$pageskey. ($page + 8) .'">'. ($page + 8) .'</a>';
if($page + 7 <= $nb_pages) $page7right = ' | '.$pageskey. ($page + 7) .'">'. ($page + 7) .'</a>';
if($page + 6 <= $nb_pages) $page6right = ' | '.$pageskey. ($page + 6) .'">'. ($page + 6) .'</a>';
if($page + 5 <= $nb_pages) $page5right = ' | '.$pageskey. ($page + 5) .'">'. ($page + 5) .'</a>';
if($page + 4 <= $nb_pages) $page4right = ' | '.$pageskey. ($page + 4) .'">'. ($page + 4) .'</a>';
if($page + 3 <= $nb_pages) $page3right = ' | '.$pageskey. ($page + 3) .'">'. ($page + 3) .'</a>';
if($page + 2 <= $nb_pages) $page2right = ' | '.$pageskey. ($page + 2) .'">'. ($page + 2) .'</a>';
if($page + 1 <= $nb_pages) $page1right = ' | '.$pageskey. ($page + 1) .'">'. ($page + 1) .'</a>';

// Вывод меню если страниц больше одной

if ($nb_pages > 1)
{
Error_Reporting(E_ALL & ~E_NOTICE);
echo "<div class=\"pstrnav\">";
echo $pervpage.$page7left.$page6left.$page5left.$page4left.$page3left.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$page3right.$page4right.$page5right.$page6right.$page7right.$nextpage;
echo "</div>";
}


echo "</br><span style=\"color:#006699;text-decoration:underline;cursor:pointer;font-size:11px;\" onclick=\" document.getElementById('instruction').style.display = (document.getElementById('instruction').style.display=='none'?'inline':'none');\">
                Все страницы</span>";
echo '<div id="instruction" style="display: none; width: 100%;"></br></br>';	

$t = 0;
for ($i = 1 ; $i <= $nb_pages ; $i++)
{
    $t++;
		$pi = $i;
		
	  if(!empty($_GET['page']))
		if(($_GET['page']) == $i)        // font-size: 18px;
			$pi = '<b class="flashingf">&nbsp;'.$i.'&nbsp;</b>';             	
if(!empty($searchplayername))
	$searchplayername = $search;
echo '&nbsp;'.$pageskey.$i.'">' . $pi.  ' </a> ';       
		}
echo '</div>';
		
echo '</br></br> <a href="#" style="font-size:13px; font-family: Ariel;">'.$t_gen.': ' . ( microtime(true) - $startx ) . ' '.$t_tsek.' </a>';
	if(empty($key))
echo "</br> <a href=\"#\" style=\"font-size:13px; font-family: Ariel;\">$t_cachedw $xcache_time $t_tsek</a>";

 
include_once("footer.php"); 
echo '</div></div></br>';

if (($_GET['theme']) == 'light') 
  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?theme=dark" title="Вернуться к началу" class="topbutton">Style</a>';
else
  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?theme=light" title="Вернуться к началу" class="topbuttondark">Style</a>'; 

echo '</br></br>  
<!--RECOD.RU Call Of duty game series chat parser by LA|ROCCA --> ';
/*
if(empty($key))
{
 $handle = fopen($cache_file, 'w'); // Открываем файл для записи и стираем его содержимое
  fwrite($handle, ob_get_contents()); // Сохраняем всё содержимое буфера в файл
  fclose($handle); // Закрываем файл
  ob_end_flush(); // Выводим страницу в браузере 
}
*/

 }
 else
 {
	


































































































































































































































































































































//if((empty($key)) || (empty($_COOKIE['user_online_x']))){

echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?archive='.$chatdbarc.'" style="padding-bottom: 40px;"> '. $main_servername . '</a>';
 
	 
       $dawDe = "<span tooltip=\"".$take_screen."\"><a href=\"".$ssylka_na_codbox."upload/index.php\" 
onclick=\"window.open(this.href, '', 'scrollbars=1,height='+Math.min(350, screen.availHeight)+',width='+Math.min(590, screen.availWidth)); 
return false;\" style=\"color:".$cvet_text.";\"> <img src=\"".$ssylka_na_codbox."img/s_icon.png\" height=\"48px\" width=\"48px\"> </a></span>";	
?>
  
</div>		
</div>	


<?php	

if (empty($_GET['search']))
	
{ $search = 0;?>
 
<div id="timer">
     
                <div v-for="(group,key) in bTime" v-show="key !== 'h1' || group !== '0000'" class="flex-container flex bit-container">
                    <div v-for="bit in group" :class="['flex', 'bit', (bit === '1')?'lit':'']"></div>
                </div>
            </div>
			<h1><div class="abs-center time"><div id="mydiv" style="display:block;"> 
			<span id="time" ><!-- <span id="time" >10</span> --> <canvas id="DigiRain"></canvas> <canvas id=c></canvas></span>  
			</div></div></h1>
        <div class="rela-block flex-container button-container"><?php echo '&emsp;&emsp;'.$adminiinfo ?>
        </div>

<?php
}
else
$search = $_GET['search'];


 
echo '<br/><br/>
<div id="blockx">';


 $user_agent = $_SERVER["HTTP_USER_AGENT"];
  if (strpos($user_agent, "Firefox") !== false)  $browser = "Firefox";
  elseif (strpos($user_agent, "Opera") !== false) $browser = "Opera";
  elseif (strpos($user_agent, "Chrome") !== false) $browser = "Chrome";
  elseif (strpos($user_agent, "MSIE") !== false) $browser = "Internet Explorer";
  elseif (strpos($user_agent, "Safari") !== false) $browser = "Safari";
  else $browser = "Неизвестный";
  //echo "Ваш браузер: $browser ";
 if ((strpos($_SERVER["REQUEST_URI"], '/chat_ban.php?server=') !== false)||(strpos($_SERVER["REQUEST_URI"], '&main=0&server=2') !== false)) {
  
if($browser == "Firefox")
	echo '<br/>';
else
	echo '<br/>';
  }else{
	  
if($browser == "Firefox")
	echo '<br/>';
else
	echo '<br/>'; 
	  
  }


$psx = 0;
$psxz = 0;
$psxzl = 0;
if (!empty($search))
{
	//$search = trim($search);
  if(((23>(strlen($search))) && (18<(strlen($search)))) && (ctype_digit($search)))
  {
	   if (!empty($searchplayername))
	   $searchplayername = '';
	   $psx = 1;
  }
	   else if(!ctype_digit($search))
	   {
             $searchplayername = $search;
			 $_GET['search'] = $searchplayername;
			 $search= '';
			 echo '<br/><br/><br/>';
	   }
		 else{
			 $searchplayername = $search;
			 $_GET['search'] = $searchplayername;
              $search= '';	
              echo '<br/><br/><br/>';			  
	    }
}	
 echo '<center><h1> CHAT MUTE BANLIST </h1></center>';
 
////////////////////////////////////////////////////////////////////////////////////				   
////////////////////////////////////////////////////////////////////////////////////
//////////////////////                                        ////////////////////// 
//////////////////////        CHAT SQLITE WALL ON SITE        ////////////////////// 			
//////////////////////                                        ////////////////////// 
////////////////////////////////////////////////////////////////////////////////////			
////////////////////////////////////////////////////////////////////////////////////	
//chmod($chatdb_path, 0666);
$chatdb = $chatdb_path;


 
try
{

  
	  
	  if(empty($Msql_support))
    $bdd = new PDO('sqlite:' . $chatdb);
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    
    $bdd = new PDO($dsn, $db_user, $db_pass);				  	  
	  }
//$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //отрубает базу при ошибке + в лог
//$bdd->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );   //продолжает работу, идет откладка в лог


$а = 0;
$xpip = 0;
$number_of_rows = 0;
$limitswplus = 0;

/*
$query = $bdd->query("SELECT COUNT(*) as count FROM x_db_players");
$query->setFetchMode(PDO::FETCH_ASSOC);
$row = $query->fetch();
$members = $row['count']; 
 */
    
 

 
 
 
 if(!empty($_GET['search']))
$getsearch = $_GET['search'];
 
 
 
  if (!empty($_GET['search'])) 
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_name  = '".$getsearch."'")->rowCount();
else if (!empty($_GET['guid']))
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_guid  = '".$_GET['guid']."'")->rowCount();
//else if (!empty($_GET['server']))
//$reponse = $bdd->query("SELECT id FROM x_db_players where s_port  = '".$_GET['server']."'")->rowCount();
else if (!empty($_GET['ip']))
$reponse = $bdd->query("SELECT id FROM x_db_players where x_db_ip  = '".$_GET['ip']."'")->rowCount();	
else
	$reponse = $bdd->query('SELECT id FROM x_db_players')->rowCount();


$kolichestvi_soobsh=$reponse;

$nb_pages = ceil($kolichestvi_soobsh / $soob_na_page); 
echo '<div align="center">';
 
if (isset($_GET['page'])){$page = $_GET['page']; }else {$page = 1; }
$premierMessageAafficher = ($page - 1) * $soob_na_page;


  if (!empty($_GET['search']))
  {
$keyword=$getsearch;
  
//$reponse = $bdd->query('SELECT * FROM x_db_players where x_db_name LIKE :keyword ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page); 

$sql = 'SELECT t0.*, t1.*
   from x_up_players t0 
   join
 (select x_db_name, x_up_name, x_db_ip, x_up_ip, x_db_ping, x_db_guid, x_db_conn, x_db_date, x_db_warn, x_date_reg, stat from x_db_players) 
 t1 ON 
 t1.x_db_guid = t0.guid where t0.name LIKE :keyword ORDER BY t1.id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;

$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
  }
  else if (!empty($_GET['guid']))	  
  {//$reponse = $bdd->query('SELECT * FROM x_db_players where x_db_guid = "'.$_GET['guid'].'" ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);

 

$reponse = $bdd->query('SELECT t0.*, t1.*
   from x_db_players t0 
   join
 (select guid,time,timeh,status1days,status from chat_ban) 
 t1 ON 
 t1.guid = t0.x_db_guid where t1.guid = "'.$_GET['guid'].'" ORDER BY t0.id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);


  // else if (!empty($_GET['server']))	  
  // $reponse = $bdd->query('SELECT * FROM x_db_players where s_port = "'.$_GET['server'].'" ORDER BY id DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);  
  }
  else if (!empty($_GET['ip']))
	{  

$reponse = $bdd->query('SELECT t0.*, t1.*
   from x_db_players t0 
   join
 (select guid,time,timeh,status1days,status from chat_ban) 
 t1 ON 
 t1.guid = t0.x_db_guid where x_db_ip = "'.$_GET['ip'].'" ORDER BY t0.id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);




}
else
{ 

//SELECT *, DATEDIFF(timeh , NOW()) AS diff FROM chat_ban where guid = "playerGUID" ORDER BY timeh ASC
//echo row['diff']

$reponse = $bdd->query('SELECT t0.*, t1.*
   from x_db_players t0 
   join
 (select guid,time,timeh,status1days,status from chat_ban) 
 t1 ON 
 t1.guid = t0.x_db_guid ORDER BY t0.id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);

//$reponse = $bdd->query('SELECT * FROM x_db_players ORDER BY id  DESC LIMIT ' . $premierMessageAafficher . ', ' . $soob_na_page);
 
}
 echo '<table border="0" id="container">';
 $i=0;
 $ssssob = 0;
 
 $pixelz = 0;
while ($dannye = $reponse->fetch())	
{	
$xplid = $dannye['id'];

if (empty($_GET['guid']))
$xplayerip = $dannye['x_db_ip'];
else
$xplayerip = $dannye['ip'];	
 
if (empty($_GET['guid'])) 
$xpnickname = $dannye['x_db_name'];
 else
$xpnickname = $dannye['name'];


$upname = $dannye['x_up_name'];
$guidxx = $dannye['x_db_guid'];
$txt = $dannye['x_db_conn'];
//$geo = $dannye['geo'];

if(!empty($status1time))
	$status1time = ' ';

if(!empty($status1))
	$status1 = ' - ';

if(!empty($status1days))
	$status1days = 'Days...';

 $repi = $bdd->query('SELECT * FROM chat_ban where guid = "'.$guidxx.'" LIMIT 1');
 while ($d = $repi->fetch())	
{
			$status1 = $d['status'];
			$status1days = $d['status1days'];
			$status1time = $d['time'];
}

if(empty($status1))
	$status1 = ' - ';

if(empty($status1days))
	$status1days = 'Days...';

if(empty($status1time))
	$status1time = ' ';


                        $gi     = geoip_open($cpath .  "functions/geoip_bases/MaxMD/GeoLiteCity.dat", GEOIP_STANDARD);
                        $record = geoip_record_by_addr($gi, $xplayerip);


						if(!empty($record)){
							  $xxxnnn = ($record->country_name);     
                        
                          $xxxnw = ($record->country_name . ", " . $record->city . "");
                        $xxccode = ($record->country_code);
						}

	if(empty($xxccode))
		$xxccode = '-';
	if(empty($xxxnnn))
	  $xxxnnn = '-';     
    if(empty($xxxnw))
      $xxxnw = '-';  	
	
	
	
$geo = $xxccode;
$fullgeo = $geo;












	if($i == 0) 
	{	//echo "<center><a href='index.php'><h1 style=\"font-family: Impact, fantasy;\">" . colorize($main_servername) . "</h1></a></center>";	

          
               if (!empty($kolichestvi_soobsh))
				echo "<h2>".$t_players."- ". $kolichestvi_soobsh." </h2>";
			

            if (!empty($_GET['server']))
				echo "<h2>Server port - ". $server." </h2>";
			
            

	echo "<tr>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;&emsp;</center></td>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;Id&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;Guid&emsp;</center></td>";
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center>&emsp;".$t_nickname."&emsp;</center></td>";	
echo "<td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> <b>".$t_time." </b></center></td>
	  <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> <b>".$t_city." </b></center></td>
	  
	 <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> &emsp;<b> Status </b></center></td>
	 
	 <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> &emsp;<b>  Days  </b></center></td>
	 	 
	 
	 
	 <td style=\"background:#333; height: 28px; font-family: Impact, fantasy; color: #ccc; font-size:14px;\"> <center> &emsp;<b>End Time </b></center></td>
	    
	  ";
	  
	echo "</tr>";		
	}
	
$i++;	
$ssssob = $i;
//$geo = mb_strtolower($geo);
          
		  
			   

	echo "<tr>";


    $tm = str_replace(".", "-", $dannye['x_db_date']);
	$tm = trim($tm);
	
	if(empty($raznica_vremya_admin))
	$raznica_vremya_admin = '-1';
	
	if($geo == 'zag')
      $tm = $tm.'';
    else
		$tm = date( "Y-m-d H:i:s", strtotime( $tm." ".$raznica_vremya." hour" ) );
	
	$xxtime = trim($tm);
    $tm = str_replace("-", ".", $tm);
	
	$tm = time_elapsed_string($xxtime);
	//$db_date = new DateTime($xxtime);
    //$unix_db_date = $db_date->getTimestamp();
    //$tm = getDateString($unix_db_date);
	
	$ttim = $dannye['x_date_reg'];
 
 
 
 
 
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\">&emsp; 
	
	  <span tooltip=\"Player in Chat\"><a href=\"".$ssylka_na_codbox."chat.php?search=".$guidxx."\" target=\"_blank\"><img src=\"".$ssylka_na_codbox."/img/chat.svg\" width=\"24\" height=\"15\" alt=\"chat\"></a></span>   </td>";
	

echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	  <span tooltip=\"Player in Stats\"><a href=\"".$ssylka_na_codbox."stats.php?search=".$guidxx."\" target=\"_blank\"><img src=\"".$ssylka_na_codbox."/img/stats.svg\" width=\"24\" height=\"15\" alt=\"chat\"></a></span>   </td>";
	 
  
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp; <b style=\"color:".$cvet_ip.";\">" .  $xplid . "&emsp;</b>   </td>";
  
 
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp;<a href=\"".$ssylka_na_codbox."chat_ban.php?guid=".$guidxx."&archive=". $chatdbarc."\"><b style=\"color:".$cvet_ip.";\">" .  $guidxx . "&emsp;</b> </a>  </td>";
 
  
 	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	&nbsp;<a href=\"".$ssylka_na_codbox."chat_ban.php?search=".$xpnickname."&archive=". $chatdbarc."\"><b style=\"color:Silver;\">" . $xpnickname . "&emsp;</b> </a>  </td>";
 
  
 
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
	
	<span tooltip=\"".$xxtime." || ".$dannye['x_date_reg']."\">&nbsp;<a href=\"".$ssylka_na_codbox."?timeh=".$ttim."&archive=". $chatdbarc."\"><b style=\"color:".$cvet_date_time.";\">" . $tm . "&emsp;</b> </a> </span>  </td>";
	echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\">";
	
	
	
	
/*	
	
foreach($geo_array as $arrr => $sd)
{
    foreach($sd as $w => $geon)
    {
		if($geo == $geon)
		{
	    ////ENG		
        //echo "<br/>".$sd[2].' => '.$geon;
	    $fullgeo = $sd[2];
	    }
    
	}	
	
}	
*/	
	
	if(!empty($geo))
	  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?geo='.$geo.'&archive='. $chatdbarc.'"><span tooltip="'.$xxxnw.'"> <img src="'.$ssylka_na_codbox.'/flags-mini/'.$geo.'.png" width="24" height="12" alt="'.$xxxnw.'"></span></a>';
	else{
/*	*/		
////////////////////////////////////////////// 
 if((($psxz < 20)&&(!empty($Msql_support)))||(($psxz < 40)&&(empty($Msql_support)))){
 $oss=$bdd ->query("SELECT * From chat where x='1' and guid='$guidxx' limit 1");
while ($xnc = $oss->fetch())
{ 
   if((!empty($xnc['geo']))||(!empty($xnc['ip'])))
   {
	   ++$psxz;
	   ++$psxzl;
   $strana = $xnc['geo']; 
   $ipaddr = $xnc['ip'];
   
   	/// + псевдо загрузка флагов
	echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?geo='.$strana.'&archive='.$chatdbarc.'"><span tooltip="'.$strana.'"><img src="'.$ssylka_na_codbox.'/flags-mini/'.$strana.'.png" width="24" height="12" alt="'.$strana.'"></span></a>';
   
   //if($psxzl < 2)
   //$bdd->exec("UPDATE chat SET geo='$strana', ip='$ipaddr',x='1' WHERE guid='$guidxx' and z='0'");
  
   }
 }
	}
	}
    



if($status1 == 1)
	$status1 = 'Banned';
	
  
 echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;
 height:24px;line-height:22px;margin:0;padding:0;\">&emsp;";
echo $status1;
 echo "&emsp;</td>";	
 
 
  echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;
 height:24px;line-height:22px;margin:0;padding:0;\">&emsp;";
echo $status1days;
 echo "&emsp;</td>";
 
  
  echo "<td style=\"background:" . ($i % 2 ? '#111' : '#222') . ";opacity: 0.9; font-family: Titillium Web; color: Silver;\"> 
 <b style=\"color:".$cvet_ip.";\">" .   $status1time . "&emsp;</b></td>";
 
  
		if(empty($key))	{
		 $txtemptycnt = substr_count($txt,' ');	
		 if((strlen($txt) > 70) && ($txtemptycnt < 3))
		 $txt = strlen($txt) > 35 ? substr($txt,0,35)."...." : $txt;
	    }
	  
		 $txt = wordwrap($txt, 60, "</br>&emsp;", 1);
 
		 if(empty($Msql_support))
		  $txt = iconv("windows-1251", "utf-8",$txt);
	   
			
	}

echo '</table>';	



if (!$reponse) {
    echo "\nPDO::errorInfo():\n";
    print_r($bdd->errorInfo());
}

$reponse->closeCursor();
$reponse = null;
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}


$fff = $soob_na_page - $ssssob;

$t = 0;
for ($i = 1 ; $i <= $nb_pages ; $i++)
{
    $t++;
	
	if (empty($search)){
		
		if (($nb_pages == $page) && ($nb_pages == $t))
		{
			  
			for ($k = 1 ; $k <= $fff; $k++)
			{
		 if($soob_na_page < $ssssob + 10)
		  echo '</br>';
	        }
		 
		 }
	}	
}	

echo '<br/><div class="footerx"><div class="footer">';

if (is_numeric($key))	
$pageskey = '<a href="'.$ssylka_na_codbox.'chat_ban.php?pass=' . $passsword .'&server=' . $server .'&search=' . $search .'&geo=' . $geosearch .'&timeh=' . $timesearch .'&st1=' . $statusx1 .'&st2=' . $statusx2 .'&ip=' . $search_ip.'&archive=' . $chatdbarc.'&page=';    
 else
$pageskey = '<a href="'.$ssylka_na_codbox.'chat_ban.php?server=' . $server .'&search=' . $search .'&geo=' . $geosearch .'&timeh=' . $timesearch .'&st1=' . $statusx1 .'&st2=' . $statusx2.'&page=';


// Проверяем нужны ли стрелки назад
if ($page != 1) $pervpage = $pageskey.'1">Первая</a> | '.$pageskey.($page - 1).'">Предыдущая</a> | ';
// Проверяем нужны ли стрелки вперед
if ($page != $nb_pages) $nextpage = ' | '.$pageskey. ($page + 1) .'">Следующая</a> | '.$pageskey.$nb_pages. '">Последняя</a>';

// Находим две ближайшие станицы с обоих краев, если они есть
if($page - 8 > 0) $page8left = ' '.$pageskey. ($page - 8) .'">'. ($page - 8) .'</a> | ';
if($page - 7 > 0) $page7left = ' '.$pageskey. ($page - 7) .'">'. ($page - 7) .'</a> | ';
if($page - 6 > 0) $page6left = ' '.$pageskey. ($page - 6) .'">'. ($page - 6) .'</a> | ';
if($page - 5 > 0) $page5left = ' '.$pageskey. ($page - 5) .'">'. ($page - 5) .'</a> | ';
if($page - 4 > 0) $page4left = ' '.$pageskey. ($page - 4) .'">'. ($page - 4) .'</a> | ';
if($page - 3 > 0) $page3left = ' '.$pageskey. ($page - 3) .'">'. ($page - 3) .'</a> | ';
if($page - 2 > 0) $page2left = ' '.$pageskey. ($page - 2) .'">'. ($page - 2) .'</a> | ';
if($page - 1 > 0) $page1left = $pageskey. ($page - 1) .'">'. ($page - 1) .'</a> | ';

if($page + 8 <= $nb_pages) $page8right = ' | '.$pageskey. ($page + 8) .'">'. ($page + 8) .'</a>';
if($page + 7 <= $nb_pages) $page7right = ' | '.$pageskey. ($page + 7) .'">'. ($page + 7) .'</a>';
if($page + 6 <= $nb_pages) $page6right = ' | '.$pageskey. ($page + 6) .'">'. ($page + 6) .'</a>';
if($page + 5 <= $nb_pages) $page5right = ' | '.$pageskey. ($page + 5) .'">'. ($page + 5) .'</a>';
if($page + 4 <= $nb_pages) $page4right = ' | '.$pageskey. ($page + 4) .'">'. ($page + 4) .'</a>';
if($page + 3 <= $nb_pages) $page3right = ' | '.$pageskey. ($page + 3) .'">'. ($page + 3) .'</a>';
if($page + 2 <= $nb_pages) $page2right = ' | '.$pageskey. ($page + 2) .'">'. ($page + 2) .'</a>';
if($page + 1 <= $nb_pages) $page1right = ' | '.$pageskey. ($page + 1) .'">'. ($page + 1) .'</a>';

// Вывод меню если страниц больше одной

if ($nb_pages > 1)
{
Error_Reporting(E_ALL & ~E_NOTICE);
echo "<div class=\"pstrnav\">";
echo $pervpage.$page7left.$page6left.$page5left.$page4left.$page3left.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$page3right.$page4right.$page5right.$page6right.$page7right.$nextpage;
echo "</div>";
}


echo "</br><span style=\"color:#006699;text-decoration:underline;cursor:pointer;font-size:11px;\" onclick=\" document.getElementById('instruction').style.display = (document.getElementById('instruction').style.display=='none'?'inline':'none');\">
                Все страницы</span>";
echo '<div id="instruction" style="display: none; width: 100%;"></br></br>';	

$t = 0;
for ($i = 1 ; $i <= $nb_pages ; $i++)
{
    $t++;
		$pi = $i;
		
	  if(!empty($_GET['page']))
		if(($_GET['page']) == $i)        // font-size: 18px;
			$pi = '<b class="flashingf">&nbsp;'.$i.'&nbsp;</b>';             	
if(!empty($searchplayername))
	$searchplayername = $search;
echo '&nbsp;'.$pageskey.$i.'">' . $pi.  ' </a> ';       
		}
echo '</div>';
		
echo '</br></br> <a href="#" style="font-size:13px; font-family: Ariel;">'.$t_gen.': ' . ( microtime(true) - $startx ) . ' '.$t_tsek.' </a>';
	if(empty($key))
echo "</br> <a href=\"#\" style=\"font-size:13px; font-family: Ariel;\">$t_cachedw $xcache_time $t_tsek</a>";

 
include_once("footer.php"); 
echo '</div></div></br>';

if (($_GET['theme']) == 'light') 
  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?theme=dark" title="Вернуться к началу" class="topbutton">Style</a>';
else
  echo '<a href="'.$ssylka_na_codbox.'chat_ban.php?theme=light" title="Вернуться к началу" class="topbuttondark">Style</a>'; 

echo '</br></br>  
<!--RECOD.RU Call Of duty game series chat parser by LA|ROCCA --> ';
 
if(empty($key))
{
 $handle = fopen($cache_file, 'w'); // Открываем файл для записи и стираем его содержимое
  fwrite($handle, ob_get_contents()); // Сохраняем всё содержимое буфера в файл
  fclose($handle); // Закрываем файл
  ob_end_flush(); // Выводим страницу в браузере 
}
 
  
 }

?>
</div></body>
</html>		