// click to change the center;

var w = c.width = window.innerWidth,
    h = c.height = window.innerHeight,
    ctx = c.getContext( '2d' ),
    
    points = [],
    frame = 0,
    
    cen = {
      x: w/2,
      y: h/2
    },
    gui = new dat.GUI,
    repaintAlpha = .1;

ctx.lineWidth = .1;
gui.add( window, 'repaintAlpha', 0, 1 );

function anim() {
  
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = 'rgba(0, 0, 0, alp)'.replace( 'alp', repaintAlpha );
  ctx.fillRect( 0, 0, w, h );
  ctx.globalCompositeOperation = 'lighter'
  
  window.requestAnimationFrame( anim );
  
  if( points.length < 100 && Math.random() < .3 ) points.push( new Point );
  
  ++frame;
  
  for( var i = 0; i < points.length; ++i ) {
    
    var p1 = points[i];
    p1.step();
    
    for( var j = i+1; j < points.length; ++j ) {
      
      var p2 = points[j],
          x = p2.x - p1.x,
          y = p2.y - p1.y;
      
      if( x*x + y*y < 10000 ) p1.connect( p2 );
    }
  }
}

function Point() {
  
  this.reset();
}
Point.prototype.reset = function() {
  
  this.vx = Math.random() * 2 + 1;
  
  if( Math.random() < .5 )
    this.x = 0;
  
  else {
    this.x = w;
    this.vx *= -1;
  }
  
  this.y = Math.random() * h;
  this.vy = Math.random() * 4 - 2;
}
Point.prototype.step = function() {
  
  this.x += this.vx;
  this.y += this.vy;
  
  if( this.x < 0 || this.x > w || this.y < 0 || this.y > h ) this.reset();
}
Point.prototype.connect = function( that ) {
  
  ctx.strokeStyle = 'hsl(hue, 80%, 50%)'.replace( 'hue', ( this.x + that.x) / 2 / w * 360 + frame % 360 );
  ctx.beginPath();
  ctx.moveTo( this.x, this.y );
  ctx.quadraticCurveTo( cen.x, cen.y, that.x, that.y );
  ctx.stroke();
}
for( var i = 0; i < 300; ++i ) {
  
  if( points.length < 100 && Math.random() < .3 ) points.push( new Point );
  
  ++frame;
  
  points.map( function( p ) {
    
    p.step();
  } );
}
anim();

window.addEventListener( 'resize', function() {
  w = c.width = window.innerWidth;
  h = c.height = window.innerHeight;
  cen.x = w/2;
  cen.y = h/2;
} );
c.addEventListener( 'click', function( e ) {
  
  cen.x = e.clientX;
  cen.y = e.clientY;
} );