<?php

  $take_screen = "Take Screenshot! Wait 5 sec.";
  $t_players = "Players";
  
  $t_kills_min = "Kill per minute";
  $t_total_games = "games";
  
  $t_server = "Server";
  $t_time = "Time";
  $t_city = "Geo";
  $t_nickname = "Name";
  $t_nickmy = "My";
  $t_messages = "Messages";
  
  $moreinfo_more = "More information...";
  $moreinfo_here = "Press here!";
  
  $t_tottal = "Total";
  $t_ago = "Ago";
  $t_series = "Series in a row";
  $t_damages = "Damage";
  $t_knife = "Knife";
  $t_today = "Today";
  $t_playing = "Playing";
  $t_info = "Info";
  $t_skill = "Skill";
  $t_accuracy = "Accuracy";
  $t_heads = "Heads";
  $t_kd = "K/D";
  $t_deaths = "Deaths";
  $t_kills = "Kills";
  $t_soul = "Soul";
  $t_general_stats = "Main top";
  $t_search = 'Search';
  $t_gen = 'Generation time:';
  $t_top = 'Top';
  $t_total_players = 'Total players on all servers'; //Total players on all servers
  $t_killx2 = ' kills on top'; //kills on top
  $t_tsek = ' sec.';
  $t_cachedw = 'Cached with '; //Cached with
  
  $t_geo_tops = ' GEO TOP '; //GEO TOP
  
  $t_page_first = 'First';
  $t_page_pre = 'Previous';
  $t_page_next = 'Next';
  $t_page_last = 'Last';
  $t_page_all = 'All Pages';
  
  $t_top_today =  'Today top'; //'TODAY TOP ';
  $t_top_week =  'Week top'; //'WEEK TODAY';
  
  $t_player_place = 'Position among the players of the server'; 
  $t_player_place_all = 'Position among the players of the all servers'; 
  $t_player_place_skill = 'Skill on top';
  $t_player_place_kills = 'Kills on top';
  $t_player_place_heads = 'Heads on top';
  
  $medals = 'Medals';
  $medals_pro = 'PRO  Medals';
  $medals_series = 'Kill  Series  Medals';
  $medals_anti = 'Anti  Medals';
  
   
  $medals_killer  = 'Killer ';
  $medals_headshots  = 'Headshots';
  $medals_suicides = 'Suicides';  
  $medals_knife = 'Knife';  
  $medals_skill = 'Skill';
  $medals_grenade = 'Grenade';   
  $medals_cobra = 'Cobra'; 
  $medals_deaths = 'Most Target';
  $medals_series = 'Series';  
 
$hit_head = "Headshots";			
$hit_torso_lower = "Torso Lower";	
$hit_torso_upper = "Torso Upper";	
$hit_right_arm_lower = "Right Arm Lower";	
$hit_left_leg_upper = "Left Leg Upper";	
$hit_neck = "Neck";	
$hit_right_arm_upper = "Right Arm Upper";	
$hit_left_hand = "Left Hand";	
$hit_left_arm_lower = "Left Arm Lower";	
$hit_none = "";	
$hit_right_leg_upper = "Right Leg Upper";	
$hit_left_arm_upper = "Left Arm Upper";	
$hit_right_leg_lower = "Right Leg Lower";	
$hit_left_foot = "Left Foot";	
$hit_right_foot = "Right Foot";	
$hit_right_hand = "Right Hand";									
$hit_left_leg_lower = "Left Leg Lower"; 

$playeed_date = "Date";
$t_lasttime = "Last Hunt";
$t_timee = "First Hunt";
	
$t_xyears = 'year';
$t_xmonth = 'month';					 
$t_xday = 'day';
$t_xhours  = 'h';				 
$t_xmin = 'm';
$t_xsek = 's';	

$lang_skill_history = 'History';
$lang_skill_history_sk_archive = 'Skill archive';
$lang_skill_history_sk_record = 'Skill record';
$lang_skill_history_sk_avg = 'Average Skill';
$lang_skill_history_kd_record = 'K/D ratio record';
$lang_skill_history_kd_avg = 'Average K/D ratio';

 
///https://callofduty.fandom.com/ru/wiki/%D0%9F%D1%80%D0%B5%D1%81%D1%82%D0%B8%D0%B6
$prestige_0 = "No Prestige";
$prestige_1 = "Army Commendation Medal";
$prestige_2 = "Vietnamese company medal";
$prestige_3 = "Staff Service Medal";
$prestige_4 = 'Order of the Legion of Honor"';
$prestige_5 = "Kuwait Liberation Medal";
$prestige_6 = "Special Service Medal";
$prestige_7 = "Flight Merit Cross";
$prestige_8 = "Civil Action Medal";
$prestige_9 = "Wound medal";
$prestige_10 = "Naval cross";

$bonus_slot_3d  = "YOU WIN VIP 3 days!";
$bonus_slot_vip = "You win VIP ";
$bonus_slot_days = "day's!";
$bonus_slot_lose = "YOU LOSE";
$bonus_slot_welcome = "WELCOME";
$bonus_slot_spin = "TAKE A SPIN!";
$bonus_slot_spinning = "SPINNING";

$bonus_slot_vb  = "VIP bonus!";
$bonus_slot_vbtxt  = "Your ip address is not in the server database, you need your real ip address!";
 


