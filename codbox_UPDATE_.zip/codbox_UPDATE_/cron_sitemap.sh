#!/bin/sh

DIRFILE=`readlink -e "$0"`
CURFILE=`basename "$DIRFILE"`
CURDIR=`dirname "$DIRFILE"`

php -q -f $CURDIR/stats_curl_sitemap.php
