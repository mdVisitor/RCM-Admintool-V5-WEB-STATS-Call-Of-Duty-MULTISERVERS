﻿<?php
$filemtime=filemtime($by_time);
            //if ((time()-$filemtime>= 100)&& (filesize($by_time) != 0))
      if (time()-$filemtime < 97800)  //21600  6 hours   
			{	
				
if(filesize($by_time) == 0)
{
	
	
	
$re = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, 
t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,
t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,
t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= t0.s_lasttime
 ORDER BY (t0.s_time+0) ASC LIMIT 1');  

 
 
while ($row = $re->fetch())	
{	
	$ntime_pl = $row['s_player'];
	$timee = $row['s_time'];
	$lasttime = $row['s_lasttime'];
	$ntime_dmg = $row['s_dmg'];
	$ntime_guid = $row['s_guid'];
	
}





///////////////////////////////////////////////////////////////////



                // количество дней (разница)
				 if((!empty($timee))&&(!empty($lasttime))){
					 
                      $now = new DateTime(); // текущее время на сервере
					
					
                     $datetime1 =  DateTime::createFromFormat("Y-m-d H:i:s", $lasttime);//создаем из переменной
                     $datetime2 =  DateTime::createFromFormat("Y-m-d H:i:s", $timee);
                     $raznica = $datetime1->diff($datetime2);//разница					
					 $xyears = $raznica->y; // кол-во лет
					 $xmonth = $raznica->m; // кол-во mesac
					 $xday = $raznica->d;   // кол-во дней
					 $xhours = $raznica->h; // кол-во часов
					 $xmin = $raznica->i;   // кол-во минут
                     $xsek = $raznica->s;   // кол-во c		

			  if(!empty($xday)){
				if((!empty($xhours))&&($xhours > 0)){ 
				  if((!empty($xmin))&&($xmin > 0)){
					  //$xmin = '';
				     if((!empty($xsek))&&($xsek > 0))
					   $xsek = '';
				  }
				} 
			  }
				 
					 if(!empty($xyears)) $xyears = $xyears.'.'.$t_xyears.' '; else $xyears = '';
					 if(!empty($xmonth)) $xmonth = $xmonth.'.'.$t_xmonth.' '; else $xmonth = '';					 
					 if(!empty($xday)) $xday = $xday.'.'.$t_xday.' '; else $xday = '';
					 if(!empty($xhours)) $xhours = $xhours.'.'.$t_xhours.' '; else $xhours = '';					 
				     if(!empty($xmin)) $xmin = $xmin.'.'.$t_xmin.' '; else $xmin = '';
                     if(!empty($xsek)) $xsek = $xsek.'.'.$t_xsek.' '; else $xsek = '';	
					  
                     $lasttime2 = $xyears.''.$xmonth.''.$xday.''.$xhours;//.''.$xmin .''.$xsek;	
				 
				     $strrwer = strlen($lasttime2);
				 
				      if($strrwer > 75)
                        $lasttime2 = $today;
			
					 
					 $date = DateTime::createFromFormat("Y-m-d H:i:s", $lasttime); // задаем дату в любом формате
					 $interval = $now->diff($date); // получаем разницу в виде объекта DateInterval
					 $xyears = $interval->y; // кол-во лет
					 $xmonth = $interval->m; // кол-во mesac
					 $xday = $interval->d;   // кол-во дней
					 $xhours = $interval->h; // кол-во часов
					 $xmin = $interval->i;   // кол-во минут
                     $xsek = $interval->s;   // кол-во c	
                  
			  if(!empty($xday)){
				if((!empty($xhours))&&($xhours > 0)){ 
				  if((!empty($xmin))&&($xmin > 0)){
					  //$xmin = '';
				     if((!empty($xsek))&&($xsek > 0))
					   $xsek = '';
				  }
				} 
			  }
				
					 if(!empty($xyears)) $xyears = $xyears.'.'.$t_xyears.' '; else $xyears = '';
					 if(!empty($xmonth)) $xmonth = $xmonth.'.'.$t_xmonth.' '; else $xmonth = '';					 
					 if(!empty($xday)) $xday = $xday.'.'.$t_xday.' '; else $xday = '';
					 if(!empty($xhours)) $xhours = $xhours.'.'.$t_xhours.' '; else $xhours = '';					 
				     if(!empty($xmin)) $xmin = $xmin.'.'.$t_xmin.' '; else $xmin = '';
                     if(!empty($xsek)) $xsek = $xsek.'.'.$t_xsek.' '; else $xsek = '';	
					 
                     $timee2 = $xyears.''.$xmonth.''.$xday.''.$xhours.''.$xmin.''.$xsek;
					 
					 if(empty($timee2))
						 $timee2 = " сейчас"; 
					 
					 
					 
				     $strrwer = strlen($timee2);
				      if($strrwer > 75)
					    $timee2 = $lasttime;					 
			
                 } else{$lasttime2 = 0;  $timee = 0; $timee2 = 0;}	

$ntime  = $lasttime2;

///////////////////////////////////////////////////////////////////



 	$fpl = fopen($by_time, 'w+');
	fwrite($fpl, $ntime_guid."%".$ntime_pl."%".$ntime);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($by_time);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$ntime_guid = trim($infff[0]);		
$ntime_pl = trim($infff[1]);	
$ntime = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 18800) 
{

$re = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= t0.s_lasttime
 ORDER BY (t0.s_time+0) ASC LIMIT 1');    
 
while ($row = $re->fetch())	
{	
	$ntime_pl = $row['s_player'];
	$timee = $row['s_time'];
	$lasttime = $row['s_lasttime'];
	$ntime_dmg = $row['s_dmg'];
	$ntime_guid = $row['s_guid'];

}

///////////////////////////////////////////////////////////////////



                // количество дней (разница)
				 if((!empty($timee))&&(!empty($lasttime))){
					 
                      $now = new DateTime(); // текущее время на сервере
					
					
                     $datetime1 =  DateTime::createFromFormat("Y-m-d H:i:s", $lasttime);//создаем из переменной
                     $datetime2 =  DateTime::createFromFormat("Y-m-d H:i:s", $timee);
                     $raznica = $datetime1->diff($datetime2);//разница					
					 $xyears = $raznica->y; // кол-во лет
					 $xmonth = $raznica->m; // кол-во mesac
					 $xday = $raznica->d;   // кол-во дней
					 $xhours = $raznica->h; // кол-во часов
					 $xmin = $raznica->i;   // кол-во минут
                     $xsek = $raznica->s;   // кол-во c		

			  if(!empty($xday)){
				if((!empty($xhours))&&($xhours > 0)){ 
				  if((!empty($xmin))&&($xmin > 0)){
					  //$xmin = '';
				     if((!empty($xsek))&&($xsek > 0))
					   $xsek = '';
				  }
				} 
			  }
				 
					 if(!empty($xyears)) $xyears = $xyears.'.'.$t_xyears.' '; else $xyears = '';
					 if(!empty($xmonth)) $xmonth = $xmonth.'.'.$t_xmonth.' '; else $xmonth = '';					 
					 if(!empty($xday)) $xday = $xday.'.'.$t_xday.' '; else $xday = '';
					 if(!empty($xhours)) $xhours = $xhours.'.'.$t_xhours.' '; else $xhours = '';					 
				     if(!empty($xmin)) $xmin = $xmin.'.'.$t_xmin.' '; else $xmin = '';
                     if(!empty($xsek)) $xsek = $xsek.'.'.$t_xsek.' '; else $xsek = '';	
					  
                     $lasttime2 = $xyears.''.$xmonth.''.$xday.''.$xhours;//.''.$xmin .''.$xsek;
				 
				     $strrwer = strlen($lasttime2);
				 
				      if($strrwer > 75)
                        $lasttime2 = $today;
			
					 
					 $date = DateTime::createFromFormat("Y-m-d H:i:s", $lasttime); // задаем дату в любом формате
					 $interval = $now->diff($date); // получаем разницу в виде объекта DateInterval
					 $xyears = $interval->y; // кол-во лет
					 $xmonth = $interval->m; // кол-во mesac
					 $xday = $interval->d;   // кол-во дней
					 $xhours = $interval->h; // кол-во часов
					 $xmin = $interval->i;   // кол-во минут
                     $xsek = $interval->s;   // кол-во c	
                  
			  if(!empty($xday)){
				if((!empty($xhours))&&($xhours > 0)){ 
				  if((!empty($xmin))&&($xmin > 0)){
					  //$xmin = '';
				     if((!empty($xsek))&&($xsek > 0))
					   $xsek = '';
				  }
				} 
			  }
				
					 if(!empty($xyears)) $xyears = $xyears.'.'.$t_xyears.' '; else $xyears = '';
					 if(!empty($xmonth)) $xmonth = $xmonth.'.'.$t_xmonth.' '; else $xmonth = '';					 
					 if(!empty($xday)) $xday = $xday.'.'.$t_xday.' '; else $xday = '';
					 if(!empty($xhours)) $xhours = $xhours.'.'.$t_xhours.' '; else $xhours = '';					 
				     if(!empty($xmin)) $xmin = $xmin.'.'.$t_xmin.' '; else $xmin = '';
                     if(!empty($xsek)) $xsek = $xsek.'.'.$t_xsek.' '; else $xsek = '';	
					 
                     $timee2 = $xyears.''.$xmonth.''.$xday.''.$xhours.''.$xmin.''.$xsek;
					 
					 if(empty($timee2))
						 $timee2 = " сейчас"; 
					 
					 
					 
				     $strrwer = strlen($timee2);
				      if($strrwer > 75)
					    $timee2 = $lasttime;					 
			
                 } else{$lasttime2 = 0;  $timee = 0; $timee2 = 0;}	


$ntime  = $lasttime2;
///////////////////////////////////////////////////////////////////

 	$fpl = fopen($by_time, 'w+');
	fwrite($fpl, $ntime_guid."%".$ntime_pl."%".$ntime);	
    fclose($fpl);
}
