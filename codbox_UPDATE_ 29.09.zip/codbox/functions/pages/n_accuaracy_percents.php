﻿<?php
$filemtime=filemtime($crn_accuaracy_percents);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_accuaracy_percents) != 0))
      if (time()-$filemtime < 69800)  //21600  6 hours   
			{	
				
if(filesize($crn_accuaracy_percents) == 0)
{
	
	
$re = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,
 t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
 t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,
 t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,
 t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg, ROUND((s_kills) * 100.0 / s_dmg, 1) AS Percent
FROM db_stats_1 where s_kills > 1000 ORDER BY (Percent+0) ASC) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
t1.s_pg = t2.s_pg
 '.$serverxxx.' t1.s_kills >= 1000
ORDER BY (Percent+0) DESC LIMIT 1');	
	 
 
while ($row = $re->fetch())	
{	
	$n_acc_pl = $row['s_player'];
	$n_acc_kills = $row['s_kills'];
	$n_acc_dmg = $row['s_dmg'];
	$n_acc_guid = $row['s_guid'];
	$n_acc = get_percentage($n_acc_kills, $n_acc_dmg);
}


 	$fpl = fopen($crn_accuaracy_percents, 'w+');
	fwrite($fpl, $n_acc_guid."%".$n_acc_pl."%".$n_acc);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_accuaracy_percents);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$n_acc_guid = trim($infff[0]);		
$n_acc_pl = trim($infff[1]);	
$n_acc = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 18800) 
{

$re = $bdd->query('SELECT t0.s_pg,t0.s_guid, t0.s_port, t0.servername,
 t0.s_player,t0.s_time,t0.s_lasttime, t1.s_pg,t1.s_kills,t1.s_deaths,t1.s_heads,
 t1.s_suicids,t1.s_fall,t1.s_melle,t1.s_dmg, t2.s_pg,t2.w_place,t2.w_skill,
 t2.w_ratio,t2.w_geo,t2.w_prestige,t2.w_fps,t2.w_ip,t2.w_ping,t2.n_kills,
 t2.n_deaths,t2.n_heads,t2.n_kills_min,t2.n_deaths_min 
   from db_stats_0 t0 
   join 
 (select s_pg,s_kills,s_deaths,s_heads,s_suicids,s_fall,s_melle,s_dmg, ROUND((s_kills) * 100.0 / s_dmg, 1) AS Percent
FROM db_stats_1 where s_kills > 1000 ORDER BY (Percent+0) ASC) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select s_pg,w_place,w_skill,w_ratio,w_geo,w_prestige,w_fps,w_ip,w_ping,n_kills,n_deaths,n_heads,n_kills_min,n_deaths_min from db_stats_2) 
 t2 ON 
t1.s_pg = t2.s_pg
 '.$serverxxx.' t1.s_kills >= 1000
ORDER BY (Percent+0) DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
	$n_acc_pl = $row['s_player'];
	$n_acc_kills = $row['s_kills'];
	$n_acc_dmg = $row['s_dmg'];
	$n_acc_guid = $row['s_guid'];
	$n_acc = get_percentage($n_acc_kills, $n_acc_dmg);
}


 	$fpl = fopen($crn_accuaracy_percents, 'w+');
	fwrite($fpl, $n_acc_guid."%".$n_acc_pl."%".$n_acc);	
    fclose($fpl);
}
