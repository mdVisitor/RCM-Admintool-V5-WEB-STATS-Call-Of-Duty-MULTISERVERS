<?php
session_start();
$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");  
include_once("functions/words.php"); 
include_once("functions/chatdb_archive.php"); 
include_once("functions/functions.inc.php"); include_once("langctrl.php");  
include_once("functions/geo.php");

  
	$cc = 1800; 
	$xcache_time = $cc;
	
if(empty($key))
{
  $file = "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
  $filemd5 = md5($file); 
  $cache_file = $cache_folder."$filemd5.html";
  if (file_exists($cache_file)) {
   if ((time() - $cc) < filemtime($cache_file)) {
      echo file_get_contents($cache_file); 
	  echo "<!-- --------- Cached with $xcache_time seconds --------- -->";
      exit; 
    }
	}
  ob_start();
  
  }
  
  
  if (!empty($_GET['server']))
	$server = $_GET['server']; 
   else
  $server = 0;
  
?>

<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title><?php echo $title_zagolovok_stranicy ?></title>
<link rel="stylesheet" href="<?php echo $ssylka_na_codbox;?>css_js/RGraph/examples/demos.css" type="text/css" media="screen" />		
<script src="<?php echo $ssylka_na_codbox;?>css_js/RGraph/libraries/RGraph.common.core.js"></script>
<script src="<?php echo $ssylka_na_codbox;?>css_js/RGraph/libraries/RGraph.common.dynamic.js"></script>
<script src="<?php echo $ssylka_na_codbox;?>css_js/RGraph/libraries/RGraph.common.tooltips.js"></script>
<script src="<?php echo $ssylka_na_codbox;?>css_js/RGraph/libraries/RGraph.pie.js"></script>
		<title><?php echo $title_zagolovok_stranicy ?></title>
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/recod-ru.css"/>
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/demo.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/tooltip-classic.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/matrix.min.css">
        <script type="text/javascript" src="<?php echo $ssylka_na_codbox;?>css_js/matrix.min.js" async defer></script>
		<script type="text/javascript" src="<?php echo $ssylka_na_codbox;?>css_js/html2canvas.js"></script>
<meta name="robots" content="noindex, nofollow" />
<?php 

if (!empty($_GET['theme']))
$_SESSION['theme'] = $_GET['theme'];


if (!empty($_SESSION['theme'])){
	$_GET['theme'] = $_SESSION['theme'];
}
else
	$_GET['theme'] = 'dark';



if (($_GET['theme']) == 'dark') {?>
<style>
body{
  transition:0;
  background-color:#141e21; /* #002600 */
  color:#2eb4e9;
  margin: 0;
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}

table{
 position:relative;	
}


.topbuttondark {
width:50px;
border:2px solid #ccc;
background:#f7f7f7;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#333;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }
else  {
?>
<style>
body{
  transition:0;
  background-color:#ddd; /* #002600 */
  color:#000;
  margin: 0;
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}


table{
 position:relative;		
}

.topbutton {
width:50px;
border:2px solid #ccc;
background:#333;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#fff;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }?>
</head>
<body>




<div class="menuooo-center2">
 <div class="menuooo2">
<div id="menu">
        <ul>		
<?php		
foreach ($ssylki_array as $arxx => $namessylka) {	
echo '<li>| <a href="'.$arxx.'" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #FFF, 0 0 7px #990694, 0 0 18px #990694, 0 0 40px #990694, 0 0 65px #990694;" target="_blank">'.$namessylka.'</a></li>';   
} echo '</br>';		
foreach ($multi_servers_array as $arx => $xservername) {	
						   $zx = explode("server_md5:", $arx);
						   $fld = $zx[1];
						   $server_md5 = strtok($fld, " ");
   echo '<li>| <a href="'.$ssylka_na_codbox.'geo.php?server='.$server_md5.'">'.$xservername.'</a> </li>';   
}


?>
        </ul>
	
<div class="absolute-style"> 
<?php
echo '<a href="'.$ssylka_na_codbox.'geo.php?main" style="padding-bottom: 40px;"> '. $main_servername . '</a>'; 
?>
   
     
</div>		
	
    </div>
</div></div>


<?php
try {	
	
	  if(empty($Msql_support))
    $bdd = new PDO('sqlite:' . $chatdb);
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
	  }	
	

	
$countries = array(
     "","AP","EU","AD","AE","AF","AG","AI","AL","AM","CW",
	"AO","AQ","AR","AS","AT","AU","AW","AZ","BA","BB",
	"BD","BE","BF","BG","BH","BI","BJ","BM","BN","BO",
	"BR","BS","BT","BV","BW","BY","BZ","CA","CC","CD",
	"CF","CG","CH","CI","CK","CL","CM","CN","CO","CR",
	"CU","CV","CX","CY","CZ","DE","DJ","DK","DM","DO",
	"DZ","EC","EE","EG","EH","ER","ES","ET","FI","FJ",
	"FK","FM","FO","FR","SX","GA","GB","GD","GE","GF",
	"GH","GI","GL","GM","GN","GP","GQ","GR","GS","GT",
	"GU","GW","GY","HK","HM","HN","HR","HT","HU","ID",
	"IE","IL","IN","IO","IQ","IR","IS","IT","JM","JO",
	"JP","KE","KG","KH","KI","KM","KN","KP","KR","KW",
	"KY","KZ","LA","LB","LC","LI","LK","LR","LS","LT",
	"LU","LV","LY","MA","MC","MD","MG","MH","MK","ML",
	"MM","MN","MO","MP","MQ","MR","MS","MT","MU","MV",
	"MW","MX","MY","MZ","NA","NC","NE","NF","NG","NI",
	"NL","NO","NP","NR","NU","NZ","OM","PA","PE","PF",
	"PG","PH","PK","PL","PM","PN","PR","PS","PT","PW",
	"PY","QA","RE","RO","RU","RW","SA","SB","SC","SD",
	"SE","SG","SH","SI","SJ","SK","SL","SM","SN","SO",
	"SR","ST","SV","SY","SZ","TC","TD","TF","TG","TH",
	"TJ","TK","TM","TN","TO","TL","TR","TT","TV","TW",
	"TZ","UA","UG","UM","US","UY","UZ","VA","VC","VE",
	"VG","VI","VN","VU","WF","WS","YE","YT","RS","ZA",
	"ZM","ME","ZW","A1","A2","O1","AX","GG","IM","JE",
  "BL","MF", "BQ");


$x = 0;
$fff =  0;

foreach ($countries as $x){
  $query=$bdd->query("SELECT COUNT(*) as count FROM db_stats_2 WHERE w_geo='$x'");

$query->setFetchMode(PDO::FETCH_ASSOC);
$row=$query->fetch();
if(!empty($row['count'])){
 $members=$row['count'];	
	

foreach($geo_array as $arrr => $sd)
{
    foreach($sd as $w => $geon)
    {

	if($members > 100)
	{
		if($x == $geon)
		{
		$fullgeo = $sd[2];
		
		$dataPoints0[$fff] = $fullgeo;
		$dataPoints1[$fff] = $members;
	    
		++$fff;
	    }
	}	
		
	}	
}

	
}}


$query->closeCursor();
$query = null;
}
catch (PDOException $e) {
    print 'Exception : ' . $e->getMessage();
}


 $players_geo_list = implode("','", $dataPoints0);
 $players_count_list = implode(",", $dataPoints1);

define("counts", $players_count_list);
define("geo", $players_geo_list);		
?>		


<center>
</br></br></br></br></br></br>
    <h2><?php echo $t_geo_tops; ?></h2>

<canvas id="cvs" width="650" height="500">[No canvas support]</canvas>
<script>
    labels = [ '<?php echo geo; ?>'];
    data = [<?php echo counts; ?>];


      for (var i=0; i<data.length; ++i) {
        labels[i] = labels[i] + ', ' + data[i] + '(players)';
    }

    new RGraph.Pie({
        id: 'cvs',
        data: data,
        options: {
            labels: labels,
            tooltips: labels,
            colorsStroke: 'white',
            linewidth: 0,
			textSize: 12,
            shadowOffsetx: 2,
            shadowOffsety: 2,
            shadowBlur: 3,
            exploded: 10
        }
    }).draw();
</script>
</center>
 <?php
if (($_GET['theme']) == 'light') 
  echo '<a href="'.$ssylka_na_codbox.'geo.php?theme=dark" title="Вернуться к началу" class="topbutton">Style</a>';
else
  echo '<a href="'.$ssylka_na_codbox.'geo.php?theme=light" title="Вернуться к началу" class="topbuttondark">Style</a>'; 
?> 

</body>
</html>
<?php
include_once("footer.php"); 
echo '<!--RECOD.RU Call Of duty game series chat parser by LA|ROCCA --> ';

if(empty($key))
{
 $handle = fopen($cache_file, 'w'); // Открываем файл для записи и стираем его содержимое
  fwrite($handle, ob_get_contents()); // Сохраняем всё содержимое буфера в файл
  fclose($handle); // Закрываем файл
  ob_end_flush(); // Выводим страницу в браузере 
}
?>