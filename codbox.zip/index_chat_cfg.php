﻿<?php
if(empty($access)) {header("location:https://promo-bc.com/promo.php?type=direct_link&c=411744&page=popular_chat"); 
    die('Bye HACKER :) !');}


	
	
  $ssylka_na_codbox = 'http://81.198.253.216/codbox/';
 
  $title_zagolovok_stranicy = 'zona-ato-game.ru';
  
  $main_servername = '<img src="http://zona-ato-game.ru/uploads/monthly_2018_07/59de67b25928d.png.c17aa4b8f94eff15c8411bb4c029f7ec.png" alt="zona-ato-game.ru">';
  
  $pre_server = '^3|^1ZONA ATO^3|';  //название серверов, ключевое название! 
  
	
/*#########    DATABASE CONFIGS    #########*/
    $Msql_support = 1; // 1 - Msql  0 - SqLite3
    
	///*********** FOR MSQL ONLY
	$host_adress = 'localhost:3308';
    $db_name   = 'adminmod';
    $db_user = 'root';
    $db_pass = '260386';
    $charset_db = 'utf8';
	
	//===  MAMBA.PHP PDO SQLITE3
	$mamba_db_path        = 'db4.sqlite';    /// db4.sqlite IN RCM ADMINMOD
	//===  STATS.PHP PDO SQLITE3
	$stats_db_path        = 'db3.sqlite';    /// db3.sqlite
    $stats_db_path_week   = 'dbw3.sqlite';   /// dbw3.sqlite
	$stats_db_path_month   = 'dbm3.sqlite';   /// dbm3.sqlite
	//===  CHAT.PHP PDO SQLITE3
    $chatdbsize = 90; // 90.MB
	// Не забываем поставить права 666 на этот файл, для автообновления гео флагов.
    $chatdb_path = 'D:\_TEST_SERVER\RECODMOD_MULTI_SERVERS\ReCodMod\databases\chatdb.sqlite';
  	

	
/*#########   STEAM   #########*/
 $steamkey = 'Ваш Steam Key'; 
 
 $steam_users_id = array(
 "124yt124124" => "Админ",
 "f124y12y412" => "Admin",  
 "7124y214y21y4" => "Admin2", 
 "92d4ece3e2bc14fdeaeb97ed99ebbbab0bfda47f71df7d8538242fa32ade08d7" => "Laroxxx",
 "1234456546457575755" => "Guest15163",
 "1eyey25215" => "Vip",
 "213123124124" => "Moderator"
 
 );	

 
/*#########   GAMETRACKER PARSER   #########*/ 
 $ip_for_gametracker = '212.109.217.69';
  
  
/*#########   MENU 1   #########*/   
 $ssylki_array = array( 
 "http://81.198.253.216/codbox/mamba.php" => "mamba",
 "http://81.198.253.216/codbox/geo.php" => "GEO",
 "http://81.198.253.216/codbox/stats.php" => "STATS",
 "http://81.198.253.216/codbox/chat.php" => "chat"
 );  
     
  
/*#########   MENU + INFO + RCON CONTROL    #########   ///Все настройки на управление чата, меню...  тут */
$multi_servers_array = array(
 "ip:212.109.217.69 port:28961 rcon:123 server_md5:28961" => "Dom HighXP",
 "ip:212.109.217.69 port:28962 rcon:123 server_md5:28962" => "War HighXP",
 "ip:212.109.217.69 port:28963 rcon:123 server_md5:28963" => "Sab Privat",
 "ip:212.109.217.69 port:28964 rcon:123 server_md5:28964" => "HardCore",
 "ip:212.109.217.69 port:28965 rcon:123 server_md5:28965" => "New Weapon",
 "ip:212.109.217.69 port:28966 rcon:123 server_md5:28966" => "Crossfire",
 "ip:212.109.217.69 port:28967 rcon:123 server_md5:28967" => "Gun Games",
 "ip:212.109.217.69 port:28968 rcon:123 server_md5:28968" => "Killhouse",
 "ip:212.109.217.69 port:28969 rcon:123 server_md5:28969" => "Nuketown",
 "ip:212.109.217.69 port:28960 rcon:123 server_md5:28960" => "CTF HighXP"
 );  
 
 

/* #######################   STATS    ####################### */
/* ########################################################## */  
  $title_migalka_stats = 'Статистика Серверов';  
  $top_main_total=20; //количество строк на страницу
  $color_headers = '#777';   
  $color_geo = '#777';
  $color_prestige = '#777';
  $color_nickname = '#3a87bc';  
  $color_kills = '#619fc9'; 
  $color_deaths = '#3d6d8e';  
  $color_kdratio = '#2a9125';   
  $color_heads = '#999';  
  $color_skill = '#888';  
  $color_grenades = '#999';  
  $color_knife = '#999';
  $color_suicids = '#555'; 
  $color_date_time = 'silver';  
  $color_date_time_new = 'lime';  
  $color_ip = '#2a9125';
  $color_ban_knopki = 'red';


/* #######################   CHAT    ####################### */
/* ########################################################## */  
  
  $title_migalka = 'Чат Серверов';  
  $soob_na_page=70; //количество строк сообшений на страницу
  $cache_folder = "cache/"; // Адрес нахождения папки var/www/site/cache/
  $raznica_vremya = '0'; // +1 час // -1 час и т.д.
  $cvet_date_time = '#0099cc';  
  $cvet_nikov = '#3a87bc';
  $cvet_ip = '#2a9125';
  $cvet_ban_knopki = 'red';
  $cvet_text = '#B6B6B6';
   
/* ###################      SCREENSHOTS      ################ */
/* ########################################################## */
$gallerytitle = 'Call oF Duty Gallery';
$pics_per_page = 30;
$columns_desktop = 3; 
 
$folder_of_screenshots_url = 'http://81.198.253.216/codbox/'; // url 
$folder_of_screenshots = 'C:/wamp64/www/codbox/screenshots/'; //MAIN FOLDER
$folder_web_of_screenshots_minus = '/zona-ato-game.ru/default/docs/';


 $screenshots_urls = array( 
 "http://81.198.253.216/....,./index.php" => "Servername-1",
 "http://81.198.253.216/.,..../index.php" => "Servername-2",
 "http://81.198.253.216/..,.../index.php" => "Servername-3"
 );   

  
  
  
  
  
  
$ssylka_sourcebans = 'http://zona-ato-game.ru/sourcebans/index.php'; 










///////////////////////////////////////////////////////////////////////////////////    
///////////////////////////////////////////////////////////////////////////////////   
////////////////////////       ADMIN PANEL       //////////////////////////////////   
///////////////////////////////////////////////////////////////////////////////////   
///////////////////////////////////////////////////////////////////////////////////  

/* ########################################################## */
/* ########################################################## */ 
/* #########################    DEMOS    #####################*/   
 
 $demos_array = array( 
 "http://81.198.253.216/....." => "Servername-1",
 "http://81.198.253.216/....." => "Servername-2",
 "http://81.198.253.216/....." => "Servername-3"
 );    
 

 
 
 
/* ########################################################## */
/* ########################################################## */ 
/* ####  PLAYERS STATUS {vip, guest, administrator...}   #### */   
 
 $status = 1; // 1 - on 0 - off 
 
 $steam_users_status_id = array(
 "124yt124124" => "Админ",
 "f124y12y412" => "Admin",  
 "7124y214y21y4" => "Admin2"

 );	
	
	

 
/////////////////////// PLUGINS ///////////////////////// 