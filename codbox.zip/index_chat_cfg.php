﻿<?php
if(empty($access)) {header("location:https://promo-bc.com/promo.php?type=direct_link&c=411744&page=popular_chat"); 
    die('Bye HACKER :) !');}


	
	
  $ssylka_na_codbox = 'http://87.110.94.40/codbox/';
 
  $title_zagolovok_stranicy = 'zona-ato-game.ru';
  
  $main_servername = '<img src="http://87.110.94.40/uploads/monthly_2019_03/cyberpub.png.293d3995dfff6eb7253b2bf546b8bfaa.png" alt="zona-ato-game.ru">';
  
  $pre_server = '^3|^1ZONA ATO^3|';  //название серверов, ключевое название! 
  
	
/*#########    DATABASE CONFIGS    #########*/
    $Msql_support = 1; // 1 - Msql  0 - SqLite3
    
	///*********** FOR MSQL ONLY
	$host_adress = 'localhost:3308';
    $db_name   = 'adminmod';
    $db_user = 'root';
    $db_pass = '260386';
    $charset_db = 'utf8';
	
	//===  MAMBA.PHP PDO SQLITE3
	$mamba_db_path        = 'db4.sqlite';    /// db4.sqlite IN RCM ADMINMOD
	//===  STATS.PHP PDO SQLITE3
	$stats_db_path        = 'db3.sqlite';    /// db3.sqlite
    $stats_db_path_week   = 'dbw3.sqlite';   /// dbw3.sqlite
	$stats_db_path_month   = 'dbm3.sqlite';   /// dbm3.sqlite
	//===  CHAT.PHP PDO SQLITE3
    $chatdbsize = 90; // 90.MB
	// Не забываем поставить права 666 на этот файл, для автообновления гео флагов.
    $chatdb_path = 'home/cp/Desktop/rcmnew/ReCodMod/databases/chatdb.sqlite';
  	

	
/*#########   STEAM   #########*/
 $steamkey = 'Ваш Steam Key'; 
 
 $steam_users_id = array(
 "124yt124124" => "Админ",
 "f124y12y412" => "Admin",  
 "7124y214y21y4" => "Admin2", 
 "92d4ece3e2bc14fdeaeb97ed99ebbbab0bfda47f71df7d8538242fa32ade08d7" => "Laroxxx",
 "1234456546457575755" => "Guest15163",
 "1eyey25215" => "Vip",
 "213123124124" => "Moderator"
 
 );	

 
/*#########   GAMETRACKER PARSER   #########*/ 
 $ip_for_gametracker = '212.109.217.69';
  
  
/*#########   MENU 1   #########*/   
 $ssylki_array = array( 
 "http://87.110.94.40/codbox/mamba.php" => "mamba",
 "http://87.110.94.40/codbox/geo.php" => "GEO",
 "http://87.110.94.40/codbox/stats.php" => "STATS",
 "http://87.110.94.40/codbox/chat.php" => "chat"
 );  
     
  
/*#########   MENU + INFO + RCON CONTROL    #########   ///Все настройки на управление чата, меню...  тут */
$multi_servers_array = array(
 "ip:212.109.217.69 port:28961 rcon:123 server_md5:28961" => "Dom HighXP",
 "ip:212.109.217.69 port:28962 rcon:123 server_md5:28962" => "War HighXP",
 "ip:212.109.217.69 port:28963 rcon:123 server_md5:28963" => "Sab Privat",
 "ip:212.109.217.69 port:28964 rcon:123 server_md5:28964" => "HardCore",
 "ip:212.109.217.69 port:28965 rcon:123 server_md5:28965" => "New Weapon",
 "ip:212.109.217.69 port:28966 rcon:123 server_md5:28966" => "Crossfire",
 "ip:212.109.217.69 port:28967 rcon:123 server_md5:28967" => "Gun Games",
 "ip:212.109.217.69 port:28968 rcon:123 server_md5:28968" => "Killhouse",
 "ip:212.109.217.69 port:28969 rcon:123 server_md5:28969" => "Nuketown",
 "ip:212.109.217.69 port:28960 rcon:123 server_md5:28960" => "CTF HighXP",
 
 
 "ip:212.109.217.69 port:28971 rcon:123 server_md5:28971" => "2 Dom HighXP",
 "ip:212.109.217.69 port:28972 rcon:123 server_md5:28972" => "2 War HighXP",
 "ip:212.109.217.69 port:28973 rcon:123 server_md5:28973" => "2 Sab Privat",
 "ip:212.109.217.69 port:28974 rcon:123 server_md5:28974" => "2 HardCore",
 "ip:212.109.217.69 port:28975 rcon:123 server_md5:28975" => "2 New Weapon",
 "ip:212.109.217.69 port:28976 rcon:123 server_md5:28976" => "2 Crossfire",
 "ip:212.109.217.69 port:28977 rcon:123 server_md5:28977" => "2 Gun Games",
 "ip:212.109.217.69 port:28978 rcon:123 server_md5:28978" => "2 Killhouse",
 "ip:212.109.217.69 port:28979 rcon:123 server_md5:28979" => "2 Nuketown",
 "ip:212.109.217.69 port:28970 rcon:123 server_md5:28970" => "2 CTF HighXP"
 );  
 
 

/* #######################   STATS    ####################### */
/* ########################################################## */  
  $title_migalka_stats = 'Статистика Серверов';  
  $top_main_total=20; //количество строк на страницу
  $color_headers = '#777';   
  $color_geo = '#777';
  $color_prestige = '#777';
  $color_nickname = '#3a87bc';  
  $color_kills = '#619fc9'; 
  $color_deaths = '#3d6d8e';  
  $color_kdratio = '#2a9125';   
  $color_heads = '#999';  
  $color_skill = '#888';  
  $color_grenades = '#999';  
  $color_knife = '#999';
  $color_suicids = '#555'; 
  $color_date_time = 'silver';  
  $color_date_time_new = 'lime';  
  $color_ip = '#2a9125';
  $color_ban_knopki = 'red';


/* #######################   CHAT    ####################### */
/* ########################################################## */  
  
  $title_migalka = 'Чат Серверов';  
  $soob_na_page=70; //количество строк сообшений на страницу
  $cache_folder = "cache/"; // Адрес нахождения папки var/www/site/cache/
  $raznica_vremya = '0'; // +1 час // -1 час и т.д.
  $cvet_date_time = '#0099cc';  
  $cvet_nikov = '#3a87bc';
  $cvet_ip = '#2a9125';
  $cvet_ban_knopki = 'red';
  $cvet_text = '#B6B6B6';
   
/* ###################      SCREENSHOTS      ################ */
/* ########################################################## */
$gallerytitle = 'Call oF Duty Gallery';
$pics_per_page = 30;
$columns_desktop = 3; 
 
$folder_of_screenshots_url = 'http://87.110.94.40/codbox/'; // url 
$folder_of_screenshots = 'C:/wamp64/www/codbox/screenshots/'; //MAIN FOLDER
$folder_web_of_screenshots_minus = '/zona-ato-game.ru/default/docs/';


 $screenshots_urls = array( 
 "http://87.110.94.40/....,./index.php" => "Servername-1",
 "http://87.110.94.40/.,999..../index.php" => "Servername-2",
  "http://87.110.94.40/..9..,./index.php" => "Servername-3",
 "http://87.110.94.40/.,..9../index.php" => "Servername-4",
  "http://87.110.94.40/.9...,./index.php" => "Servername-5",
 "http://87.110.94.40/.,..../index.php" => "Servername-6",
  "http://87.110.94.40/....,./index.php" => "Servername-7",
 "http://87.110.94.40/.,....9/index.php" => "Servername-8",
  "http://87.110.94.40/9..56..,./index.php" => "Servername-9",
 "http://87.110.94.40/.9,..../index.php" => "Servername-10",
 "http://87.110.94.40/.,..98796../index.php" => "Servername-4",
  "http://87.110.94.40/.9..67867.,./index.php" => "Servername-5",
 "http://87.110.94.40/.,...68./index.php" => "Servername-6",
  "http://87.110.94.40/....68678,./index.php" => "Servername-7",
 "http://87.110.94.40/.,..6868..9/index.php" => "Servername-8",
  "http://87.110.94.40/9..6868..,./index.php" => "Servername-9",
 "http://87.110.94.40/.9,.68686868.../index.php" => "Servername-10",
 "http://87.110.94.40/.,..68689../index.php" => "Servername-4",
  "http://87.110.94.40/.9..68686.,./index.php" => "Servername-5",
 "http://87.110.94.40/.,..66666../index.php" => "Servername-6",
  "http://87.110.94.40/...8888.,./index.php" => "Servername-7",
 "http://87.110.94.40/.,..999..9/index.php" => "Servername-8",
  "http://87.110.94.40/9....,./index.php" => "Servername-9",
 "http://87.110.94.40/.9,..../index.php" => "Servername-10", 
 "http://87.110.94.40/..99,.../index.php" => "Servername-11"
 );   
 
 //Точное название папкок от куда берем скрины (например, названия папок отсканированных античитом - для меню и сортировки по мд5 ключу)
 $screenshots_anticheat_folders_name = array( 
 "black_screenshots",
 "possible",
 "cheater"
 ); 
  
  
  
  
  
  
$ssylka_sourcebans = 'http://zona-ato-game.ru/sourcebans/index.php'; 










///////////////////////////////////////////////////////////////////////////////////    
///////////////////////////////////////////////////////////////////////////////////   
////////////////////////       ADMIN PANEL       //////////////////////////////////   
///////////////////////////////////////////////////////////////////////////////////   
///////////////////////////////////////////////////////////////////////////////////  

/* ########################################################## */
/* ########################################################## */ 
/* #########################    DEMOS    #####################*/   
 
 $demos_array = array( 
 "http://87.110.94.40/....." => "Servername-1",
 "http://87.110.94.40/....." => "Servername-2",
 "http://87.110.94.40/....." => "Servername-3"
 );    
 

 
 
 
/* ########################################################## */
/* ########################################################## */ 
/* ####  PLAYERS STATUS {vip, guest, administrator...}   #### */   
 
 $status = 1; // 1 - on 0 - off 
 
 $steam_users_status_id = array(
 "124yt124124" => "Админ",
 "f124y12y412" => "Admin",  
 "7124y214y21y4" => "Admin2"

 );	
	
	

 
/////////////////////// PLUGINS ///////////////////////// 






/* ########################################################## */
/* ########################################################## */ 
/* ####                VIP BONUS REKLAMA                 #### */ 



$vip_bonus_reklama_1 = 
'<!-- admitad.banner: izvl34ia7i8ee6da7c3b16525dc3e8 Aliexpress WW -->
<a target="_blank" rel="nofollow" href="https://alitems.com/g/izvl34ia7i8ee6da7c3b16525dc3e8/?i=4"><img width="160" height="600" border="0" src="https://ad.admitad.com/b/izvl34ia7i8ee6da7c3b16525dc3e8/" alt="Aliexpress WW"/></a>
<!-- /admitad.banner -->
';


$vip_bonus_reklama_2 = 
'<!-- admitad.banner: ud5rnomdxc8ee6da7c3b16525dc3e8 Aliexpress WW -->
<a target="_blank" rel="nofollow" href="https://alitems.com/g/ud5rnomdxc8ee6da7c3b16525dc3e8/?i=4"><img width="160" height="600" border="0" src="https://ad.admitad.com/b/ud5rnomdxc8ee6da7c3b16525dc3e8/" alt="Aliexpress WW"/></a>
<!-- /admitad.banner -->
';

 
