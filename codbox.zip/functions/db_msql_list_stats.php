﻿<?php
if (!empty($pgsearch))
  $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_pg = "'.$pgsearch.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 	 
 
else if (!empty($search))
  $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_guid = "'.$search.'" LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 	 
 
 else if (!empty($search_nickname)){
	 
$keyword=$search_nickname;	      
	$sql='SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_player LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   } 
else if ((!empty($server))&&(!empty($search_time))){
	 
$keyword=$search_time;	      
	$sql='SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t0.s_lasttime LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   }   
else if (!empty($search_time)){
	 
$keyword=$search_time;	      
	$sql='SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_lasttime LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
   } 
else if ((!empty($server))&&(!empty($search_heads)))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_heads+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 
else if ((!empty($server))&&(!empty($search_skill)))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 

else if ((!empty($server))&&(!empty($search_ratiokd)))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'"  and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_ratio+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  
 
 
 
else if ((!empty($server))&&(!empty($search_deaths)))
  	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'"  and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_deaths+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  
 
 

else if ((!empty($server))&&(!empty($search_kills)))
  $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 
else if ((!empty($server))&&(!empty($search_knife)))
 $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_melle+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
else if (!empty($server))
     $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);  



else if (!empty($search_kills))
     $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 



else if (!empty($search_deaths))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_deaths and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_deaths+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 

	 
else if (!empty($search_ratiokd))
		 	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_ratio and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_ratio+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 

else if (!empty($search_heads))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_heads and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_heads+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
 
 
	 
else if (!empty($search_skill))
	$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_skill and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t2.w_skill+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 

 
else if (!empty($search_grenades))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_grenade ORDER BY (s_grenade+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	 


else if (!empty($search_knife))
$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_melle and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_melle+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 


else if (!empty($search_suecides))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_suicids ORDER BY (s_suicids+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	 
else if (!empty($search_geo))
$reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t2.w_geo="'.$search_geo.'" and t1.s_kills >= '.$kills_limiter_top.'
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 
else if (!empty($search_cfour))
 $reponse = $bdd->query('SELECT * FROM db_stats_1 where s_c4 ORDER BY (s_c4+0) DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total);	

else if ((!empty($server)) && (!empty($paages)))
 $reponse = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t0.s_port="'.$server.'"  and t1.s_kills >= 300
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total); 
 

else
{	
$datetime = date('Y-m');
 $keyword=$datetime;	      
	$sql='SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg where t1.s_kills and t0.s_lasttime LIKE :keyword
 ORDER BY (t1.s_kills+0)  DESC LIMIT ' . $premierMessageAafficher . ', ' . $top_main_total;  
 
$reponse=$bdd->prepare($sql);
$reponse->bindValue(':keyword','%'.$keyword.'%');
$reponse->execute();
}
 
 	
 /////////}