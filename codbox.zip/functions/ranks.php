<?php

$ranked = array(
30 => "rank:1 name:Рядовой image:1-3.png",
60 => "rank:2 name:Рядовой Класс 1 image:1-3.png",
120 => "rank:3 name:Рядовой Класс 2 image:1-3.png",
270 => "rank:4 name:Ефрейтор image:4-6.png",
480 => "rank:5 name:Ефрейтор 1 image:4-6.png",
750 => "rank:6 name:Ефрейтор 2 image:4-6.png",
1080 => "rank:7 name:Капрал image:7-9.png",
1470 => "rank:8 name:Капрал 1 image:7-9.png",
1920 => "rank:9 name:Капрал 2 image:7-9.png",
2430 => "rank:10 name:Младший сержант image:10-12.png",
3000 => "rank:11 name:Младший сержант 1 image:10-12.png",
3650 => "rank:12 name:Младший сержант 2 image:10-12.png",
4380 => "rank:13 name:Старший сержант image:13-15.png",
5190 => "rank:14 name:Старший сержант 1 image:13-15.png",
6080 => "rank:15 name:Старший сержант 2 image:13-15.png",
7050 => "rank:16 name:Комендор-сержант image:16-18.png",
8100 => "rank:17 name:Комендор-сержант 1 image:16-18.png",
9230 => "rank:18 name:Комендор-сержант 2 image:16-18.png",
10440 => "rank:19 name:Старшина image:19-21.png",
11730 => "rank:20 name:Старшина 1 image:19-21.png",
13100 => "rank:21 name:Старшина 2 image:19-21.png",
14550 => "rank:22 name:Мастер Сержант image:22-24.png",
16080 => "rank:23 name:Мастер Сержант 1 image:22-24.png",
17690 => "rank:24 name:Мастер Сержант 2 image:22-24.png",
19380 => "rank:25 name:2-й Лейтенант image:25-27.png",
21150 => "rank:26 name:2-й Лейтенант 1 image:25-27.png",
23000 => "rank:27 name:2-й Лейтенант 2 image:25-27.png",
24930 => "rank:28 name:1-й Лейтенант image:28-30.png",
26940 => "rank:29 name:1-й Лейтенант 1 image:28-30.png",
29030 => "rank:30 name:1-й Лейтенант 2 image:28-30.png",
31240 => "rank:31 name:Капитан image:31-33.png",
33570 => "rank:32 name:Капитан 1 image:31-33.png",
36020 => "rank:33 name:Капитан 2 image:31-33.png",
38590 => "rank:34 name:Майор image:34-36.png",
41280 => "rank:35 name:Майор 1 image:34-36.png",
44090 => "rank:36 name:Майор 2 image:34-36.png",
47020 => "rank:37 name:Подполковник image:37-39.png",
50070 => "rank:38 name:Подполковник 1 image:37-39.png",
53240 => "rank:39 name:Подполковник 2 image:37-39.png",
56530 => "rank:40 name:Полковник image:40-42.png",
59940 => "rank:41 name:Полковник 1 image:40-42.png",
63470 => "rank:42 name:Полковник 2 image:40-42.png",
67120 => "rank:43 name:Бригадный Генерал image:43-45.png",
70890 => "rank:44 name:Бригадный Генерал 1 image:43-45.png",
74780 => "rank:45 name:Бригадный Генерал 2 image:43-45.png",
78790 => "rank:46 name:Генерал-майор image:46-48.png",
82920 => "rank:47 name:Генерал-майор 1 image:46-48.png",
87170 => "rank:48 name:Генерал-майор 2 image:46-48.png",
91540 => "rank:49 name:Генерал-лейтенант image:49-51.png",
96030 => "rank:50 name:Генерал-лейтенант 1 image:49-51.png",
100640 => "rank:51 name:Генерал-лейтенант 2 image:49-51.png",
105370 => "rank:52 name:Генерал-полковник image:52-54.png",
110220 => "rank:53 name:Генерал-полковник 1 image:52-54.png",
115190 => "rank:54 name:Генерал армии image:52-54.png",
120280 => "rank:55 name:Маршал image:55.png",
 );

 
 
 /* PRESTIGE COD4*/
 
 function prestige_image($prestige) 
 { 
 if( $prestige < 120 && $prestige >= 60 ){
$image = "prestige/Rank_Prestige_2_CoD4.png";
return $image;

}else if( $prestige < 240 && $prestige >= 120 ){
$image = "prestige/Rank_Prestige_3_CoD4.png";
return $image;

}else if( $prestige < 480 && $prestige >= 240 ){
$image = "prestige/Rank_Prestige_4_CoD4.png";
return $image;

}else if( $prestige < 960 && $prestige >= 480 ){
$image = "prestige/Rank_Prestige_7_CoD4.png";
return $image;

}else if( $prestige < 1920 && $prestige >= 960 ){
$image = "prestige/Rank_Prestige_8_CoD4.png";
return $image;

}else if( $prestige < 3000 && $prestige >= 1920 ){
$image = "prestige/Rank_Prestige_9_CoD4.png";
return $image;

}else if( $prestige >= 3000 ){
$image = "prestige/Rank_Prestige_10_CoD4.png";
return $image;

} else {

$image = "prestige/null.png"; 
return $image;
 }}
 
 
function prestige_info($prestige) 
 { 
 if( $prestige < 120 && $prestige >= 60 ){
$image = "1 PR - 60/$prestige games";
return $image;

}else if( $prestige < 240 && $prestige >= 120 ){
$image = "2 PR - 120/$prestige games";
return $image;

}else if( $prestige < 480 && $prestige >= 240 ){
$image = "3 PR - 240/$prestige games";
return $image;

}else if( $prestige < 960 && $prestige >= 480 ){
$image = "4 PR - 480/$prestige games";
return $image;

}else if( $prestige < 1920 && $prestige >= 960 ){
$image = "5 PR - 960/$prestige games";
return $image;

}else if( $prestige < 3000 && $prestige >= 1920 ){
$image = "6 PR - 1920/$prestige games";
return $image;

}else if( $prestige >= 3000 ){
$image = "7 PR - 3000/$prestige games";
return $image;

} else {

$image = "No PR ".$prestige."/60 games"; 
return $image;
 }} 

 