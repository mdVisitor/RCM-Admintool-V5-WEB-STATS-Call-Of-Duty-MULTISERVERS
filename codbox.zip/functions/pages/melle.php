﻿<?php

$filemtime=filemtime($crn_melle);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_melle) != 0))
      if (time()-$filemtime < 5600)  //21600  6 hours   
			{	
				
if(filesize($crn_melle) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t1.s_melle+0)  DESC LIMIT 1');  
while ($row = $re->fetch())	
{	
   $knifes = $row['s_melle'];
	$knifer =  $row['s_player'];
	$knifer_guid = $row['s_guid'];
}  

 	$fpl = fopen($crn_melle, 'w+');
	fwrite($fpl, $knifer_guid."%".$knifer."%".$knifes);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_melle);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$knifer_guid = trim($infff[0]);		
$knifer = trim($infff[1]);	
$knifes = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 5600) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 300
 ORDER BY (t1.s_melle+0)  DESC LIMIT 1');  
while ($row = $re->fetch())	
{	
    $knifes = $row['s_melle'];
	$knifer =  $row['s_player'];
	$knifer_guid = $row['s_guid'];
}

 	$fpl = fopen($crn_melle, 'w+');
	fwrite($fpl, $knifer_guid."%".$knifer."%".$knifes);	
    fclose($fpl);
}

