﻿<?php

 $filemtime=filemtime($crn_heads);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_heads) != 0))
      if (time()-$filemtime < 2600)  //21600  6 hours   
			{	
				
if(filesize($crn_heads) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t1.s_heads+0)  DESC LIMIT 1');  
 
 
while ($row = $re->fetch())	
{	
    $heads = $row['s_heads'];
	$headers =  $row['s_player'];
	$headers_guid = $row['s_guid'];
}  

 	$fpl = fopen($crn_heads, 'w+');
	fwrite($fpl, $headers_guid."%".$headers."%".$heads);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_heads);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$headers_guid = trim($infff[0]);		
$headers = trim($infff[1]);	
$heads = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 2600) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t1.s_heads+0)  DESC LIMIT 1');  
 
 
while ($row = $re->fetch())	
{	
    $heads = $row['s_heads'];
	$headers =  $row['s_player'];
	$headers_guid = $row['s_guid'];
}  

 	$fpl = fopen($crn_heads, 'w+');
	fwrite($fpl, $headers_guid."%".$headers."%".$heads);	
    fclose($fpl);
}

