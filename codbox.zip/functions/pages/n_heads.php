﻿<?php
$filemtime=filemtime($crn_n_heads);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_n_heads) != 0))
      if (time()-$filemtime < 18800)  //21600  6 hours   
			{	
				
if(filesize($crn_n_heads) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.n_heads+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $n_heads = $row['n_heads'];
	$n_headers = $row['s_player'];
	$n_headers_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_n_heads, 'w+');
	fwrite($fpl, $n_headers_guid."%".$n_headers."%".$n_heads);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_n_heads);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$n_headers_guid = trim($infff[0]);		
$n_headers = trim($infff[1]);	
$n_heads = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 18800) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.n_heads+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $n_heads = $row['n_heads'];
	$n_headers = $row['s_player'];
	$n_headers_guid = $row['s_guid'];
}


 	$fpl = fopen($crn_n_heads, 'w+');
	fwrite($fpl, $n_headers_guid."%".$n_headers."%".$n_heads);	
    fclose($fpl);
}
