﻿<?php
$filemtime=filemtime($crn_n_kills);
            //if ((time()-$filemtime>= 100)&& (filesize($crn_n_kills) != 0))
      if (time()-$filemtime < 11600)  //21600  6 hours   
			{	
				
if(filesize($crn_n_kills) == 0)
{
	
$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.n_kills+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $n_kills = $row['n_kills'];
	$n_killkiller = $row['s_player'];
	$n_killkiller_guid = $row['s_guid'];
}

 	$fpl = fopen($crn_n_kills, 'w+');
	fwrite($fpl, $n_killkiller_guid."%".$n_killkiller."%".$n_kills);	
    fclose($fpl);
    
	}
	else
	{
		
$fpl = file($crn_n_kills);
$dfc = $fpl[0];

$infff = explode("%", $dfc);

$n_killkiller_guid = trim($infff[0]);		
$n_killkiller = trim($infff[1]);	
$n_kills = trim($infff[2]);
	
	}
	
	
	
}
else if (time()-$filemtime>= 11600) 
{

$re = $bdd->query('SELECT t0.*, t1.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_1) 
 t1 ON 
 t0.s_pg = t1.s_pg
    join 
 (select * from db_stats_2) 
 t2 ON 
 t1.s_pg = t2.s_pg '.$serverxxx.' t1.s_kills >= 1000
 ORDER BY (t2.n_kills+0)  DESC LIMIT 1');  
 
while ($row = $re->fetch())	
{	
    $n_kills = $row['n_kills'];
	$n_killkiller = $row['s_player'];
	$n_killkiller_guid = $row['s_guid'];
}

 	$fpl = fopen($crn_n_kills, 'w+');
	fwrite($fpl, $n_killkiller_guid."%".$n_killkiller."%".$n_kills);	
    fclose($fpl);
}
