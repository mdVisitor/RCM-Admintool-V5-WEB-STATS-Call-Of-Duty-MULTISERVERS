﻿<?php
	
if (!empty($pgsearch))
{
 $reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_pg like '".$pgsearch."'");
}
else if (!empty($infomore))
{
 $reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_guid like '".$search_nickname."'");	 //s_guid='$search'   s_guid like "%'.$search.'%"	
else if (!empty($search))
{
 $reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_guid like '".$search."'");	 //s_guid='$search'   s_guid like "%'.$search.'%"
}
else if (!empty($search_nickname))
{	
 $reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_player like '".$search_nickname."'");	 //s_guid='$search'   s_guid like "%'.$search.'%"
}
else if ((!empty($search_kills))&&(!empty($server)))
{ 
$reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_port='$server'");
}
else if (!empty($server))
{ 
$reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_0 where s_port='$server'"); 
}
else if (!empty($search_geo))
{
$reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_2 where w_geo='".$search_geo."'");
}
else
{	
$reponse=$bdd ->query("SELECT COUNT(*) AS id FROM db_stats_1 where s_kills >= ".$kills_limiter_top."");
}