<?php

  $take_screen = "Забрать скриншот! Жди 5 сек.";
  $t_players = "Игроки";
  
  $t_server = "Сервер";
  $t_time = "Время";
  $t_city = "Страна";
  $t_nickname = "Имя";
  $t_nickmy = "Моя";
  $t_messages = "Сообщения";
  
  
  $t_tottal = "Всего";
  $t_ago = "Тому назад";  
  $t_series = "Серии подряд";
  $t_damages = "Урон";
  $t_knife = "Ножом";
  $t_today = "Сегодня";
  $t_playing = "В игре";
  $t_info = "Инфо";
  $t_skill = "Навык";
  $t_accuracy = "Точность";
  $t_heads = "В голову";
  $t_kd = "Ф/П";
  $t_deaths = "Потери";
  $t_kills = "Фраги";
  $t_soul = "Сам";
  $t_general_stats = "Лидеры всех серверов";
  $t_search = 'Поиск';
  $t_gen = 'Время генерации:';
  $t_top = 'Лидеры';
  $t_total_players = 'Общее количество игроков'; //Total players on all servers
  $t_killx2 = ' количество фрагов в таблице лидеров'; //kills on top
  $t_tsek = 'сек.';
  $t_cachedw = 'Сохранено в '; //Cached with
  
  $t_geo_tops = ' Лидирующие страны по посещаемости '; //GEO TOP
  
  $t_page_first = 'Первая';
  $t_page_pre = 'Предыдущая';
  $t_page_next = 'Следующая';
  $t_page_last = 'Последняя';
  $t_page_all = 'Все страницы';
  
  $t_top_today =  'Лидеры сегодня'; //'TOP TODAY';
  $t_top_week =  'Лидеры недели'; //'TOP TODAY';