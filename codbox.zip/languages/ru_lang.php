<?php

  $take_screen = "Забрать скриншот! Жди 5 сек.";
  $t_players = "Игроки";
  
  $t_server = "Сервер";
  $t_time = "Время";
  $t_city = "Страна";
  $t_nickname = "Имя";
  $t_nickmy = "Моя";
  $t_messages = "Сообщения";
  
  
  $t_tottal = "Всего";
  $t_ago = "Тому назад";  
  $t_series = "Серии подряд";
  $t_damages = "Урон";
  $t_knife = "Ножом";
  $t_today = "Сегодня";
  $t_playing = "В игре";
  $t_info = "Инфо";
  $t_skill = "Навык";
  $t_accuracy = "Точность";
  $t_heads = "В голову";
  $t_kd = "Ф/П";
  $t_deaths = "Потери";
  $t_kills = "Фраги";
  $t_soul = "Сам";
  $t_general_stats = "Лидеры всех серверов";
  $t_search = 'Поиск';
  $t_gen = 'Время генерации:';
  $t_top = 'Лидеры';
  $t_total_players = 'Общее количество игроков'; //Total players on all servers
  $t_killx2 = ' количество фрагов в таблице лидеров'; //kills on top
  $t_tsek = 'сек.';
  $t_cachedw = 'Сохранено в '; //Cached with
  
  $t_geo_tops = ' Лидирующие страны по посещаемости '; //GEO TOP
  
  $t_page_first = 'Первая';
  $t_page_pre = 'Предыдущая';
  $t_page_next = 'Следующая';
  $t_page_last = 'Последняя';
  $t_page_all = 'Все страницы';
  
  $t_top_today =  'Лидеры сегодня'; //'TOP TODAY';
  $t_top_week =  'Лидеры недели'; //'TOP TODAY';
 
    $t_player_place = 'Позиция среди игроков сервера'; 
    $t_player_place_all = 'Позиция среди игроков всех серверов'; 	
    $t_player_place_skill = 'По навыку';
    $t_player_place_kills = 'По фрагам';	
    $t_player_place_heads = 'По попаданию в голову';
	
  $medals = 'Медали';
  $medals_pro = 'Про Медали';
  $medals_series = 'Медали Серий';
  $medals_anti = 'Анти медали';	
  
 
  $medals_killer  = 'По фрагам';
  $medals_headshots  = 'В голову';
  $medals_suicides = 'Суицид'; 
  $medals_knife = 'Мясник';
  $medals_skill = 'Навык';
  $medals_grenade = 'Граната';   
  $medals_cobra = 'Кобра';
  $medals_deaths = 'Потери';  
  $medals_series = 'Серия'; 
  
$hit_head = "Выстрелы в голову";			
$hit_torso_lower = "Торс Нижний";	
$hit_torso_upper = "Верхняя часть туловища";	
$hit_right_arm_lower = "Правая нижняя рука";	
$hit_left_leg_upper = "Верхняя левая нога";	
$hit_neck = "Шея";	
$hit_right_arm_upper = "Правая верхняя рука";	
$hit_left_hand = "Левая рука";	
$hit_left_arm_lower = "Левая нижняя рука";	
$hit_none = "";	
$hit_right_leg_upper = "Правая верхняя нога";	
$hit_left_arm_upper = "Верхняя левая рука";	
$hit_right_leg_lower = "Правая нога ниже";	
$hit_left_foot = "Левая нога";	
$hit_right_foot = "Правая нога";	
$hit_right_hand = "Правая рука";									
$hit_left_leg_lower = "Левая нога нижняя"; 


$playeed_date = "Дата";
$t_lasttime = "Последния охота";
$t_timee = "Первая охота";



$t_xyears = 'год';
$t_xmonth = 'мес';					 
$t_xday = 'дней';
$t_xhours  = 'ч';				 
$t_xmin = 'м';
$t_xsek = 'с';


///https://callofduty.fandom.com/ru/wiki/%D0%9F%D1%80%D0%B5%D1%81%D1%82%D0%B8%D0%B6
$prestige_0 = "Нет Престижа";
$prestige_1 = "Армейская Похвальная медаль";
$prestige_2 = "Медаль вьетнамской компании";
$prestige_3 = "Медаль службы персонала";
$prestige_4 = 'Орден Почётного легиона';
$prestige_5 = "Медаль освобождения Кувейта";
$prestige_6 = "Специальная служебная медаль";
$prestige_7 = "Крест лётных заслуг";
$prestige_8 = "Медаль гражданских действий";
$prestige_9 = "Медаль ранений";
$prestige_10 = "Военно-морской крест";


$bonus_slot_3d  = "ВЫ ВЫИГРЫВАЕТЕ VIP 3 дня!";
$bonus_slot_vip = "Вы выиграли VIP ";
$bonus_slot_days = "дней";
$bonus_slot_lose = "ТЫ ПРОИГРАЛ";
$bonus_slot_welcome = "Добро пожаловать";
$bonus_slot_spin = "СДЕЛАЙТЕ СПИН!";
$bonus_slot_spinning = "Крутится";

$bonus_slot_vb  = "Вип бонус!";
$bonus_slot_vbtxt  = "Ваш ип адрес отсутствует в базе серверов, нужен ваш реальный ip адрес!";
 


