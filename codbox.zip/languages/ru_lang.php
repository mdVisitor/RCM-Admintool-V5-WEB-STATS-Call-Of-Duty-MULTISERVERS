<?php

 $i_chatn_forver = 'На всегда!';
 $i_chat_ban  = '[Чат Блок]';
 $i_chat_exp   = '[Ч.Б. срок истек]';
 $i_chat_censored = '[Цензура]';


 $i_search = 'Поиск';
 $i_stats  = 'Статистика';
 $i_chat   = 'Чат';
 $i_status = 'Статус';
 $i_server = 'Сервер';
 $i_ban    = 'Бан';
 $i_unban  = 'РазБан';



//// МЕНЮ
  $menu_main       = 'Главная';
  $menu_medals     = 'Медали';
  $menu_chats       = 'Чат';
  $menu_chat_ban   = 'Банлист Чата';
  $menu_forum      = 'Форум';
  $menu_stats      = 'Статистика';
  $menu_geo        = 'Гео';
  $menu_banlist    = 'Банлист';
  $menu_blacklist  = 'Блэклист';
  $menu_status     = 'Статус';
  $menu_mamba      = 'Мамба';
  $menu_screens    = 'Скриншоты';  
  $menu_detected   = 'Подозрительные';
  

  $take_screen = "Забрать скриншот! Жди 5 сек.";
  $t_players = "Игроки";
  
  $t_total_games = "Игры";
  $t_kills_min = "Убил в минуту";
  
  $t_server = "Сервер";
  $t_time = "Время";
  $t_city = "Флаг";
  $t_nickname = "Имя";
  $t_nickmy = "Моя";
  $t_messages = "Сообщения";
  
  $moreinfo_more = "Больше информации...";
  $moreinfo_here = "Жми здесь!";
  
  $t_tottal = "Всего";
  $t_ago = "Тому назад";  
  $t_series = "Серии подряд";
  $t_damages = "Урон";
  $t_knife = "Ножом";
  $t_today = "Сегодня";
  $t_playing = "В игре";
  $t_info = "Инфо";
  $t_skill = "Навык";
  $t_accuracy = "Точность";
  $t_heads = "В голову";
  $t_kd = "Ф/П";
  $t_deaths = "Потери";
  $t_kills = "Фраги";
  $t_soul = "Сам";
  $t_general_stats = "Лидеры всех серверов";
  $t_search = 'Поиск';
  $t_gen = 'Время генерации:';
  $t_top = 'Лидеры';
  $t_total_players = 'Общее количество игроков'; //Total players on all servers
  $t_killx2 = ' количество фрагов в таблице лидеров'; //kills on top
  $t_tsek = 'сек.';
  $t_cachedw = 'Сохранено в '; //Cached with
  
  $t_geo_tops = ' Лидирующие страны по посещаемости '; //GEO TOP
  
  $t_page_first = 'Первая';
  $t_page_pre = 'Предыдущая';
  $t_page_next = 'Следующая';
  $t_page_last = 'Последняя';
  $t_page_all = 'Все страницы';
  
  $t_top_today =  'Лидеры сегодня'; //'TOP TODAY';
  $t_top_week =  'Лидеры недели'; //'TOP TODAY';
 
    $t_player_place = 'Позиция среди игроков сервера'; 
    $t_player_place_all = 'Позиция среди игроков всех серверов'; 	
    $t_player_place_skill = 'По навыку';
    $t_player_place_kills = 'По фрагам';	
    $t_player_place_heads = 'По попаданию в голову';
	
  $medals = 'Медали';
  $medals_pro = 'Про Медали';
  $medals_series = 'Медали Серий';
  $medals_anti = 'Анти медали';	
  
 
  $medals_killer  = 'По фрагам';
  $medals_headshots  = 'В голову';
  $medals_suicides = 'Суицид'; 
  $medals_knife = 'Мясник';
  $medals_skill = 'Навык';
  $medals_grenade = 'Граната';   
  $medals_cobra = 'Кобра';
  $medals_deaths = 'Потери';  
  $medals_series = 'Серия'; 
  
  
  
$hit_head = "Выстрелы в голову";			
$hit_torso_lower = "Торс Нижний";	
$hit_torso_upper = "Верхняя часть туловища";	
$hit_right_arm_lower = "Правая нижняя рука";	
$hit_left_leg_upper = "Верхняя левая нога";	
$hit_neck = "Шея";	
$hit_right_arm_upper = "Правая верхняя рука";	
$hit_left_hand = "Левая рука";	
$hit_left_arm_lower = "Левая нижняя рука";	
$hit_none = "";	
$hit_right_leg_upper = "Правая верхняя нога";	
$hit_left_arm_upper = "Верхняя левая рука";	
$hit_right_leg_lower = "Правая нога ниже";	
$hit_left_foot = "Левая нога";	
$hit_right_foot = "Правая нога";	
$hit_right_hand = "Правая рука";									
$hit_left_leg_lower = "Левая нога нижняя"; 

$playeed = "Играл";
$playeed_date = "Дата";
$t_lasttime = "Последния охота";
$t_timee = "Первая охота";



$t_xyears = 'год';
$t_xmonth = 'мес';					 
$t_xday = 'дней';
$t_xhours  = 'ч';				 
$t_xmin = 'м';
$t_xsek = 'с';

$lang_skill_history = 'История';
$lang_skill_history_sk_archive = 'Архив навыка';
$lang_skill_history_sk_record = 'Рекорд навыка';
$lang_skill_history_sk_avg = 'Средний навык';
$lang_skill_history_kd_record = 'Рекорд Ф/П (У/С)';
$lang_skill_history_kd_avg = 'Средний Ф/П (У/С)';


///https://callofduty.fandom.com/ru/wiki/%D0%9F%D1%80%D0%B5%D1%81%D1%82%D0%B8%D0%B6
$prestige_0 = "Нет Престижа";
$prestige_1 = "Армейская Похвальная медаль";
$prestige_2 = "Медаль вьетнамской компании";
$prestige_3 = "Медаль службы персонала";
$prestige_4 = 'Орден Почётного легиона';
$prestige_5 = "Медаль освобождения Кувейта";
$prestige_6 = "Специальная служебная медаль";
$prestige_7 = "Крест лётных заслуг";
$prestige_8 = "Медаль гражданских действий";
$prestige_9 = "Медаль ранений";
$prestige_10 = "Военно-морской крест";


$bonus_slot_3d  = "ВЫ ВЫИГРЫВАЕТЕ VIP 3 дня!";
$bonus_slot_vip = "Вы выиграли VIP ";
$bonus_slot_days = "дней";
$bonus_slot_lose = "ТЫ ПРОИГРАЛ";
$bonus_slot_welcome = "Добро пожаловать";
$bonus_slot_spin = "СДЕЛАЙТЕ СПИН!";
$bonus_slot_spinning = "Крутится";

$bonus_slot_vb  = "Вип бонус!";
$bonus_slot_vbtxt  = "Ваш ип адрес отсутствует в базе серверов, нужен ваш реальный ip адрес!";
 


