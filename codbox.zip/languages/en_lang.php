<?php

  $take_screen = "Take Screenshot! Wait 5 sec.";
  $t_players = "Players";
  
  $t_server = "Server";
  $t_time = "Time";
  $t_city = "Geo";
  $t_nickname = "Name";
  $t_nickmy = "My";
  $t_messages = "Messages";
  
  
  $t_tottal = "Total";
  $t_ago = "Ago";
  $t_series = "Series in a row";
  $t_damages = "Damage";
  $t_knife = "Knife";
  $t_today = "Today";
  $t_playing = "Playing";
  $t_info = "Info";
  $t_skill = "Skill";
  $t_accuracy = "Accuracy";
  $t_heads = "Heads";
  $t_kd = "K/D";
  $t_deaths = "Deaths";
  $t_kills = "Kills";
  $t_soul = "Soul";
  $t_general_stats = "Main top";
  $t_search = 'Search';
  $t_gen = 'Generation time:';
  $t_top = 'Top';
  $t_total_players = 'Total players on all servers'; //Total players on all servers
  $t_killx2 = ' kills on top'; //kills on top
  $t_tsek = ' sec.';
  $t_cachedw = 'Cached with '; //Cached with
  
  $t_geo_tops = ' GEO TOP '; //GEO TOP
  
  $t_page_first = 'First';
  $t_page_pre = 'Previous';
  $t_page_next = 'Next';
  $t_page_last = 'Last';
  $t_page_all = 'All Pages';
  
  $t_top_today =  'Today top'; //'TODAY TOP ';
  $t_top_week =  'Week top'; //'WEEK TODAY';