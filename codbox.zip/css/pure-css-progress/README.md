# Pure CSS Progress Bars

Pure CSS Progress Bars

### Screenshot

<img src="https://raw.githubusercontent.com/rkchauhan/pure-css-progress-bars/master/assets/imgs/screenshot-2.png" alt="Screenshot" />

### DEMO

[See the Online demo](http://rkchauhan.github.io/pure-css-progress-bars/)

### How to use

Include `cssprogress.min.css` in your target html file.

```html
<link rel="stylesheet" href="cssprogress.min.css" />

```

### License

[MIT](http://opensource.org/licenses/mit-license.php)