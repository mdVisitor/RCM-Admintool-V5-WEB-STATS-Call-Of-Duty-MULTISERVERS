<?php 

$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");

	if ( !empty($_COOKIE['user_online_login']) and !empty($_COOKIE['user_online_key']) ) {
			//Пишем логин и ключ из КУК в переменные (для удобства работы):
			$login = $_COOKIE['user_online_login']; 
			$key = $_COOKIE['user_online_key']; //ключ из кук (аналог пароля, в базе поле cookie)
			$login = $key;
			$keyxxx = $key;
			$passsword = $key;
			
			$xz = $login;
			$_POST['pass'] = $passsword;
			$_GET['pass'] = $passsword;
	    } 