<?php
ini_set("display_errors",1);
error_reporting(E_ALL);
session_start(); 
$key = '';
if (empty($_SESSION['username'])) 
	$_SESSION['username']=0;

if (!empty($_SESSION['username'])){
	$_GET['pass'] = $_SESSION['username'];
	 $passsword = $_SESSION['username'];	
}
 
if ((!empty($_GET['pass'])) && (!empty($_SESSION))) 
   $_POST['pass'] = $passsword;  
   
/* ####################################################################################### */
/* ####################################################################################### */
/* ####################################################################################### */

$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");  
include_once("functions/words.php"); 
include_once("functions/chatdb_archive.php"); 
include_once("functions/functions.inc.php"); include_once("langctrl.php");  
  
$chatdb = $chatdb_path;
function hx($sc)
 {
  $sc = str_replace(array(
    "redirect.php"
  ), '', $sc);
  return $sc . "";
 }
$cpath = hx(__FILE__);


if (!empty($passsword)){		
foreach ($steam_users_id as $passw => $xy){
  if(md5($passsword) == md5($passw))
  {
	  $key=1;
	  $xz = $xy;
  }
  
  }} else $key = '';	
  

if (is_numeric($key))
	$key = $key.'.1';   


if(empty($key))
	die('GOODBYE HACHER!');

if(!file_exists($cpath . 'screenshots/thumbs/'))
mkdir($cpath . 'screenshots/thumbs/'); 

if(!file_exists($cpath . 'screenshots/thumbs/'))
mkdir($cpath . 'screenshots/banned/');

define('DIRECTORY', $cpath . 'screenshots/banned/');
/* ####################################################################################### */
/* ####################################################################################### */
/* ####################################################################################### */
if (!empty($_GET['xnickname']))
    $xnickname = $_GET['xnickname'];
else
    $xnickname = '';
if (!empty($_GET['xurl']))
    $xurl = $_GET['xurl'];
else
    $xurl = '';
if (!empty($_GET['xip']))
    $xip = $_GET['xip'];
else
    $xip = '';



if (!empty($_GET['xnickname'])) {
//Laroxxx bred initialization xD
list($ipg, $n1) = explode('Guid', $xnickname);
list($guid, $nothing) = explode('Name', $n1);
$guid = trim($guid);
list($ipg, $name1) = explode('Name', $xnickname);
list($namer, $nothing1) = explode('Date', $name1);
$namer = trim($namer);
$xurl  = urldecode($xurl);
$xurl  = trim($xurl);
$xurl  = str_replace('-sm.jpg', '.jpg', $xurl);
$xurl  = str_replace('-la.jpg', '.jpg', $xurl);
$xurl  = str_replace('_data/i/', '', $xurl);
$xurl  = str_replace('i.php?/', '', $xurl);
$xurl  = urlencode($xurl);
}




if (!empty($_GET['chnick']))
    $namer = $_GET['chnick'];
else
    $namer = '';

if (!empty($_GET['sservv']))
    $sservv = $_GET['sservv'];
else
    $sservv = '';

if (!empty($_GET['chguid'])){
    $guid = $_GET['chguid'];
	$guid = trim($guid);
}
else
    $guid = '';



$namer = trim($namer);
$xurl  = urldecode($xurl);
$xurl  = trim($xurl);
$xurl  = str_replace('-sm.jpg', '.jpg', $xurl);
$xurl  = str_replace('-la.jpg', '.jpg', $xurl);
$xurl  = str_replace('_data/i/', '', $xurl);
$xurl  = str_replace('i.php?/', '', $xurl);
$xurl  = urlencode($xurl);

if (!empty($_GET['xurl'])) {
    try {
     if(empty($Msql_support))
    $bdd = new PDO('sqlite:' . $chatdb);
      else
	  {	  	  
$dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
$opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
	  } 
        $reponse = $bdd->query("SELECT x_db_guid,x_db_ip FROM x_db_players where x_db_guid = '$guid' limit 1");
        while ($xn = $reponse->fetch()) {
            if (!empty($xn['x_db_ip']))
                $ipp = $xn['x_db_ip'];
        }
     
if(file_exists($cpath . 'databases/screenshots.rcm')){
	
	
if (!empty($_GET['xurl'])) {
$decoded_image_url = urldecode($_GET['xurl']);
$sservv = urldecode($sservv);
$content = file_get_contents($decoded_image_url);
$imagname = basename($decoded_image_url);
file_put_contents(DIRECTORY . $imagname, $content, FILE_APPEND | LOCK_EX);
}
	$timej = date("d-m-Y H:i:s");
    $ddater = strtotime($timej);
	
    $screens = new PDO('sqlite:'. $cpath . 'databases/screenshots.rcm');
//$sql = "INSERT INTO screens (guid,player,image,reason,size,time) VALUES ('".$guid."','".$namer."','0','1','0','0')";
//$screens->exec($sql);
$screens->query("UPDATE screens SET player='{$namer}', reason='1' WHERE guid = $guid");	



 $screens_banned = new PDO('sqlite:'. $cpath . 'databases/screenshots_banned.rcm');	

 $bbndd = $ssylka_na_codbox.'screenshots/banned/'.$imagname;

 $sql = "INSERT INTO screens (guid,player,image,reason,size,time,dater,server,nameserver) VALUES ('".$guid."','".$namer."','".$bbndd."','1','0','".$timej."','".$ddater."','0','".$sservv."')";	
 $screens_banned->exec($sql);
 $screens_banned->query("UPDATE screens SET player='{$namer}', reason='1' WHERE guid = $guid");

	
	$screens = NULL;
}	 
	}
    catch (Exception $e) {
        die('Errors : ' . $e->getMessage());
    }

	
	
	
$n_spg = 0;	
	
try
{	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    
    $bdd = new PDO($dsn, $db_user, $db_pass);			  	  
   
   
$re=$bdd ->query("SELECT s_pg,s_guid FROM db_stats_0 where s_guid = $guid limit 1");
while ($row = $re->fetch())	
{	
  $n_spg = $row['s_pg'];
}
 
   
$bdd->query("UPDATE db_stats_2 SET n_heads=14 WHERE s_pg='" . $n_spg . "'");

	
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}	
	
	
	
	
	
	
	
	
	
}
 ///////////////////////////////////////////////////////////
 //exit;
 
 
if (!empty($_GET['xurl'])) {
if (empty($ipp))
    $ipp = '';
 header("Location: http://zona-ato-game.ru/sourcebans/index.php?p=admin&c=bans&xnickname=" . $namer . "&xguid=" . $guid . "&xurl=" . $xurl . "&xip=" . $ipp . "");
 die();
}



 
if (!empty($_GET['chnick'])){
 
if (!empty($_GET['chnick']))
    $chnick = $_GET['chnick'];
else
    $chnick = '';
 
if (!empty($_GET['chip']))
    $chip = $_GET['chip'];
else
    $chip = '';
 
if (!empty($_GET['chguid'])){
    $chguid = $_GET['chguid'];
	$chguid = trim($chguid);
}
else
    $chguid = '';
 
if (empty($_GET['xurl'])) {
	if (empty($chip)) {
    try {
         if(empty($Msql_support))
    $bdd = new PDO('sqlite:' . $chatdb);
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
$opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
	  } 
        $reponse = $bdd->query("SELECT x_db_guid,x_db_ip FROM x_db_players where x_db_guid = '$guid' limit 1");
        while ($xn = $reponse->fetch()) {
            if (!empty($xn['x_db_ip']))
                $cip = $xn['x_db_ip'];
        }
	
    }
    catch (Exception $e) {
        die('Errors : ' . $e->getMessage());
    }
}}

if (empty($_GET['xurl'])) {
if (!empty($chguid)) {
	if (empty($cip))
       $cip = '...';
   	if (!empty($chip))
       $cip = $chip;
header("Location: http://zona-ato-game.ru/sourcebans/index.php?p=admin&c=bans&xnickname=" . $chnick . "&xguid=" . $chguid . "&xurl=" . $xurl . "&xip=" . $cip . "");
die();
}}
}



 