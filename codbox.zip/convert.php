﻿<?php
///  httpget("https://zona-ato-game.ru/codbox/convert.php?port="+ level.scr_db_port_servera +"&guid="+ self getGuid() +"", ::callback);
if (!empty($_GET['port'])) 
   $server_port = $_GET['port']; 
else
   $server_port = 0;

if (!empty($_GET['guid'])) {
   $guid = $_GET['guid'];
}else
    $guid = 0;

 			$hid = trim($server_port.$guid);	
			$hid = abs(hexdec(crc32($hid)));
echo $hid;		
?>



