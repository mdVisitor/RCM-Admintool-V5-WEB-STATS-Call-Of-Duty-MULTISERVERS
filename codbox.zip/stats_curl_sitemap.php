<?php

set_time_limit(0);
include("functions/sitemap.class.php"); 
$sitemap = new sitemap();
$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");

//игнорировать ссылки с расширениями:
$sitemap->set_ignore(array("javascript:", ".html", ".css", ".js", ".ico", ".jpg", 
".png", ".jpeg", ".swf", ".gif", ".log", "/css_js", "/databases", "/cache", "/e_monitor", 
"/chat_archive", "/flags-mini", "/fonts", "/functions", "/img", "/js", "/upload", "/css",
"/res", "/screenshots", "/scss", "chat.php", "status.php", "ajaxfile.php", "chat_ban.php", 
"chat_ban_list.php", ".sqlite", "redirect.php", "screenshots.php", "screenshots_cron.php", 
"top.php", "vip_bonus.php", "ajaxfile.php", "langctrl.php", "footer.php", "geo.php", ".zip", 
".db"));

//ссылка Вашего сайта:
$sitemap->get_links($ssylka_na_codbox."stats_curl.php");

//если нужно вернуть просто массив с данными:
//$arr = $sitemap->get_array();
//echo "<pre>";
//print_r($arr);
//echo "</pre>";

header ("content-type: text/xml");
$map = $sitemap->generate_sitemap();
echo $map;
?>