<?php

function get_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $yip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $yip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $yip = $_SERVER['REMOTE_ADDR'];
}
 
error_reporting(E_ALL);
///ini_set("display_errors",0);
///error_reporting(0);
session_start(); 
$guidy = 0;
$status1days = 0;



function hx($sc)
 {
  $sc = str_replace(array(
    "vip_bonus.php"
  ), '', $sc);
  return $sc . "";
 }
$x_ff  = 0;
$cpath = hx(__FILE__);

$key = '';
$startx = microtime(true);
$today = date("Y-m-d");
if (empty($_SESSION['username'])) 
	$_SESSION['username']=0;

if (!empty($_SESSION['username'])){
	$_GET['pass'] = $_SESSION['username'];
	 $passsword = $_SESSION['username'];	
}
 
 
if(!empty($_COOKIE['user_online_x']))
	$key = $_COOKIE['user_online_x'];
 
if ((!empty($_GET['pass'])) && (!empty($_SESSION))) {
   $_POST['pass'] = $passsword;   
}
$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");
//include_once("functions/chatdb_archive.php"); 
include_once("functions/functions.inc.php"); include_once("langctrl.php");  
include_once("functions/ranks.php");  
include_once("functions/geo.php");  
//var_dump($geo_array);
  
  
  
$rtyh = $cpath.'databases/bonus.rcm';
if (!file_exists($rtyh)){

try
{
	$db = new PDO('sqlite:' .$rtyh);
	$db->exec('CREATE TABLE IF NOT EXISTS playbonus (
			id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
			name VARCHAR(90)  NOT NULL,
			guid int(32)  NOT NULL,
			ban int(2)  NOT NULL,
			ip VARCHAR(22)  NOT NULL,
			counts int(8)  NOT NULL,
			date datetime  NOT NULL
	)');
 
	$st = $db->query('SELECT name FROM playbonus');
	$result = $st->fetchAll();
	if (sizeof($result) == 0)
	{echo 'Table created successfully' . "\n";}}
    catch(PDOException $e){die($e->getMessage());}}  
	

if (empty($Msql_support))
$Msql_support = 0;
if (empty($host_adress))
    $host_adress = '0';
if (empty($db_name))
    $db_name   = '0';
if (empty($db_user))
    $db_user = '0';
if (empty($db_pass))
    $db_pass = '0';
if (empty($charset_db))
    $charset_db = '0';

if (!empty($passsword)){		
foreach ($steam_users_id as $passw => $xy){
  if(md5($passsword) == md5($passw))
  {
	  $key=1;
	  $xz = $xy;
  }
  
  }} else $key = '';	
  

if (is_numeric($key))
	$key = $key.'.1';
 
if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_x'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	
if(empty($Msql_support))
	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)(filesize($stats_db_path) / 1000000).' Мб';
else
{
	
try
{	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
    $sth = $bdd->query('SHOW TABLE STATUS');
    $sizeoff = $sth->fetch(PDO::FETCH_ASSOC)["Data_length"];

  
	
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}	

	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)($sizeoff / 1000000).' Мб';

}	
	}else $adminiinfo = '';	

if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_x'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php?adminpanel='.$xz.'" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">АдминПанель</a>
	<a href="'.$ssylka_na_codbox.'?logout=logout&lg#Logout!" onclick="location.reload()" style="color:#000;text-shadow:0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #ffa500, 0 0 7px #ffa500, 0 0 16px #ffa500, 0 0 40px #ffa500, 0 0 65px #ffa500;" >Logout!</a>';
}else 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">Логин</a>';


if (((!empty($_GET['logout'])) && (!empty($_SESSION['username']))) || ((!empty($_GET['logout'])) && (!empty($_COOKIE['user_online_x']))))
{	
echo 'Админ - '.$key.' вышел :)';
setcookie ( 'user_online_x', '', time()-2 );
session_destroy();
echo "<meta http-equiv='refresh' content='0'>";
}

$cache_time = 20;
$cc = $cache_time;
$xcache_time = $cc;
	

$player = '';
 if(empty($guidy)){     
if (empty($search))
{
	

 
try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	$dbw3 = new PDO('sqlite:' . $stats_db_path_week);
    $dbm3day = new PDO('sqlite:' . $stats_db_path_month);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		
		//PDO::ATTR_EMULATE_PREPARES => true,
		
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);	
	$dbw3 = $bdd;
    $dbm3day = $bdd;
	  }
//$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //отрубает базу при ошибке + в лог
//$bdd->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );   //продолжает работу, идет откладка в лог
	 
$xl = $bdd->query('SELECT t0.*, t2.* 
   from db_stats_0 t0 
   join 
 (select * from db_stats_2) 
 t2 ON 
 t0.s_pg = t2.s_pg 
   where t2.w_ip = "'.$yip.'" LIMIT 1');    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['s_guid'];
  $player  = $jk['s_player']; 
}

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}
				
} 
 } 

 
if(empty($key))
{
  $file = "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
  $filemd5 = md5($file.$guidy); 
  $cache_file = $cache_folder."/$filemd5.html";
  if (file_exists($cache_file)) {
   if ((time() - $cc) < filemtime($cache_file)) {
      echo file_get_contents($cache_file); 
	  echo "<!-- --------- Cached with $xcache_time seconds --------- -->";
      exit; 
    }
	}
  ob_start();
  }
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title><?php echo 'BONUS COD4'; ?></title>
		 <link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/recod-r.css"/>
  
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
 
 		
<?php 

if (!empty($_GET['theme']))
$_SESSION['theme'] = $_GET['theme'];


if (!empty($_SESSION['theme'])){
	$_GET['theme'] = $_SESSION['theme'];
}
else
	$_GET['theme'] = 'dark';



if (($_GET['theme']) == 'dark') {?>
<style>
body{

  background-color:#141e21; /* #002600 */
  color:#2eb4e9;

}
 

table{
 position:relative;	
 min-width: 1100px; 
}


.topbuttondark {
width:50px;
border:2px solid #ccc;
background:#f7f7f7;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#333;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }
else if (($_GET['theme'] == 'light')) {
?>
<style>
body{
 
  background-color:#ddd; /* #002600 */
  color:#000;
 
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}


table{
 position:relative;	
 min-width: 1100px;  
}

.topbutton {
width:50px;
border:2px solid #ccc;
background:#333;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#fff;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }?>

	

 
  
<script>
var newTxt="<?php echo $title_migalka_stats ?>";
var oldTxt=document.title;
 
function migalka(){
    if(document.title==oldTxt){
        document.title=newTxt;
    }else{
        document.title=oldTxt;
    }
}
 
var timer = setInterval(migalka,1000);
</script>


 <script>
 $(document).ready(function(){

        var $menu = $("#menu");

        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("default")
                           .addClass("fixed transbg")
                           .fadeIn('fast');
                });
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("fixed transbg")
                           .addClass("default")
                           .fadeIn('fast');
                });
            }
        });//scroll

        $menu.hover(
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).removeClass('transbg');
                }
            },
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).addClass('transbg');
                }
            });//hover
    });//jQuery
 </script>
 
 
  <script> 
            function mouseover() { 
                document.getElementById("gfg").style.color = "red"; 
            } 
              
            function mouseout() { 
                document.getElementById("gfg").style.color = "green"; 
            } 
        </script> 
  <style>
@import url('https://fonts.googleapis.com/css?family=Roboto');
@import url('https://fonts.googleapis.com/css?family=Roboto+Mono');
a{
	color: #283593;
	text-decoration: none;
}
h3{
	margin-top: 12px;
}
*{
	margin:0px;
}
 
main{
	border-radius: 5px;
	background-color: #EF5350;
	margin-top: 30px;
	padding-top: 20px;
	padding-bottom: 20px;
	padding-left: 15px;
	padding-right: 15px;
	margin-left: calc((100% - 580px) / 2);
	width: 550px;
}
section#status{
	margin-bottom: 25px;
	padding-top: 25px;
	padding-bottom: 25px;
	border-radius: 5px;
	text-align: center;
	background-color: #37474F;
	color: #FFFFFF;
	font-size: 25px;
	font-family: 'Roboto Mono', monospace;
}
section#Slots{
	border-radius: 15px;
	background-color: #FAFAFA;
}
section#Gira{
	margin-top: 25px;
	padding-top: 25px;
	padding-bottom: 25px;
	border-radius: 5px;
	text-align: center;
	background-color: #AB47BC;
	color: #FFFFFF;
	font-size: 25px;
}
section#Gira:hover{
	background-color: #BA68C8;
}
section#options{
	margin-top: 20px;
	padding-top: 5px;
	border-radius: 5px;
	background-color: #C62828;
	color: #FFFFFF;
}
.option{
	padding-left: 5px;
}
section#info{
	background-color: #616161;
	padding-left: 12px;
	padding-bottom: 12px;
	border-radius: 5px;
	overflow: hidden;
	animation-duration: 1s;
	color: #BDBDBD;
	margin-top: 50px;
	margin-left: 30%;
	margin-right: 30%;
	display: none;
}
#slot1, #slot2, #slot3{
	display: inline-block;
	margin-top: 5px;
	margin-left: 15px;
	margin-right: 15px;
	background-size: 150px;
	width: 150px;
	height: 150px;
}
.a1{
	background-image: url("res/tiles/seven.png");
}
.a2{
	background-image: url("res/tiles/cherries.png");
}
.a3{
	background-image: url("res/tiles/club.png");
}
.a4{
	background-image: url("res/tiles/diamond.png");
}
.a5{
	background-image: url("res/tiles/heart.png");
}
.a6{
	background-image: url("res/tiles/spade.png");
}
.a7{
	background-image: url("res/tiles/joker.png");
}
</style>

 		

</head>
<html>
<body onload="toggleAudio()">

<script> 
addEventListener('click', function (event) {
    if (event.target.id == 'found') {
        
    }
}, true);
</script>
<div class="menuooo-center2">
 <div class="menuooo2">
<div id="menu">
        <ul>		
<?php		
		echo '<li>'.$adminpl.'</li>';
foreach ($ssylki_array as $arxx => $namessylka) {	
   echo '<li>| <a href="'.$arxx.'" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #FFF, 0 0 7px #990694, 0 0 18px #990694, 0 0 40px #990694, 0 0 65px #990694;" target="_blank">'.$namessylka.'</a></li>';   
} 		


?>
      
	  </ul>

    </div>
</div></div>


 
<?php
$zzzzz = 0;
$date = date('Y-m-d H:i:s');
if(!empty($_GET['days'])){
if(!empty($guidy)){ 

if(!empty($_GET['days'])) 
$limitsw = $_GET['days'];
else
	$limitsw = 0;	
	
try
{	

$db = new PDO('sqlite:' .$rtyh);

 
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


$rep  = $db->query("SELECT * FROM playbonus where guid=".$guidy." limit 1");
   while ($row = $rep->fetch())	
{	
 $ip_playbonus = $row['guid'];
 $date_playbonus = $row['date'];
 
 			 
			 
if(((strtotime($date_playbonus)) - (strtotime($date))) < 0)
 $db->query("UPDATE playbonus SET date='{$dateend}' WHERE guid=".$guidy."");
else
  $zzzzz = 1;	
			
			
		   }
		   
}
    catch(PDOException $e){die($e->getMessage());}		
	
	
	
if(empty($ip_playbonus)){
if($db->exec("INSERT INTO playbonus ('name', 'guid', 'ban', 'ip', 'counts', 'date') VALUES ('".$player."', '".$guidy."', '0', '".$yip."', '1', '".$dateend."')")>0)	
echo 'in';	
}	
	
if(!empty($zzzzz))
die ('</br></br><center> <h1>24h '.$ip_playbonus.' LIMIT!</h1></center></br>');	


$file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen);


echo '</br></br><center> <h1>'.$bonus_slot_vip.'  '.$limitsw.'  '.$bonus_slot_days.'</h1></center></br>';
 	
$statusw ='VIP'; 

try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	$dbw3 = new PDO('sqlite:' . $stats_db_path_week);
    $dbm3day = new PDO('sqlite:' . $stats_db_path_month);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		
		//PDO::ATTR_EMULATE_PREPARES => true,
		
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);	
	$dbw3 = $bdd;
    $dbm3day = $bdd;
	  }
	 
	 
$xl = $bdd->query("SELECT id FROM player_status where guid = $guidy LIMIT 1");    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['s_guid'];
  $player  = $jk['s_player'];
  $status1days = $jk['status1days'];
}


  
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	

if(($status1days < 5)&&($limitsw < 7))
 $bdd->query("UPDATE player_status SET time='{$dateend}', status1='{$statusw}', status1days='{$limitsw}' WHERE guid = $guidy");	

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}

if(($status1days < 5)&&($limitsw < 7))
exit;

}}	 
?>		
		
 
 <div id="blockx">	
<div class="absolute-style"> 
<?php
echo '<a href="'.$ssylka_na_codbox.'vip_bonus.php" style="padding-top: 40px;"> '. $main_servername . '</a>';

?>

    </div>
</div></div>

</br></br></br></br></br></br>
<center><h1><?php echo $bonus_slot_vb; ?></h1></center>
</br>
<center><h2><?php  if(empty($guidy)) echo $bonus_slot_vbtxt;  ?></h2></center>


 


<?php  if(!empty($guidy)){  ?>

<center>
<table width="70%" align="center">
<tr>
<td style="background:#000;opacity: 0.9;">

<?php  echo $vip_bonus_reklama_1;  ?>

</td>

<div id="shownOnlyOnceADay">
<td style="background:#000;opacity: 0.9;">
<main>
	<section id="status"><?php echo $bonus_slot_welcome." ".$player." !"; ?></section>
	<section id="Slots">
		<div id="slot1" class="a1"></div>
		<div id="slot2" class="a1"></div>
		<div id="slot3" class="a1"></div>
	</section>
	<section onclick="doSlot()" id="Gira"><?php echo $bonus_slot_spin; ?></section>
	<section id="options">
		<img src="res/icons/audioOn.png" id="audio" class="option" onclick="toggleAudio()" />
	</section>
</main>
</br>
</td>
</div>

<td style="background:#000;opacity: 0.9;">

<?php  echo $vip_bonus_reklama_2;  ?>

</td>
</tr>
</table>
</center>

<script>
 
var doing = false;
var spin = [new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3")];
var coin = [new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3")]
var win = new Audio("res/sounds/win.mp3");
var lose = new Audio("res/sounds/lose.mp3");
var audio = false;
let status = document.getElementById("status")
var info = true;

function doSlot(){
	if (doing){return null;}
	doing = true;
	var numChanges = randomInt(1,4)*7
	var numeberSlot1 = numChanges+randomInt(1,7)
	var numeberSlot2 = numChanges+2*7+randomInt(1,7)
	var numeberSlot3 = numChanges+4*7+randomInt(1,7)

	var i1 = 0;
	var i2 = 0;
	var i3 = 0;
	var sound = 0
	status.innerHTML = "<?php echo $bonus_slot_spinning; ?>"
	slot1 = setInterval(spin1, 50);
	slot2 = setInterval(spin2, 50);
	slot3 = setInterval(spin3, 50);
	function spin1(){
		i1++;
		if (i1>=numeberSlot1){
			coin[0].play()
			clearInterval(slot1);
			return null;
		}
		slotTile = document.getElementById("slot1");
		if (slotTile.className=="a7"){
			slotTile.className = "a0";
		}
		slotTile.className = "a"+(parseInt(slotTile.className.substring(1))+1)
	}
	function spin2(){
		i2++;
		if (i2>=numeberSlot2){
			coin[1].play()
			clearInterval(slot2);
			return null;
		}
		slotTile = document.getElementById("slot2");
		if (slotTile.className=="a7"){
			slotTile.className = "a0";
		}
		slotTile.className = "a"+(parseInt(slotTile.className.substring(1))+1)
	}
	function spin3(){
		i3++;
		if (i3>=numeberSlot3){
			coin[2].play()
			clearInterval(slot3);
			testWin();
			return null;
		}
		slotTile = document.getElementById("slot3");
		if (slotTile.className=="a7"){
			slotTile.className = "a0";
		}
		sound++;
		if (sound==spin.length){
			sound=0;
		}
		spin[sound].play();
		slotTile.className = "a"+(parseInt(slotTile.className.substring(1))+1)
	}
}

function testWin(){
	var slot1 = document.getElementById("slot1").className
	var slot2 = document.getElementById("slot2").className
	var slot3 = document.getElementById("slot3").className

	if ((slot1 == slot2 && slot2 == slot3) ||
		(slot1 == slot2 && slot3 == "a7") ||
		(slot1 == slot3 && slot2 == "a7") ||
		(slot2 == slot3 && slot1 == "a7") ||
		(slot1 == slot2 && slot1 == "a7") ||
		(slot1 == slot3 && slot1 == "a7") ||
		(slot2 == slot3 && slot2 == "a7") ||
		(slot1 == slot2 && slot2 == slot3 && slot1=="a7")){
		
		
	if ((slot1 == slot2 && slot2 == slot3 && slot1=="a7")){		
		
 
		status.innerHTML = "<?php echo $bonus_slot_3d; ?>";
        window.open('<?php echo $ssylka_na_codbox;?>vip_bonus.php?days='+dayz+'', '_blank'); 
		win.play();
	  }	
		
	else if ((slot1 == slot2 && slot2 == slot3) ||
		(slot1 == slot2 && slot3 == "a7") ||
		(slot1 == slot3 && slot2 == "a7") ||
		(slot2 == slot3 && slot1 == "a7") ||
		(slot1 == slot2 && slot1 == "a7") ||
		(slot1 == slot3 && slot1 == "a7") ||
		(slot2 == slot3 && slot2 == "a7")){	

	    dayz = Math.floor(Math.random()*6 + 1);	
 
		 
		status.innerHTML = "<?php echo $bonus_slot_vip; ?> "+dayz+" <?php echo $bonus_slot_days; ?>";
        window.open('<?php echo $ssylka_na_codbox;?>vip_bonus.php?days='+dayz+'', '_blank');				
		win.play();
	  }			

		 
	}else{
		status.innerHTML = "<?php echo $bonus_slot_lose; ?>"
		lose.play();
	}
	doing = false;
}

function toggleAudio(){
	if (!audio){
		audio = !audio;
		for (var x of spin){
			x.volume = 0.5;
		}
		for (var x of coin){
			x.volume = 0.5;
		}
		win.volume = 1.0;
		lose.volume = 1.0;
	}else{
		audio = !audio;
		for (var x of spin){
			x.volume = 0;
		}
		for (var x of coin){
			x.volume = 0;
		}
		win.volume = 0;
		lose.volume = 0;
	}
	document.getElementById("audio").src = "res/icons/audio"+(audio?"On":"Off")+".png";
}

function randomInt(min, max){
	return Math.floor((Math.random() * (max-min+1)) + min);
}
</script>
 
<?php 











} 
$i = 0;
echo "</br><center><h2>LAST BONUS!</h2>";
$file = $cpath.'databases/bonus.log';
//how many lines?
$linecount=100;

//what a typical line length?
$length=40;


//we double the offset factor on each iteration
//if our first guess at the file offset doesn't
//yield $linecount lines
$offset_factor=1;


$bytes=filesize($file);

$fp = fopen($file, "r") or die("Can't open $file");


$complete=false;
while (!$complete)
{
    //seek to a position close to end of file
    $offset = $linecount * $length * $offset_factor;
    fseek($fp, -$offset, SEEK_END);


    //we might seek mid-line, so read partial line
    //if our offset means we're reading the whole file, 
    //we don't skip...
    if ($offset<$bytes)
        fgets($fp);

    //read all following lines, store last x
    $lines=array();
    while(!feof($fp))
    {
        $line = fgets($fp);
        array_push($lines, $line);
        if (count($lines)>$linecount)
        {
            array_shift($lines);
            $complete=true;
        }
    }

    //if we read the whole file, we're done, even if we
    //don't have enough lines
    if ($offset>=$bytes)
        $complete=true;
    else
        $offset_factor*=2; //otherwise let seek even further back

}
fclose($fp);

//var_dump($lines);
$cntz = 0;
foreach($lines as $line){
	++$cntz;
	if(!empty($line))
echo "</br>".$cntz.") ".$line;	
}


echo "</center></br></br>";




include_once("footer.php"); 

 $handle = fopen($cache_file, 'w'); // Открываем файл для записи и стираем его содержимое
  fwrite($handle, ob_get_contents()); // Сохраняем всё содержимое буфера в файл
  fclose($handle); // Закрываем файл
  ob_end_flush(); // Выводим страницу в браузере 

 ?>
 

</body>
</html>