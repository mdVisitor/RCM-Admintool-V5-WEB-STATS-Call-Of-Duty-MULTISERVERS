<?php

function get_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
        $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $yip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $yip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $yip = $_SERVER['REMOTE_ADDR'];
}
 
error_reporting(E_ALL);
///ini_set("display_errors",0);
///error_reporting(0);
session_start(); 
$guidy = 0;
$status1days = 0;





$yip = '87.110.94.40';

































function hx($sc)
 {
  $sc = str_replace(array(
    "vip_bonus.php"
  ), '', $sc);
  return $sc . "";
 }
$x_ff  = 0;
$cpath = hx(__FILE__);

$key = '';
$startx = microtime(true);
$today = date("Y-m-d");
include("login.php");
$access = '2asdasdwq3dxaezw234cz234xczwrvzsr3cvzs3r5czsr';
include("index_chat_cfg.php");
//include_once("functions/chatdb_archive.php"); 
include_once("functions/functions.inc.php"); include_once("langctrl.php");  
include_once("functions/ranks.php");  
include_once("functions/geo.php");  
//var_dump($geo_array);
  
  
  
$rtyh = $cpath.'databases/bonus.rcm';
if (!file_exists($rtyh)){

try
{
	$db = new PDO('sqlite:' .$rtyh);
	$db->exec('CREATE TABLE IF NOT EXISTS playbonus (
			id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,
			name VARCHAR(90)  NOT NULL,
			guid int(32)  NOT NULL,
			ban int(2)  NOT NULL,
			ip VARCHAR(22)  NOT NULL,
			counts int(8)  NOT NULL,
			date datetime  NOT NULL
	)');
 
	$st = $db->query('SELECT name FROM playbonus');
	$result = $st->fetchAll();
	if (sizeof($result) == 0)
	{echo 'Table created successfully' . "\n";}}
    catch(PDOException $e){die($e->getMessage());}}  
	

if (empty($Msql_support))
$Msql_support = 0;
if (empty($host_adress))
    $host_adress = '0';
if (empty($db_name))
    $db_name   = '0';
if (empty($db_user))
    $db_user = '0';
if (empty($db_pass))
    $db_pass = '0';
if (empty($charset_db))
    $charset_db = '0';

if (!empty($_COOKIE['user_online_login'])){		
foreach ($steam_users_id as $passw => $xy){
	$md5session = md5($_COOKIE['user_online_login']);
  if($md5session == md5($passw))
  {
	  $key=1;
	  $xz = $xy;
  }
  
  }} else $key = '';
  

if (is_numeric($key))
	$key = $key.'.1';
 
if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_login'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	
if(empty($Msql_support))
	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)(filesize($stats_db_path) / 1000000).' Мб';
else
{
	
try
{	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);			  	  
    $sth = $bdd->query('SHOW TABLE STATUS');
    $sizeoff = $sth->fetch(PDO::FETCH_ASSOC)["Data_length"];

  
	
}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}	

	$adminiinfo = ''.$xz.' | БД: '.$sizzedb = (int)($sizeoff / 1000000).' Мб';

}	
	}else $adminiinfo = '';	

if(((!empty($key)) && (empty($_GET['logout']))) || ((!empty($_COOKIE['user_online_login'])) && (empty($_GET['logout'])))){ //| права на базу данных => '.substr(sprintf('%o', fileperms($stats_db_path)), -4).' 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php?adminpanel='.$xz.'" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">АдминПанель</a>
	<a href="'.$ssylka_na_codbox.'?logout=logout&lg#Logout!" onclick="location.reload()" style="color:#000;text-shadow:0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #ffa500, 0 0 7px #ffa500, 0 0 16px #ffa500, 0 0 40px #ffa500, 0 0 65px #ffa500;" >Logout!</a>';
}else 
	$adminpl = '|<a href="'.$ssylka_na_codbox.'adminpanel.php" target="_blank" onclick="location.reload()" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #00cc00, 0 0 7px #00cc00, 0 0 16px #00cc00, 0 0 40px #00cc00, 0 0 65px #00cc00;">Логин</a>';


if (((!empty($_GET['logout'])) && (!empty($_SESSION['username']))) || ((!empty($_GET['logout'])) && (!empty($_COOKIE['user_online_login']))))
{	
echo 'Админ - '.$key.' вышел :)';
setcookie ( 'user_online_login', '', time()-2 );
session_destroy();
echo "<meta http-equiv='refresh' content='0'>";
}

$cache_time = 20;
$cc = $cache_time;
$xcache_time = $cc;
	

$player = "";
 if(empty($guidy)){     
if (empty($search))
{
	

 
try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	$dbw3 = new PDO('sqlite:' . $stats_db_path_week);
    $dbm3day = new PDO('sqlite:' . $stats_db_path_month);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		
		//PDO::ATTR_EMULATE_PREPARES => true,
		
		PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8",
		PDO::NULL_TO_STRING => NULL,
    ];
    $bdd = new PDO($dsn, $db_user, $db_pass, $opt);	
	$dbw3 = $bdd;
    $dbm3day = $bdd;
	  }
//$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //отрубает базу при ошибке + в лог
//$bdd->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );   //продолжает работу, идет откладка в лог
	 
$xl = $bdd->query('SELECT t0.*, t1.* 
   from db_stats_0 t0 
   join 
 (select * from x_up_players) 
 t1 ON 
 t0.s_guid = t1.guid 
   where t1.ip = "'.$yip.'" LIMIT 1');    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['s_guid'];
  $player  = $jk['s_player']; 
}

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}
				
} 
 } 

 
$faces = array ('🌟', '💗', '🍒', '🍓', '🍬', '🎂');

$cards = array ('🌟', '💗', '🍒', '🍓', '🍬', '🎂');

$names = array ('🌟', '💗', '🍒', '🍓', '🍬', '🎂');


$deck = array();
foreach ($faces as $face) {
foreach ($cards as $card) {
foreach ($names as $name) {
$deck[] = array ("face"=>$face, "card"=>$card,"name"=>$name);}}}

shuffle($deck);
$card = array_shift($deck);

//echo $card['face'] . $card['card'] . $card['name'];

if(($card['face'] == $card['card']) && ($card['card'] == $card['name']))
{ 
$nzslot1 = 7;
  $nzslot2 = 7;
	$nzslot3 = 7;
	   $randd = 5;
}
else if($card['face'] == $card['card'])
{ 
$nzslot1 = 7;
  $nzslot2 = 7;
	$nzslot3 = rand(1, 6);
       $randd = 3;
}
else if($card['card'] == $card['name'])
{ 
$nzslot1 = rand(1, 6);
  $nzslot2 = 7;
	$nzslot3 = 7;
      	$randd = 2;
}
else
{ 
$nzslot1 = 2;
  $nzslot2 = 3;
	$nzslot3 = 5;
      	$randd = 0;
}
$date = date('Y-m-d H:i:s');
 
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta name="robots" content="noindex,nofollow" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<title><?php echo 'BONUS COD4'; ?></title>
		 <link rel="stylesheet" type="text/css" href="<?php echo $ssylka_na_codbox;?>css/recod-r.css"/>
  
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
 
 		
<?php 

if (!empty($_GET['theme']))
$_SESSION['theme'] = $_GET['theme'];


if (!empty($_SESSION['theme'])){
	$_GET['theme'] = $_SESSION['theme'];
}
else
	$_GET['theme'] = 'dark';



if (($_GET['theme']) == 'dark') {?>
<style>
body{

  background-color:#141e21; /* #002600 */
  color:#2eb4e9;

}
 

table{
 position:relative;	
 min-width: 1100px; 
}


.topbuttondark {
width:50px;
border:2px solid #ccc;
background:#f7f7f7;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#333;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }
else if (($_GET['theme'] == 'light')) {
?>
<style>
body{
 
  background-color:#ddd; /* #002600 */
  color:#000;
 
}

canvas {
  display: block;
  cursor: crosshair;
  position:static;
}


table{
 position:relative;	
 min-width: 1100px;  
}

.topbutton {
width:50px;
border:2px solid #ccc;
background:#333;
text-align:center;
padding:10px;
position:fixed;
bottom:50px;
right:50px;
cursor:pointer;
color:#fff;
font-family:verdana;
font-size:12px;
border-radius: 50px;
-moz-border-radius: 50px;
-webkit-border-radius: 50px;
-khtml-border-radius: 50px;
}
</style>
<?php }?>

	
<script>  
    function showContent(link) {  
  
        var cont = document.getElementById('contentBody');  
        var loading = document.getElementById('loading');  
  
        cont.innerHTML = loading.innerHTML;  
  
        var http = createRequestObject();  
        if( http )   
        {  
            http.open('get', link);  
            http.onreadystatechange = function ()   
            {  
                if(http.readyState == 4)   
                {  
                    cont.innerHTML = http.responseText;  
                }  
            }  
            http.send(null);      
        }  
        else   
        {  
            document.location = link;  
        }  
    }  
  
    // создание ajax объекта  
    function createRequestObject()   
    {  
        try { return new XMLHttpRequest() }  
        catch(e)   
        {  
            try { return new ActiveXObject('Msxml2.XMLHTTP') }  
            catch(e)   
            {  
                try { return new ActiveXObject('Microsoft.XMLHTTP') }  
                catch(e) { return null; }  
            }  
        }  
    }  
</script> 
 
  
<script>
var newTxt="<?php echo $title_migalka_stats ?>";
var oldTxt=document.title;
 
function migalka(){
    if(document.title==oldTxt){
        document.title=newTxt;
    }else{
        document.title=oldTxt;
    }
}
 
var timer = setInterval(migalka,1000);
</script>


 <script>
 $(document).ready(function(){

        var $menu = $("#menu");

        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("default")
                           .addClass("fixed transbg")
                           .fadeIn('fast');
                });
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("fixed transbg")
                           .addClass("default")
                           .fadeIn('fast');
                });
            }
        });//scroll

        $menu.hover(
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).removeClass('transbg');
                }
            },
            function(){
                if( $(this).hasClass('fixed') ){
                    $(this).addClass('transbg');
                }
            });//hover
    });//jQuery
 </script>
 
 
  <script> 
            function mouseover() { 
                document.getElementById("gfg").style.color = "red"; 
            } 
              
            function mouseout() { 
                document.getElementById("gfg").style.color = "green"; 
            } 
        </script> 
  <style>
a{
	color: #283593;
	text-decoration: none;
}
h3{
	margin-top: 12px;
}
*{
	margin:0px;
}
 
main{
	border-radius: 5px;
	background-color: #555b55;
	margin-top: 30px;
	padding-top: 20px;
	padding-bottom: 20px;
	padding-left: 15px;
	padding-right: 15px;
	margin-left: calc((100% - 580px) / 2);
	width: 550px;
}
section#status{
	margin-bottom: 25px;
	padding-top: 25px;
	padding-bottom: 25px;
	border-radius: 5px;
	text-align: center;
	background-color: #37474F;
	color: #FFFFFF;
	font-size: 25px;
	font-family: 'Roboto Mono', monospace;
}
section#Slots{
	border-radius: 15px;
	background-color: #FAFAFA;
}
section#Girx{
	margin-top: 25px;
	padding-top: 25px;
	padding-bottom: 25px;
	border-radius: 5px;
	text-align: center;
	background-color: #a00646;
	color: #FFFFFF;
	font-size: 25px;
}
section#Girx:hover{
	background-color: #7a0335;
}
section#options{
	margin-top: 20px;
	padding-top: 5px;
	border-radius: 5px;
	background-color: #44434c;
	color: #FFFFFF;
}
.option{
	padding-left: 5px;
}

#slot1, #slot2, #slot3{
	display: inline-block;
	margin-top: 5px;
	margin-left: 15px;
	margin-right: 15px;
	background-size: 150px;
	width: 150px;
	height: 150px;
}
.a1{
	background-image: url("res/tiles/seven.png");
}
.a2{
	background-image: url("res/tiles/cherries.png");
}
.a3{
	background-image: url("res/tiles/club.png");
}
.a4{
	background-image: url("res/tiles/diamond.png");
}
.a5{
	background-image: url("res/tiles/heart.png");
}
.a6{
	background-image: url("res/tiles/spade.png");
}
.a7{
	background-image: url("res/tiles/joker.png");
}
</style>

 		

</head>
<html>
<body onload="toggleAudio()">
 

<script> 
addEventListener('click', function (event) {
    if (event.target.id == 'found') {
        
    }
}, true);
</script>
<div class="menuooo-center2">
 <div class="menuooo2">
<div id="menu">
        <ul>		
<?php		
		echo '<li>'.$adminpl.'</li>';
foreach ($ssylki_array as $arxx => $namessylka) {	
   echo '<li>| <a href="'.$arxx.'" style="color:#000;text-shadow: 0 0 1px #fff, 0 0 2px #fff, 0 0 30px #fff, 0 0 4px #FFF, 0 0 7px #990694, 0 0 18px #990694, 0 0 40px #990694, 0 0 65px #990694;" target="_blank">'.$namessylka.'</a></li>';   
} 		


?>
      
	  </ul>

    </div>
</div></div>


 
 
		
 
 <div id="blockx">	
<div class="absolute-style"> 
<?php
echo '<a href="'.$ssylka_na_codbox.'vip_bonus.php" style="padding-top: 40px;"> '. $main_servername . '</a>';

?>

    </div>
</div></div>
 
<center><h1><?php if(empty($_GET['days'])) echo '</br></br></br>'.$bonus_slot_vb; ?></h1></center>
</br>
<center><h2><?php  if(empty($guidy)) echo '</br>'.$bonus_slot_vbtxt;  ?></h2></center>


<?php
 
 
 
 
 
 
 
 
 
 
 
 try
{	

$db = new PDO('sqlite:' .$rtyh);


$rep  = $db->query("SELECT * FROM playbonus where guid=".$guidy." limit 1");
   while ($row = $rep->fetch())	
{	
 $ip_playbonus = $row['guid'];
 $date_playbonus = $row['date'];
 
 			 
/*	*/		 
if(((strtotime($date_playbonus)) - (strtotime($date))) > 0)
{

die ('</br></br></br><center> <h1>24h '.$ip_playbonus.' LIMIT!</h1></center></br>');
	
}			
	
		
		   }
		   
}
    catch(PDOException $e){die($e->getMessage());} 
 
 
 
/////////////////////////////////////////////////////////////////// 
 
 
$zzzzz = 0;
if(!empty($randd)){
	
	
$_GET['days'] = $randd;	
	
	
if(!empty($guidy)){ 

if(!empty($_GET['days'])) 
$limitsw = $_GET['days'];
else
	$limitsw = 0;	
	
try
{	

$db = new PDO('sqlite:' .$rtyh);

 
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


$rep  = $db->query("SELECT * FROM playbonus where guid=".$guidy." limit 1");
   while ($row = $rep->fetch())	
{	
 $ip_playbonus = $row['guid'];
 $date_playbonus = $row['date'];
 
 			 
			 
if(((strtotime($date_playbonus)) - (strtotime($date))) < 0)
 $db->query("UPDATE playbonus SET date='".$dateend."' WHERE guid=".$guidy."");
else
  $zzzzz = 1;	
			
			
		   }
		   
}
    catch(PDOException $e){die($e->getMessage());}		
	
	
	
if(empty($ip_playbonus)){
if($db->exec("INSERT INTO playbonus ('name', 'guid', 'ban', 'ip', 'counts', 'date') VALUES ('0', '".$guidy."', '0', '".$yip."', '1', '".$dateend."')")>0)	
{

echo '-';	
}
}	
	
	

if($limitsw > 8)
$limitsw = 0;


 	
$statusw ='VIP'; 

try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $bdd = new PDO($dsn, $db_user, $db_pass);	
	  }
	 
	 
$xl = $bdd->query("SELECT guid,status1,status1days,time FROM player_status where guid = ".$guidy." LIMIT 3");    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['guid'];
  $status1days = $jk['status1days'];
  $statusone = $jk['status1'];
  $statusonetime = $jk['time'];
  
if(!empty($statusone)){	
$dateend = date('Y-m-d', strtotime($statusonetime. ' + '.$limitsw.' days'));	
	if($limitsw < 7)
{
$bdd->query("UPDATE player_status SET time='".$dateend."', status1days=status1days+'".$limitsw."' WHERE guid = ".$guidy."");  

$file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen);	
}



} 
  
}


  
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


if(!empty($statusone)){
	
$dateend = date('Y-m-d', strtotime($statusonetime. ' + '.$limitsw.' days'));
 	
}else{
if($limitsw < 7){
	
$bdd->exec("INSERT INTO player_status (guid,time,timeh,text,status1,status1days,status2,status2days)
 VALUES ('".$guidy."','".$dateend."',CURRENT_TIME(),'0','".$statusw."','".$limitsw."','0','0')");	
 $file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen);	
 }
}

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}

 

}}	  
 

 
 
 
 
 
 
 
 
 

$zzzzz = 0;
$date = date('Y-m-d H:i:s');
if(!empty($_GET['days'])){
if(!empty($guidy)){ 
 
if(!empty($_GET['days'])) 
$limitsw = $_GET['days'];
else
	$limitsw = 0;	
	
try
{	

$db = new PDO('sqlite:' .$rtyh);

 
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


$rep  = $db->query("SELECT * FROM playbonus where guid=".$guidy." limit 1");
   while ($row = $rep->fetch())	
{	
 $ip_playbonus = $row['guid'];
 $date_playbonus = $row['date'];
 
 			 
			 
if(((strtotime($date_playbonus)) - (strtotime($date))) > 0)
  $zzzzz = 1;	
			
			
		   }
		   
}
    catch(PDOException $e){die($e->getMessage());}		
	
	
if(empty($ip_playbonus)){
if($db->exec("INSERT INTO playbonus ('name', 'guid', 'ban', 'ip', 'counts', 'date') VALUES ('0', '".$guidy."', '0', '".$yip."', '1', '".$dateend."')")>0)	
$file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen);
}	
 	
	
 if(!empty($zzzzz))
 die ('</br></br></br><center> <h1>24h '.$ip_playbonus.' LIMIT!</h1></center></br>');


if($limitsw > 8)
$limitsw = 0;




echo '</br></br><center> <h1>'.$bonus_slot_vip.'  '.$limitsw.'  '.$bonus_slot_days.'</h1></center></br>';
 	
$statusw ='VIP'; 

try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $bdd = new PDO($dsn, $db_user, $db_pass);	
	  }
	 
	 
$xl = $bdd->query("SELECT guid,status1,status1days,time FROM player_status where guid = ".$guidy." LIMIT 3");    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['guid'];
  $status1days = $jk['status1days'];
  $statusone = $jk['status1'];
  $statusonetime = $jk['time'];
  
  
  
}


  
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


 

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}

if($limitsw < 7)
exit;

}}	 
?>	 


<?php  if(!empty($guidy)){  ?>

<center>
<table width="70%" align="center">
<tr>
<td style="background:#000;opacity: 0.9;">

<?php  echo $vip_bonus_reklama_1;  ?>

</td>

<div id="shownOnlyOnceADay">
<td style="background:#000;opacity: 0.9;">
<main>
	<section id="status"><?php echo $bonus_slot_welcome." ".$player." !"; ?></section>
	<section id="Slots">
		<div id="slot1" class="a1"></div>
		<div id="slot2" class="a1"></div>
		<div id="slot3" class="a1"></div>
	</section>
	<section onclick="doSlot()" id="Girx"><?php echo $bonus_slot_spin; ?></section>
	<section id="options">
		<img src="res/icons/audioOn.png" id="audio" class="option" onclick="toggleAudio()" />
	</section>
</main>
</br>
</td>
</div>

<td style="background:#000;opacity: 0.9;">

<?php  echo $vip_bonus_reklama_2;  ?>

</td>
</tr>
</table>
</center>

<script>
 
var doing = false;
var spin = [new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3")];
var coin = [new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3")]
var win = new Audio("res/sounds/win.mp3");
var lose = new Audio("res/sounds/lose.mp3");
var audio = false;
let status = document.getElementById("status")
var info = true;
var dayz = 0;
var hotxxx = 0;
var windowName = 'userConsole'; 
 
function doSlot(){
	if (doing){return null;}
	doing = true;
 
	
	
/*	
	var nzCh = randomInt(1,4)*7
	var nzslot1 = nzCh+randomInt(1,7)
	var nzslot2 = nzCh+4*7+randomInt(5,6)
	var nzslot3 = nzCh+4*7+randomInt(1,7)
*/
    var nzCh = randomInt(1,4)*7
	var nzslot1 = <?php echo $nzslot1; ?>;
	var nzslot2 = <?php echo $nzslot2; ?>;
	var nzslot3 = <?php echo $nzslot3; ?>;	
	
	var i1 = 0;
	var i2 = 0;
	var i3 = 0;
	var sound = 0
	status.innerHTML = "<?php echo $bonus_slot_spinning; ?>"
	slot1 = setInterval(spin1, 80);
	slot2 = setInterval(spin2, 80);
	slot3 = setInterval(spin3, 80);
	function spin1(){
		i1++;
		if (i1>=nzslot1){
			coin[0].play()
			clearInterval(slot1);
			return null;
		}
		stT = document.getElementById("slot1");
		if (stT.className=="a7"){
			stT.className = "a0";
		}
		stT.className = "a"+(parseInt(stT.className.substring(1))+1)
	}
	function spin2(){
		i2++;
		if (i2>=nzslot2){
			coin[1].play()
			clearInterval(slot2);
			return null;
		}
		stT = document.getElementById("slot2");
		if (stT.className=="a7"){
			stT.className = "a0";
		}
		stT.className = "a"+(parseInt(stT.className.substring(1))+1)
	}
	function spin3(){
		i3++;
		if (i3>=nzslot3){
			coin[2].play()
			clearInterval(slot3);
			testWin();
			return null;
		}
		stT = document.getElementById("slot3");
		if (stT.className=="a7"){
			stT.className = "a0";
		}
		sound++;
		if (sound==spin.length){
			sound=0;
		}
		spin[sound].play();
		stT.className = "a"+(parseInt(stT.className.substring(1))+1)
	}
}

function testWin(){
	var slot1 = document.getElementById("slot1").className
	var slot2 = document.getElementById("slot2").className
	var slot3 = document.getElementById("slot3").className
		
	
    		hotxxx++;
	
	
	if ((slot1 == slot2 && slot2 == slot3) ||
		(slot1 == slot2 && slot3 == "a7") ||
		(slot2 == slot3 && slot2 == "a7") ||
		(slot1 == slot2 && slot2 == slot3 && slot1=="a7")){
		
		
	if ((slot1 == slot2 && slot2 == slot3 && slot1=="a7")){		
		
 
		status.innerHTML = "<?php echo $bonus_slot_3d; ?>";
		
		
		
		
		
<?php
echo $randd = rand(1, 6);

$zzzzz = 0;
$date = date('Y-m-d H:i:s');
if(!empty($_GET['days'])){
	
	
$_GET['days'] = $randd;	
	
	
if(!empty($guidy)){ 

if(!empty($_GET['days'])) 
$limitsw = $_GET['days'];
else
	$limitsw = 0;	
	
try
{	

$db = new PDO('sqlite:' .$rtyh);

 
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


$rep  = $db->query("SELECT * FROM playbonus where guid=".$guidy." limit 1");
   while ($row = $rep->fetch())	
{	
 $ip_playbonus = $row['guid'];
 $date_playbonus = $row['date'];
 
 			 
			 
if(((strtotime($date_playbonus)) - (strtotime($date))) < 0)
 $db->query("UPDATE playbonus SET date='".$dateend."' WHERE guid=".$guidy."");
else
  $zzzzz = 1;	
			
			
		   }
		   
}
    catch(PDOException $e){die($e->getMessage());}		
	
	
	
if(empty($ip_playbonus)){
if($db->exec("INSERT INTO playbonus ('name', 'guid', 'ban', 'ip', 'counts', 'date') VALUES ('0', '".$guidy."', '0', '".$yip."', '1', '".$dateend."')")>0)	
	echo '-';
}	
	
if(!empty($zzzzz)){
	
die ('</br></br></br></br></br><center> <h1>24h '.$ip_playbonus.' LIMIT!</h1></center></br>');
}

if($limitsw > 8)
$limitsw = 0;


echo '</br></br><center> <h1>'.$bonus_slot_vip.'  '.$limitsw.'  '.$bonus_slot_days.'</h1></center></br>';
 	
$statusw ='VIP'; 

try
{
	
if(empty($Msql_support))
	  {
	
	
	if(!empty($stats_db_path))
	{
	
    $bdd =  new PDO('sqlite:' . $stats_db_path);
	}
	
	  }
      else
	  {	  	  
    $dsn = "mysql:host=$host_adress;dbname=$db_name;charset=$charset_db";
    $bdd = new PDO($dsn, $db_user, $db_pass);	
	  }
	 
	 
$xl = $bdd->query("SELECT guid,status1,status1days,time FROM player_status where guid = ".$guidy." LIMIT 3");    
   
while ($jk = $xl->fetch())	
{	
  $guidy  = $jk['guid'];
  $status1days = $jk['status1days'];
  $statusone = $jk['status1'];
  $statusonetime = $jk['time'];
  
if(!empty($statusone)){	
$dateend = date('Y-m-d', strtotime($statusonetime. ' + '.$limitsw.' days'));	
	if($limitsw < 7){
$bdd->query("UPDATE player_status SET time='".$dateend."', status1days=status1days+'".$limitsw."' WHERE guid = ".$guidy."");  

$file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen);}} 
  
}


  
$dateend = date('Y-m-d', strtotime($date. ' + '.$limitsw.' days'));	


if(!empty($statusone)){
	
$dateend = date('Y-m-d', strtotime($statusonetime. ' + '.$limitsw.' days'));
 	
}else{
if($limitsw < 7){
	
$bdd->exec("INSERT INTO player_status (guid,time,timeh,text,status1,status1days,status2,status2days)
 VALUES ('".$guidy."','".$dateend."',CURRENT_TIME(),'0','".$statusw."','".$limitsw."','0','0')");	

 $file = $cpath.'databases/bonus.log';
$text = "Date:".$date." Guid:".$guidy." Days:".$limitsw." Player:".$player."\n";
$fOpen = fopen($file,'a'); 
fwrite($fOpen, $text);
fclose($fOpen); 
 }
}

}
catch(Exception $e)
{
    
    die('Errors : '.$e->getMessage());
}

if($limitsw < 7)
exit;

}}	 
?>				
		
		
		
		
var popUp = window.open('<?php echo $ssylka_na_codbox;?>vip_bonus.php?days=<?php echo $randd;?>', windowName, 'width=480, height=300, left=24, top=24, scrollbars, resizable');
 if (popUp == null || typeof(popUp)=='undefined') {  
    alert('Please disable your pop-up blocker and try again./Пожалуйста, отключите блокировку всплывающих окон и попробуйте снова.'); 
} 
else {  
    popUp.focus();
}	

    
		win.play();
	  }	
		
	else if ((slot1 == slot2 && slot2 == slot3) ||
		(slot1 == slot2 && slot3 == "a7") ||
		(slot1 == slot3 && slot2 == "a7") ||
		(slot2 == slot3 && slot1 == "a7") ||
		(slot1 == slot2 && slot1 == "a7") ||
		(slot1 == slot3 && slot1 == "a7") ||
		(slot2 == slot3 && slot2 == "a7")){	


		 
		status.innerHTML = "<?php echo $bonus_slot_vip; echo ' '.$randd; ?> <?php echo $bonus_slot_days; ?>";
		
 var popUp = window.open('<?php echo $ssylka_na_codbox;?>vip_bonus.php?days=<?php echo $randd;?>', windowName, 'width=480, height=300, left=24, top=24, scrollbars, resizable');     
 if (popUp == null || typeof(popUp)=='undefined') {  
    alert('Please disable your pop-up blocker and try again./Пожалуйста, отключите блокировку всплывающих окон и попробуйте снова.'); 
} 
else {  
    popUp.focus();
}	

		
		win.play();
	  }			

		 
	}else{
		
		
 if (hotxxx>=5)
        status.innerHTML = "LIMIT 5 SPINS"
        else
        status.innerHTML = "<?php echo $bonus_slot_lose; ?> / SPINS "+hotxxx+"" 			
				
		
		
	if (hotxxx>=5){
		
		
 
 
	
var popUp = window.open('<?php echo $ssylka_na_codbox;?>vip_bonus.php?days=999', windowName, 'width=480, height=300, left=24, top=24, scrollbars, resizable'); 
if (popUp == null || typeof(popUp)=='undefined') {  
    alert('Please disable your pop-up blocker and try again./Пожалуйста, отключите блокировку всплывающих окон и попробуйте снова.'); 
} 
else {  
    popUp.focus();
}	
 

	}		
		
		lose.play();
	}
	doing = false;
}

function toggleAudio(){
	if (!audio){
		audio = !audio;
		for (var x of spin){
			x.volume = 0.5;
		}
		for (var x of coin){
			x.volume = 0.5;
		}
		win.volume = 1.0;
		lose.volume = 1.0;
	}else{
		audio = !audio;
		for (var x of spin){
			x.volume = 0;
		}
		for (var x of coin){
			x.volume = 0;
		}
		win.volume = 0;
		lose.volume = 0;
	}
	document.getElementById("audio").src = "res/icons/audio"+(audio?"On":"Off")+".png";
}

function randomInt(min, max){
	return Math.floor((Math.random() * (max-min+1)) + min);
}
</script>
 
<?php 











} 
$i = 0;
echo "</br><center><h2>LAST BONUS!</h2>";
$file = $cpath.'databases/bonus.log';
//how many lines?
$linecount=100;

//what a typical line length?
$length=40;


//we double the offset factor on each iteration
//if our first guess at the file offset doesn't
//yield $linecount lines
$offset_factor=1;


$bytes=filesize($file);

$fp = fopen($file, "r") or die("Can't open $file");


$complete=false;
while (!$complete)
{
    //seek to a position close to end of file
    $offset = $linecount * $length * $offset_factor;
    fseek($fp, -$offset, SEEK_END);


    //we might seek mid-line, so read partial line
    //if our offset means we're reading the whole file, 
    //we don't skip...
    if ($offset<$bytes)
        fgets($fp);

    //read all following lines, store last x
    $lines=array();
    while(!feof($fp))
    {
        $line = fgets($fp);
        array_push($lines, $line);
        if (count($lines)>$linecount)
        {
            array_shift($lines);
            $complete=true;
        }
    }

    //if we read the whole file, we're done, even if we
    //don't have enough lines
    if ($offset>=$bytes)
        $complete=true;
    else
        $offset_factor*=2; //otherwise let seek even further back

}
fclose($fp);

//var_dump($lines);
$cntz = 0;
foreach($lines as $line){
	++$cntz;
	if(!empty($line))
echo "</br>".$cntz.") ".$line;	
}


echo "</center></br></br>";




include_once("footer.php"); 


 ?>
 

</body>
</html>